set pages 10000 lines 180 trimspool on colsep '|'
select to_char(sysdate, 'DDMONYYYY-HH24:MI:SS') report_tstamp from dual;
select i.instance_name
from v$instance i;
select i.version
from v$instance i;

set timing on
set serveroutput on
declare
        cnt     number;
        str     varchar2(32767);

        cursor ttabs is
        select table_name from user_tables
        where table_name not like 'SYS_%'
        -- and table_name not in ('COSTEDEVENT') 
        order by table_name;
begin
	dbms_output.put_line('TABLE_NAME | ROWCOUNT');
        for tab in ttabs
        loop
                str := 'select /*+ parallel */ count(*) from '|| tab.table_name;
                execute immediate str into cnt;
                dbms_output.put_line(tab.table_name|| ' | '||cnt);
        end loop;
end;
/
