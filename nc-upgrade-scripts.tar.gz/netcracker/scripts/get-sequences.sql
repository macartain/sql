set pages 10000 lines 180 trimspool on timing on colsep '|'

select * 
from dba_sequences ds
where ds.sequence_owner in ('GENEVA_ADMIN', 'BAL', 'IST')
order by ds.sequence_owner, ds.sequence_name;
