set lines 200 pages 10000 echo off feed off verify off trimspool on

select to_char(sysdate, 'DDMONYYYY-HH24:MI:SS') from dual;

select i.instance_name
from v$instance i;

select i.version
from v$instance i;

col table_name for a30 trunc
col index_name for a30 trunc
col tablespace_name for a30 trunc
col iot_name for a7 trunc
col pct_free for 999
col pct_used for 999
col ini_trans for 999
col freelists for 999
col freelist_groups for 999
col degree for a4 trunc
col num_rows for 999,999,999,999
col ITL for 999
col FL for 999
col FLG for 999
col PCF for 999
col PCU for 999
col pool for a9 trunc

prompt ************************************************************************
prompt TABLESPACES
prompt ************************************************************************
col TABLESPACE_NAME for a24
col BLK for a4
COL EXT_SIZE FORMAT A24 HEADING "Ext Size I/N/Min"
COL EXT_LIMITS FORMAT A18 HEADING "Limits Min/Max/%"
select TABLESPACE_NAME, (BLOCK_SIZE/1024) ||'K' BLK,
(INITIAL_EXTENT/1024 ||'K/' || NEXT_EXTENT/1024|| 'K/' || MIN_EXTLEN/1024||'K') EXT_SIZE,
(MIN_EXTENTS || '/' || DECODE(MAX_EXTENTS,2147483645,'UNL',MAX_EXTENTS)|| '/' || PCT_INCREASE) EXT_LIMITS,
 MIN_EXTLEN/1024  "MinExtLen", extent_management,
segment_space_management ASSM, SUBSTR(allocation_type,1,7) ALLOC, STATUS
from dba_tablespaces;

prompt ************************************************************************
prompt TABLES
prompt ************************************************************************
select  dt.table_name, dt.TABLESPACE_NAME, dt.IOT_NAME, 
        dt.pct_free PCF, dt.pct_used PCU, dt.INI_TRANS ITL, 
        dt.freelists FL, dt.freelist_groups FLG,
        to_char(LAST_ANALYZED, 'DDMONYY HH24:MI:SS') analysed, 
        AVG_ROW_LEN, NUM_ROWS, SAMPLE_SIZE, degree, bytes/1024/1024 MB, dt.buffer_pool pool
from dba_tables dt
    left join dba_segments ds on ds.segment_name = dt.table_name
where dt.owner='GENEVA_ADMIN'
and segment_type = 'TABLE' 
order by table_name;

prompt ************************************************************************
prompt INDEXES
prompt ************************************************************************
select di.index_name, di.tablespace_name, di.pct_free, di.ini_trans, di.freelists, di.freelist_groups, di.degree
from dba_indexes di
where owner='GENEVA_ADMIN'
order by di.index_name; 

