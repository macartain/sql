#/bin/ksh

sqlplus -s $DATABASE << EOF
alter session force parallel query;
spool count.sql

set feedback off echo off line 300 pages 0 serveroutput on

exec dbms_output.put_line('spool RBMrowcount.out');

select 'select /*+PARALLEL ('||ut.table_name||',32)' || nvl2(uc.constraint_name,' INDEX_FFS('||uc.table_name||' '||uc.constraint_name||')','') || ' */ '''||ut.table_name||'|'' || count(*) from '||ut.table_name||';' 
from user_tables ut, user_constraints uc
where
ut.TABLE_NAME = uc.table_name(+) and constraint_type(+) = 'P'
and ut.table_name not like 'SYS_IOT_%' 
and ut.table_name not like '%QUEUE%'
and ut.table_name not like '%JAVA%'
and ut.table_name not like 'AQ$%'
and ut.table_name not like '%HEAD%'
and ut.table_name not like '%AUDIT%'
and ut.table_name not like 'OFFER%'
and ut.table_name not like 'TMP%'
and ut.table_name not like 'DUPLICATECHECK%'
and ut.table_name not like 'IMV%'
and ut.table_name not in ('COSTEDEVENT','REJECTEVENT','AUDITTRAIL') 
order by ut.table_name;

exec dbms_output.put_line('spool off');
exec dbms_output.put_line('exit');
spool off

@count.sql
EOF

