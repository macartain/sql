set lines 200 pages 500 echo off feed off verify off trimspool on

col name for a45 trunc
col display_value for a45 trunc
select to_char(sysdate, 'DDMONYYYY-HH24:MI:SS') from dual;

select i.instance_name 
from v$instance i;

select i.version 
from v$instance i;

select p.name, p.display_value
from v$parameter p
order by name;
