set pages 10000 lines 180 trimspool on timing on colsep '|'
col string_value for a75
col name for a65
select * from gparams;
