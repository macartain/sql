-- Add
-- orphaned rows?
-- check default passwords?
-- list of users to check for schemas?
-- current AWR status
-- current stats date breakdown

--set serveroutput on lines 500 pages 3000 colsep |
set serveroutput on lines 500 pages 3000 
col SYStimestamp for a65
col host_name for a10
col TRIGGERING_EVENT for a40

prompt ============================================================
prompt Pre-upgrade checks
prompt ============================================================
SELECT SYStimestamp, instance_name, host_name FROM v$instance;
set pages 10000 lines 180 trimspool on

prompt ============================================================
prompt Host and DB details
prompt ============================================================
select HOST_NAME, VERSION, to_char(STARTUP_TIME, 'DDMONYY-HH24:MI:SS') starttm from v$instance;
select  NAME, to_char(CREATED,'DDMONYY-HH24:MI:SS') creattm, LOG_MODE, FORCE_LOGGING, DB_UNIQUE_NAME, FLASHBACK_ON  from v$database;
select * from v$nls_parameters;

prompt ============================================================
prompt Oracle compatibility
prompt ============================================================
show parameter compat;

prompt ============================================================
prompt Oracle params
prompt ============================================================
show parameter _bump;
show parameter _para;

prompt ============================================================
prompt Oracle SGA
prompt ============================================================
sho sga
break on report
compute sum of curr on report
col COMPONENT for a35
col curr for 999,999
col minsz for 999,999
col maxsz for 999,999
col usersz for 999,999
col OPER_COUNT for 999,999,999
col GRANULE  for a8

select COMPONENT, CURRENT_SIZE/(1024*1024) curr, MIN_SIZE/(1024*1024) minsz, MAX_SIZE/(1024*1024) maxsz, USER_SPECIFIED_SIZE/(1024*1024) usede, TO_CHAR(LAST_OPER_TIME,'DDMONYYYY-HH24:MI:SS') last_op, GRANULE_SIZE/(1024*1024)||'K' granule
from v$sga_dynamic_components;
clear breaks

prompt ============================================================
prompt Redo log setup
prompt ============================================================
col member format a65
SELECT a.group#, a.member, b.bytes
  FROM v$logfile a, v$log b 
WHERE a.group# = b.group#;
  
prompt ============================================================
prompt Logging status
prompt ============================================================
col FORCE_LOGGING for a13

select FORCE_LOGGING, LOG_MODE from V$DATABASE;

select tablespace_name, FORCE_LOGGING, status from DBA_TABLESPACES;

prompt ============================================================
prompt Table logging status
prompt ============================================================
select LOGGING, count(*)
from dba_tables
where OWNER='GENEVA_ADMIN'
group by LOGGING;

prompt ============================================================
prompt Tables with LOGGING=NO/NULL
prompt ============================================================
select TABLE_NAME, LOGGING
from dba_tables
where OWNER='GENEVA_ADMIN'
and (LOGGING='NO' or LOGGING is null)
order by LOGGING, TABLE_NAME;

prompt ============================================================
prompt Index logging status
prompt ============================================================
select LOGGING, count(*)
from dba_indexes
where OWNER='GENEVA_ADMIN'
group by LOGGING;

prompt ============================================================
prompt Indexes with LOGGING=NO
prompt ============================================================
select INDEX_NAME, LOGGING
from dba_indexes
where OWNER='GENEVA_ADMIN'
and LOGGING='NO'
order by INDEX_NAME;

prompt ============================================================
prompt Login case-sensitivity
prompt ============================================================
show parameter case;

prompt ============================================================
prompt Recyclebin
prompt ============================================================
show parameter recyc;

prompt ============================================================
prompt Pre-9i tables with non-PDML ITL - disables parallel ops
prompt Needs data dictionary access...
prompt ============================================================
SELECT u.name owner, o.name FROM sys.obj$ o, sys.tab$ t, sys.user$ u
WHERE o.obj# = t.obj# AND o.owner# = u.user#
 AND bitand(t.property,536870912) != 536870912
 and u.name='GENEVA_ADMIN'
 and o.name not like 'SYS_IOT_%'
 and o.name not like '%QUEUE%';

prompt ============================================================
prompt PX-related params
prompt ============================================================
sho parameter para

prompt ============================================================
prompt Table names too long
prompt ============================================================
select table_name, length(table_name)
from user_tables
where length(table_name) >30;

prompt ============================================================
prompt Non standard table names 
prompt ============================================================
select table_name
from dba_tables 
where table_name like '%/_%' ESCAPE '/'
and owner ='GENEVA_ADMIN' 
and table_name not like 'OLD_%'
and table_name not like 'AQ%'
and table_name not like 'SYS_%'
and table_name not like 'VERSION_GENEVA_%'
and table_name not like 'PREVERS_RB_%';

prompt ============================================================
prompt Unusually named indexes
prompt ============================================================
select di.index_name
from dba_indexes di
where di.owner='GENEVA_ADMIN'
and di.index_name not like '%_PK'
and di.index_name not like '%_AK_'
and di.index_name not like '%_AK__'
and di.index_name not like '%_UK_'
and di.index_name not like '%_UK__'
and di.index_name not like 'SYS_%'  
and di.index_name not like 'AQ$_%';

prompt ============================================================
prompt Unusually named triggers
prompt ============================================================
select dt.trigger_name, dt.trigger_type, dt.triggering_event, dt.table_name, dt.status 
from dba_triggers dt
where dt.table_owner='GENEVA_ADMIN'
and dt.trigger_name not like 'TR%';

prompt ============================================================
prompt Unusually named code objects
prompt ============================================================
select OBJECT_NAME, OBJECT_TYPE, status, to_char(created, 'dd-MON-yy hh24:mi')
from dba_objects dj
where (dj.OBJECT_NAME not like 'GNV%' and dj.OBJECT_NAME not like 'RB%' and dj.OBJECT_NAME not like 'TCA%')
and dj.object_type in ('PROCEDURE', 'FUNCTION', 'PACKAGE', 'PACKAGE BODY')
and dj.owner='GENEVA_ADMIN'
order by OBJECT_NAME;

prompt ============================================================
prompt Invalid objects
prompt ============================================================
col object_name for a55
select owner, object_name, OBJECT_TYPE, status
from all_objects
where status='INVALID'
and OBJECT_TYPE != 'SYNONYM'
order by owner, object_name;

prompt ============================================================
prompt Queue propagation schedules
prompt ============================================================
col schema for a12
col qname for a25
col destination for a10
col LAST_ERROR_MSG for a35 word_wrap
select schema, QNAME, DESTINATION, SCHEDULE_DISABLED, 
to_char(START_DATE,'MM-DD-YYYY HH24:MI:SS') as Started, 
to_char(LAST_RUN_DATE,'MM-DD-YYYY HH24:MI:SS') as Last_Run, 
PROCESS_NAME, TOTAL_NUMBER, FAILURES, LAST_ERROR_MSG
from DBA_QUEUE_SCHEDULES;

prompt ============================================================
prompt Materialised views and logs
prompt ============================================================
select log_owner,log_table
from dba_mview_logs;

select owner,mview_name, to_char(last_refresh_date, 'DDMONYY-HH24:mi') last_refresh
from dba_mviews;

prompt ============================================================
prompt Queue contents
prompt ============================================================
col owner for a15
col name for a34
col TOTAL_WAIT for 999,999,999,999
break on owner
select owner, NAME, QUEUE_TYPE, WAITING, READY,EXPIRED, TOTAL_WAIT, AVERAGE_WAIT
from GV$AQ q, dba_queues u
where q.QID = u.QID
and owner = 'GENEVA_ADMIN'
and name in ('COSTEDEVENTQUEUEHEAD', 'COSTEDEVENTQUEUETAIL', 'REJECTEVENTQUEUEHEAD', 'REJECTEVENTQUEUETAIL')
order by owner, queue_type, queue_table, name;

prompt ============================================================
prompt Scheduled jobs
prompt ============================================================
col owner for a12
col PROGRAM_OWNER for a12
col PROGRAM_NAME for a25
col JOB_NAME for a30
col JOB_TYPE for a20
col JOB_ACTION for a35 wrap
col SCHEDULE_NAME for a25
col REPEAT_INTERVAL for a30 wrap
select OWNER, JOB_NAME, PROGRAM_NAME, SCHEDULE_NAME, REPEAT_INTERVAL, STATE, 
    TO_CHAR(START_DATE, 'DDMONYY-HH24:MI') startdtm, TO_CHAR(NEXT_RUN_DATE, 'DDMONYY-HH24:MI') nextrun 
from dba_scheduler_jobs;

prompt ============================================================
prompt Out-of-range RANDOM_HASHES
prompt ============================================================
select account_num, random_hash from account 
where random_hash<0
or random_hash >1000000;

select customer_ref, random_hash from customer
where random_hash<0
or random_hash >1000000;

prompt ============================================================
prompt Java component  checks
prompt ============================================================
col objname for a80
select dbms_java.longname(object_name) objname, status, created
  from dba_objects
where object_type = 'JAVA CLASS'
   and OBJECT_NAME like '%DataValid%';

select t.OWNER, count(*) as java_classes
  from dba_objects t
where t.OBJECT_TYPE = 'JAVA CLASS'
   and t.OWNER like '%_ADMIN'
group by t.OWNER;

prompt ============================================================
prompt Component versions - Oracle
prompt ============================================================
col COMP_NAME for a45
col COMP_ID for a15
select COMP_ID, COMP_NAME, VERSION, STATUS 
from dba_registry;

prompt ============================================================
prompt Component versions - RB
prompt ============================================================
col product for a35
col value for a45
select substr(b.name,1,40)||':'||substr(c.name,1,40) PRODUCT, to_char(c.value) Value 
from ipf_admin.systemregistryentry a, ipf_admin.systemregistryentry b, ipf_admin.systemregistryentry c  
where a.name = 'Installed' 
and a.id = b.parent_id 
and b.id = c.parent_id 
and c.name in ('currentDatabaseVersion','currentSoftwareVersion') 
order by 1; 

prompt ============================================================
prompt Key system registry values
prompt ============================================================
select * from ipf_admin.systemregistryentry where name like '%ORA%';
select * from ipf_admin.systemregistryentry where name like '%ROOT%';
select * from ipf_admin.systemregistryentry where name like '%HOST%';

prompt ============================================================
prompt End of script
prompt ============================================================
