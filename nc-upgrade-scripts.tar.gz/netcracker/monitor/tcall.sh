#!/bin/ksh

oldGetDBVal() {
	
	# set $sql and call this to execute arbitrary SQL that returns a char
	
	print Running: $sql
	sqlplus -s ${DATABASE} <<EOSQL
	set feedback off head off verify off
	whenever sqlerror exit sql.sqlcode
	whenever oserror exit oscode
	set serveroutput on size unlimited
	variable retval char(100)
	begin
		$sql
	end ;
	/
	print :retval
	exit
EOSQL
	return

}


getDBVal() {

	CMDRET=`sqlplus -s/nolog $DATABASE << eof
	$sql
	exit
	eof`

	CMDRET=`echo $CMDRET|tr -d ' '`

	if [[ "$CMDRET" = "norowsselected" ]]; then
		print "ERROR - No value" 
	else
		print $CMDRET
	fi
}

sql='select SCRIPTNAME||STEPNAME into :retval from migrationprocess;'
print Running - $(getDBVal);