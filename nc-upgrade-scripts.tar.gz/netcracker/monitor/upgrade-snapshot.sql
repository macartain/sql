set pages 200
set lines 1000
set trimspool on

prompt -----------------------------------------------------------------------------------------;
prompt MIGRATION PROGRESS;
prompt -----------------------------------------------------------------------------------------;
col SCRIPTNAME for a25
col LASTMESSAGE for a65
select * from TMP_LASTKEY;
select to_char(TIMESTAMP, 'YYYYMONDD-hh24:mi') tstamp, RUNNUMBER, SCRIPTNAME, STEPNAME, BEFOREAFTER, LASTMESSAGE from migrationprocess;


prompt -----------------------------------------------------------------------------------------;
prompt UNDO;
prompt -----------------------------------------------------------------------------------------;

SELECT tablespace_name, STATUS, SUM(BYTES)/(1024*1024) as mb, COUNT(*)
   FROM DBA_UNDO_EXTENTS
   GROUP BY tablespace_name, STATUS;

-- detail
--select tablespace_name, segment_name, blocks, bytes/1024, status
--from dba_undo_extents
--where upper(tablespace_name) like '%UNDO%'
--and rownum <30
;

prompt -----------------------------------------------------------------------------------------;
prompt TEMP;
prompt -----------------------------------------------------------------------------------------;

SELECT   A.tablespace_name tablespace, D.mb_total,
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM     v$sort_segment A,
         ( SELECT   B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
         FROM     v$tablespace B, v$tempfile C
         WHERE    B.ts#= C.ts#
         GROUP BY B.name, C.block_size
         ) D
WHERE    A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;

prompt -----------------------------------------------------------------------------------------;
prompt  Temp segment usage per session;
prompt -----------------------------------------------------------------------------------------;

col osuser for a12 trunc
col sid_serial for a10 trunc
col sid_serial for a10 trunc
col program for a22 trunc
col module for a12 trunc
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, S.osuser, P.spid, S.module,
         P.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
         COUNT(*) statements
FROM     v$sort_usage T, v$session S, dba_tablespaces TBS, v$process P
WHERE    T.session_addr = S.saddr
AND      S.paddr = P.addr
AND      T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, S.osuser, P.spid, S.module,
         P.program, TBS.block_size, T.tablespace
ORDER BY sid_serial;

prompt -----------------------------------------------------------------------------------------;
prompt Sessions;
prompt -----------------------------------------------------------------------------------------;

col user for a13 trunc
col osuser for a12 trunc
COL "SID,serial" FOR A10
col status FOR a10
COL "ps PID" FOR A10 trunc
COL "Shadow PID" FOR A8
COL PROGRAM FOR A26 trunc
col child for 999 trunc

SELECT nvl(vs.username, '-') "user", osuser, vs.sid||','||vs.serial# "SID,serial", process "ps PID", type, status,
        vs.PROGRAM, sql_id, SQL_CHILD_NUMBER child, vp.spid "Shadow PID", TO_CHAR(LOGON_TIME,'DDMON-hh24:mi:ss') logon
from v$session vs
        full outer join v$process vp on vs.paddr = vp.addr
order by LOGON_TIME desc;

exit;
