#!/bin/ksh 
# ----------------------------------------------------------------------------
# mwatch.sh - Migration watch
#
# sleep_interval  - interval between samples in seconds
#
# xplan_threshold - interval in seconds over which a migration step is 
# 	taken to need some analysis - if it has been running for greater
# 	than this interval then mwatch will try to guess the relevant SQL
# 	and generate an explain plan for it.
# ----------------------------------------------------------------------------
# v1.0 - 01FEB2013 - Initial version
# ----------------------------------------------------------------------------

sleep_interval=10				# looop interval - seconds
xplan_threshold=20				# no of seconds before capture xplan
monitor_user='GENEVA_ADMIN'		# currently unused
checked_combos=""				# tracks SQLID/child combinations already explained
		
# ----------------------------------------------------------------------------
# pull value from DB
# ----------------------------------------------------------------------------
getDBVal() {
	
	# set $sql and call this to execute arbitrary SQL that returns a char
	
	CMDRET=`sqlplus -s/nolog $DATABASE << eof
	$sql
	exit
	eof`

	CMDRET=`echo $CMDRET|tr -d ' '`
	
	if [[ "$CMDRET" = "norowsselected" ]]; then
		print "ERROR - No value yet" 
	else
		print $CMDRET
	fi

}

# ----------------------------------------------------------------------------
# seconds between current time and start of current step in migprocess
# ----------------------------------------------------------------------------
current_step_duration () {
	
	sql="select extract (day from NUMTODSINTERVAL((sysdate-timestamp), 'DAY'))*24*60*60 
	+ extract (hour from NUMTODSINTERVAL((sysdate-timestamp), 'DAY'))*60*60 
	+ extract (minute from NUMTODSINTERVAL((sysdate-timestamp), 'DAY'))*60 
	+ extract (second from NUMTODSINTERVAL((sysdate-timestamp), 'DAY')) as seconds_passed 
	into :retval from migrationprocess;"

	print $(getDBVal)
	
} # current_step_duration

# ----------------------------------------------------------------------------
# check if an explain plan has already been generated for SQLID/child combo
# ----------------------------------------------------------------------------
already_explained () {
	
	echo $checked_combos | grep -q $1-$2
	if [[ $? -eq 0 ]]; then
		print 1
	else
		print 0
	fi
	
} # already_explained

# ----------------------------------------------------------------------------
# get explain plans 
# ----------------------------------------------------------------------------
gen_explain_plan () {

	sqlplus -s $DATABASE <<EOSQL
	set pagesize 20000 lines 120 feedback off verify off echo off
	whenever sqlerror exit sql.sqlcode
	whenever oserror exit oscode
	set serveroutput on size unlimited
	select * from table(dbms_xplan.display_cursor('$1', '$2'));
	exit;
EOSQL

} # gen_explain_plan

# ----------------------------------------------------------------------------
# get all SQLIDs
# ----------------------------------------------------------------------------
get_sqlids () {

	# This weird here document escapes all metachars after it - doing it 
	# for just v\$session fails for some reason.
	# This code packs the cursor result set into a ksh array
	set -A sid_list `sqlplus -s $DATABASE <<\EOF
	set pagesize 0 feedback off verify off heading off echo off
	whenever sqlerror exit sql.sqlcode
	whenever oserror exit oscode
	select sql_id, sql_child_number 
		from v$session 
		where sql_id is not null 
		and username='GENEVA_ADMIN' 
		group by sql_id, sql_child_number;
	exit;
EOF`

	element=0
	while [ $element -lt  ${#sid_list[*]} ]
		do
		sid=${sid_list[$element]}
		let element=$element+1;
		child=${sid_list[$element]}
		let element=$element+1;
		print Candidate SQLID/child number: $sid child: $child
		if [[ $(already_explained $sid $child) -gt 0 ]]; then
			print This SQLID/child number combination already dumped
		else
			gen_explain_plan $sid $child
			checked_combos="${checked_combos}$sid-$child-"
		fi
	done

} # get_sqlids

# ----------------------------------------------------------------------------
# generate explain plan for step running longer than threshold 
# ----------------------------------------------------------------------------
report_long_running_step () {

	runtime=$(current_step_duration)
	print Current step running for $runtime seconds. 

	if [[ $runtime -gt $xplan_threshold ]]; then
		print Exceeds interval - candidate for Explain Plan...
		get_sqlids
	fi

} # report_long_running_step

# ----------------------------------------------------------------------------
# main sampling loop
# ----------------------------------------------------------------------------

print "Starting at $(date '+%Y%m%d%-H%M%S')"

while [ 1 ]; do

	print '#######################################################################'
	print "$(date +%Y%m%d-%H:%M:%S)"
	print '#######################################################################'

	sql='select SCRIPTNAME||STEPNAME into :retval from migrationprocess;'
	print Running - $(getDBVal);

	sql='select to_char(TIMESTAMP) into :retval from migrationprocess;'
	print Running since $(getDBVal)
	
	report_long_running_step
	
	# run SQL to capture standard stuff
	sqlplus -s ${DATABASE} @upgrade-snapshot
	
	sleep $sleep_interval;

done # while 1

# ----------------------------------------------------------------------------
# end of script
# ----------------------------------------------------------------------------
