--
-- List available snapshots
--
-- Based on $ORACLE_HOME/rdbms/admin/awrinput.sql
--
--
set termout off;
set pages 100
set lines 120
column instart_fmt noprint;
column inst_name   format a12  heading 'Instance';
column db_name     format a12  heading 'DB Name';
column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column lvl         format 99   heading 'Snap|Level';

break on inst_name on db_name on host on instart_fmt skip 1;

ttitle off;

spool logs/list_all_awr_snapshots.lst

select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  instart_fmt
     , di.instance_name                                  inst_name
     , di.db_name                                        db_name
     , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
     , s.snap_level                                      lvl
  from dba_hist_snapshot s
     , dba_hist_database_instance di
 where
   di.dbid             = s.dbid
   and di.instance_number  = s.instance_number
   and di.startup_time     = s.startup_time
 order by db_name, instance_name, snap_id;

spool off
set termout on;
prompt Output file: list_all_awr_snapshots.lst
!echo "Use generate_awr_reports.ksh to generate AWR reports." >> list_all_awr_snapshots.lst
quit
