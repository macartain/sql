#!/usr/bin/ksh

TARGET_DIR="logs/infrootfiles-${ORACLE_SID}-`date +%Y%m%d_%H%M`"

##########################################################################
# Main 
##########################################################################
if [[ ! -r $INFINYS_ROOT ]]; then
      print "Couldn't find INFINYS_ROOT.."
      exit 1
fi

print "Running post checks.."
sqlplus -s $DATABASE @run_post_checks.sql
ls -lart logs

print "Tarring up INFINYS_ROOT files .."
mkdir -p ${TARGET_DIR}
cp -r $INFINYS_ROOT/infinys.env $TARGET_DIR/.
cp -r $INFINYS_ROOT/*.xml $TARGET_DIR/.
cp -r $INFINYS_ROOT/infinys.properties $TARGET_DIR/.
tar cf - $INFINYS_ROOT/logs | gzip -c > $TARGET_DIR/infroot-toplevel-logs.tgz

if [[ ! -r $INFINYS_ROOT/stage/RB/RB/schema/migration ]]; then
      print "Couldn't find STAGE_ROOT schema area.."
else 
      tar cf - $INFINYS_ROOT/stage/RB/RB/schema/migration | gzip -c > $TARGET_DIR/RB-migration-scripts-logs.tgz
fi

ls -lart $TARGET_DIR

sqlplus -s $DATABASE @monitor/list_all_awr_snapshots.sql
print Remember to generate AWRs - list at logs/list_all_awr_snapshots.lst
print Remember to stop mwatch if running
