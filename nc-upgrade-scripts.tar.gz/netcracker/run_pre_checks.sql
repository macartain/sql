set pages 10000 lines 1000 trimspool on timing on colsep '|'

prompt sending output to spool files...
set termout off

define stage = 'PRE'
column tm new_value file_label noprint
select to_char(sysdate, 'YYYYMMDD-HH24MI') || '-' || '&stage' || '-' || instance_name tm from v$instance;

spool logs/&file_label.-prechecks.log
@scripts/get-prechecks.sql
spool off

spool logs/&file_label.-initparams.log
@scripts/get-initparams.sql
spool off

spool logs/&file_label.-storage-params.log
@scripts/get-storage-params.sql
spool off

spool logs/&file_label.-additional_space.log
@scripts/get-additional_space.sql
spool off

-- generate rowcount script
set timing off
spool scripts/get-rowcounts.sql
@scripts/generate-rowcount-script.sql
spool off

spool logs/&file_label.-rowcounts.log
@scripts/get-rowcounts.sql
spool off
set timing on

spool logs/&file_label.-sequences.log
@scripts/get-sequences.sql
spool off

spool logs/&file_label.-segment-sizes.log
@scripts/get-segment-sizes.sql
spool off

spool logs/&file_label.-gparams.log
@scripts/get-gparams.sql
spool off

spool logs/&file_label.-tspace-sizes.log
@scripts/get-tspace-sizes.sql
spool off

exit;
