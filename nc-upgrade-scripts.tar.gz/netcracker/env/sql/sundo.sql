col mxtim for 999,999.99 heading "longest txn|time (mins)"
col maxcon heading "max|concurrent|txns"
select TO_CHAR(BEGIN_TIME, 'DDMONYY-HH24:MI') begin_tm, 
undotsn, undoblks, txncount, maxquerylen/60 as mxtim, maxconcurrency as maxcon, nospaceerrcnt, TUNED_UNDORETENTION 
from v$undostat
-- for last hour
-- where begin_time > sysdate-(1/24)
order by BEGIN_TIME;
prompt Segments:
SELECT tablespace_name, STATUS, SUM(BYTES)/(1024*1024) as mb, COUNT(*)   
   FROM DBA_UNDO_EXTENTS 
   GROUP BY tablespace_name, STATUS;  
