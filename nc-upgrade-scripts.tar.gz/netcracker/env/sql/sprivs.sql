set pages 0 feed off veri off lines 500 trimspool on
accept thisuser prompt "Enter user to report: "

-- ((select the role(s) that a user has been assigned....?)
prompt ========================================================================
prompt Roles assigned to &&thisuser
prompt ========================================================================
select * from dba_role_privs where GRANTEE='&&thisuser'
order by GRANTED_ROLE;

-- (see all the 'grants' that have been assigned to a user....? )
prompt ========================================================================
prompt Grants to &&thisuser
prompt ========================================================================
select * from dba_sys_privs 
where grantee = '&&thisuser'
or GRANTEE in (
	select GRANTED_ROLE from dba_role_privs where GRANTEE='&&thisuser')
order by grantee, PRIVILEGE;

-- And Objects 
prompt ========================================================================
prompt Object Grants to &&thisuser
prompt ========================================================================
SELECT grantee, privilege, owner, table_name
FROM dba_tab_privs
where grantee = '&&thisuser'
or GRANTEE in (
	select GRANTED_ROLE from dba_role_privs where GRANTEE='&&thisuser')
order by grantee, PRIVILEGE, owner, table_name;
