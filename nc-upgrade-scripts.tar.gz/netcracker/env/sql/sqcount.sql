select count(*) ceqhead from aq$costedeventqueuehead
/
select count(*) ceqtail from aq$costedeventqueuetail
/
select count(*) rejecthead from aq$rejecteventqueuehead
/
select count(*) rejecttail from aq$rejecteventqueuetail
/

