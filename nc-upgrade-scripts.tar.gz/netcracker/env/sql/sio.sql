set pages 200
set lines 180
col user for a13
COL "SID,serial" FOR A10
COL PROGRAM FOR A30 trunc
col sql_text for a40 trunc
SELECT nvl(vs.username, '-') "user", vs.sid||','||vs.serial# "SID,serial", 
vs.PROGRAM, sql_text, sio.BLOCK_GETS, sio.CONSISTENT_GETS, sio.PHYSICAL_READS, sio.BLOCK_CHANGES, sio.CONSISTENT_CHANGES
from v$session vs 
left join v$sqlarea sq on vs.sql_hash_value = sq.hash_value
and vs.SQL_ADDRESS = sq.ADDRESS
join v$sess_io sio on sio.SID = vs.SID
order by sio.PHYSICAL_READS desc
/
