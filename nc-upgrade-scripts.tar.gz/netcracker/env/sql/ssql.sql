col sql_text for a160 wrap
select sql_text from v$sql where sql_id='&sql_id';
