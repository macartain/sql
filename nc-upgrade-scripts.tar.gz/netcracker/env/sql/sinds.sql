-- indexes for a table
col COLUMN_NAME for a35
break on INDEX_NAME skip 1
select * from user_ind_columns
where TABLE_NAME='&table_name'
order by INDEX_NAME, COLUMN_POSITION;
