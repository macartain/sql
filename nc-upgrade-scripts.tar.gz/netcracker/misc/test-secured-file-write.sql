begin
secured_file.writefile_1('testkey','thing');
end;
/
