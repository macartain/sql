select * from ipf_admin.systemregistryentry where name like '%ORA%';
select * from ipf_admin.systemregistryentry where name like '%ROOT%';
select * from ipf_admin.systemregistryentry where name like '%HOST%';

select substr(b.name,1,40)||':'||substr(c.name,1,40) PRODUCT, to_char(c.value) Value 
from ipf_admin.systemregistryentry a, ipf_admin.systemregistryentry b, ipf_admin.systemregistryentry c  
where a.name = 'Installed' 
and a.id = b.parent_id 
and b.id = c.parent_id 
and c.name in ('currentDatabaseVersion','currentSoftwareVersion') 
order by 1; 
