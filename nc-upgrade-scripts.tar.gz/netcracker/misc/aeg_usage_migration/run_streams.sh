#!/usr/bin/ksh
#################################################################################

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting 10 streams in background"

nohup wrap-aegmigration.sh 0 100000 2>&1 >aegmig1.log &
nohup wrap-aegmigration.sh 100001 200000 2>&1 >aegmig2.log &
nohup wrap-aegmigration.sh 200001 300000 2>&1 >aegmig3.log &
nohup wrap-aegmigration.sh 300001 400000 2>&1 >aegmig4.log &
nohup wrap-aegmigration.sh 400001 500000 2>&1 >aegmig5.log &
nohup wrap-aegmigration.sh 500001 600000 2>&1 >aegmig6.log &
nohup wrap-aegmigration.sh 600001 700000 2>&1 >aegmig7.log &
nohup wrap-aegmigration.sh 700001 800000 2>&1 >aegmig8.log &
nohup wrap-aegmigration.sh 800001 900000 2>&1 >aegmig9.log &
nohup wrap-aegmigration.sh 900001 1000000 2>&1 >aegmig10.log &

printInform "AEGUSAGEMIGRATION.MIGRATEUNBILLEDUSAGE process completed successfully..."

exit 0