-- bulk migration
set serveroutput on
set trimspool on
set timing on 
BEGIN
        dbms_output.enable(1000000);
        dbms_output.put_line('Starting');
        aegusagemigration.migrateunbilledusage(
                p_accountNumber => NULL,
                p_eventSeq => NULL,
                p_numOfAcctsPerRun => NULL,
                p_batchCommitSize => NULL,
                p_commitOrNoCommit => 'Y');
EXCEPTION
        WHEN OTHERS THEN
                dbms_output.put_line( 'RETURN:ERROR: ' || sqlerrm );
END;
/
exit;
