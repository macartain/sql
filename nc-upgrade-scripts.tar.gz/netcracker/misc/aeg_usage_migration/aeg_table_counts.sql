set echo off
select systimestamp from dual;
select count(distinct account_num) as AEGACCTS_COUNT from AEGACCOUNT;
select count(distinct account_num) as ACCTS_COUNT from ACCOUNT;
select count(distinct account_num) as TMPMIG_COUNT from TMPAEGMIGRATEACC;

-- bulk migration table count
select USAGE_MIGRATED_BOO, count(*)
from TMPAEGMIGRATEACC
group by USAGE_MIGRATED_BOO;

-- predicted inserts to AEGDAILYUSAGESUMMARY
select count(*) as PREDICTED_AEGDUS_INSERT_COUNT from (
       SELECT /*+ parallel */ CE.account_num
       FROM costedevent CE, account ACC
                WHERE CE.account_num = ACC.account_num AND
                     CE.event_seq >= ACC.bill_event_seq
                GROUP BY CE.account_num,
                        CE.event_seq,
                        CE.event_source,
                        TRUNC(CE.event_dtm),
                        CE.event_type_id,
                        CE.tax_override_id,
                        CE.revenue_code_id);

-- actual inserts to AEGDAILYUSAGESUMMARY 
select count(*) as ACTUAL_AEGDUS_INSERT_COUNT from AEGDAILYUSAGESUMMARY;
exit;
