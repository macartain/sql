--------------------------------------------------------------------------------------------------------------------
-- Author:      Colm McCartan
-- Date:        22 November 2013
-- Copyright:   NetCracker Technology Corporation 2013
--------------------------------------------------------------------------------------------------------------------
--
--------------------------------------------------------------------------------------------------------------------
--
-- Drops table and procedure needed to support running AEGUSAGEMIGRATION in parallel ranges
--
--------------------------------------------------------------------------------------------------------------------
whenever sqlerror exit
set lines 200
set trimspool on
set verify off
set feed off

prompt
prompt Dropping NC_AEGMIGLOGTMP table...
--
-- Drop table, but if that table doesn't exist then do not display an error message
--
BEGIN
        EXECUTE IMMEDIATE 'drop table NC_AEGMIGLOGTMP purge';
EXCEPTION
        WHEN OTHERS THEN IF sqlcode != -0942 THEN RAISE; END IF;
END;
/
        
prompt Dropping wrapper procedure RUN_AEGMIGRANGE
drop procedure RUN_AEGMIGRANGE;

prompt Done

