--------------------------------------------------------------------------------------------------------------------
-- Author:      Colm McCartan
-- Date:        22 November 2013
-- Copyright:   NetCracker Technology Corporation 2013
--------------------------------------------------------------------------------------------------------------------
-- Modify these parameters to suit the local environment
--
define target_tablespace = users
--
--------------------------------------------------------------------------------------------------------------------
--
-- Creates table and prcedure needed to support running AEGUSAGEMIGRATION in parallel ranges
--
--------------------------------------------------------------------------------------------------------------------
whenever sqlerror exit
set lines 200
set trimspool on
set verify off
set feed off

--
-- Drop table, but if that table doesn't exist then do not display an error message
--
BEGIN
        EXECUTE IMMEDIATE 'drop table NC_AEGMIGLOGTMP purge';
EXCEPTION
        WHEN OTHERS THEN IF sqlcode != -0942 THEN RAISE; END IF;
END;
/

prompt
prompt Creating NC_AEGMIGLOGTMP table...
--
-- Stores start and end points for streams - more useful when invoked from DBMS_SCHEDULER 
--
create table NC_AEGMIGLOGTMP (
        tstamp  timestamp,
        jobno   number,
        msg		varchar2(128))
        tablespace &target_tablespace;
        
prompt Creating wrapper procedure RUN_AEGMIGRANGE
--
-- Given a lower and upper range will run migrateunbilledusage for each account with a 
-- random hash in that range.
--
create or replace procedure RUN_AEGMIGRANGE(
	lower NUMBER, 
	upper NUMBER,
	runid NUMBER := NULL
	) 
as

cursor accountrange 
is 
select account_num
from account a
where a.random_hash between lower and upper;

begin 		
	insert into nc_aegmiglogtmp values ( 
		systimestamp, runid, 'Starting run for range: '||lower||'->'|| upper); 
    
	for acct in accountrange
	loop
		insert into nc_aegmiglogtmp values ( 
			systimestamp, runid, acct.account_num); 
			aegusagemigration.migrateunbilledusage (
				p_accountNumber => acct.account_num,
				p_eventSeq => NULL,
				p_numOfAcctsPerRun => NULL,
				p_batchCommitSize => NULL,
				p_commitOrNoCommit => 'Y');
	end loop;    

	insert into nc_aegmiglogtmp values ( 
		systimestamp, runid, 'Completed run for range: '||lower||'->'|| upper); 
end;
/
sho err
prompt Done
