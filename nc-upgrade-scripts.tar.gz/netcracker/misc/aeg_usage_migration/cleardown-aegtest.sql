truncate table AEGDAILYUSAGESUMMARY ;
drop table TMPAEGMIGRATEACC;
truncate table nc_aegmiglogtmp;

-- repopulate AEGACCOUNT
truncate table AEGACCOUNT;
insert /*+ APPEND */ into AEGACCOUNT(
    ACCOUNT_NUM,
    NEXT_AEGWD_RUN_DAT,
    AEG_REVENUE_CHANGE_BOO,
    AEGWD_CHARGED_TO_DAT,
    NEXT_PRODUCT_CHANGE_SEQ,
    LAST_PROCESSED_CHARGE_SEQ,
    DOMAIN_ID
    )
select  ACCOUNT_NUM,
        trunc(NEXT_BILL_DTM),
        'F',
        NULL,
        1,
        NULL,
        DOMAIN_ID
from    ACCOUNT;
commit;

exit;
