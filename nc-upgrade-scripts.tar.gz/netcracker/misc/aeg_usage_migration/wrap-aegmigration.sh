#!/usr/bin/ksh
#################################################################################

PROG_NAME=$(basename $0)
LOG_FILE="${PWD}/aegusagemigration.$$.log"
LOWER_RANGE=$1
UPPER_RANGE=$2

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting ranged AEGUSAGEMIGRATION.MIGRATEUNBILLEDUSAGE process..."
printInform "Executing for RANDOM_HASH range ${LOWER_RANGE} to ${UPPER_RANGE}"

sqlResult=`sqlplus -S ${DATABASE} >${LOG_FILE} << EOF
           set heading off feedback off echo off pagesize 0 wrap off tab off
           set linesize 1000
           set serveroutput on
           DECLARE
           BEGIN
               run_aegmigrange(${LOWER_RANGE},${UPPER_RANGE},$$);
               COMMIT;
           EXCEPTION
               WHEN OTHERS THEN
                   dbms_output.put_line('ERROR : ' || SQLERRM);
           END;
           /
           exit;
           EOF`

printInform "AEGUSAGEMIGRATION Output:"
cat ${LOG_FILE}

cat ${LOG_FILE} | grep -i "ERROR" > /dev/null
if [ $? -eq 0 ] 
then
    printError "ERROR: Failed to complete AEGUSAGEMIGRATION.MIGRATEUNBILLEDUSAGE process..."
    printInform "Check ${LOG_FILE} file for more details"
    exit 1
fi 

printInform "AEGUSAGEMIGRATION.MIGRATEUNBILLEDUSAGE process completed successfully..."

exit 0

