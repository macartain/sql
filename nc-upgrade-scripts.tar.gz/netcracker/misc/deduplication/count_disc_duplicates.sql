-- environment details
col SYStimestamp for a45
col host_name for a10
SELECT SYStimestamp, instance_name, host_name FROM v$instance;

prompt CPDU duplicates count
SELECT /*+ parallel */ count(*) as CPDU_DUPS
FROM (SELECT CUSTOMER_REF, ROW_NUMBER() OVER (
            PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, 
            PERIOD_NUM, DOMAIN_ID ORDER BY ROWID) rn
      FROM CUSTPRODUCTDISCOUNTUSAGE)
WHERE rn>1;

prompt CPIDU duplicates count
SELECT /*+ parallel */ count(*) as CPIDU_DUPS
FROM (SELECT CUSTOMER_REF, ROW_NUMBER() OVER (
            PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, 
            PERIOD_NUM, EVENT_SEQ, DOMAIN_ID ORDER BY ROWID) rn
      FROM CUSTPRODINVOICEDISCUSAGE)
WHERE rn>1;