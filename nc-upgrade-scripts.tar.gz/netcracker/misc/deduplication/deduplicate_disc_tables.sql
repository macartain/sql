--------------------------------------------------------------------------------------------------------------------
-- Backup and repair duplicate tables
--------------------------------------------------------------------------------------------------------------------
-- Modify these parameters to suit the local environment
--
define target_tablespace = users

--------------------------------------------------------------------------------------------------------------------
-- 
--------------------------------------------------------------------------------------------------------------------
whenever sqlerror exit
set lines 200 trimspool on verify off 

-- environment details
col SYStimestamp for a45
col host_name for a10
SELECT SYStimestamp, instance_name, host_name FROM v$instance;

prompt CPDU duplicates count
SELECT /*+ parallel */ count(*) as CPDU_DUPS
FROM (SELECT CUSTOMER_REF, ROW_NUMBER() OVER (
            PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, 
            PERIOD_NUM, DOMAIN_ID ORDER BY ROWID) rn
      FROM CUSTPRODUCTDISCOUNTUSAGE)
WHERE rn>1;

prompt CPIDU duplicates count
SELECT /*+ parallel */ count(*) as CPIDU_DUPS
FROM (SELECT CUSTOMER_REF, ROW_NUMBER() OVER (
            PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, 
            PERIOD_NUM, EVENT_SEQ, DOMAIN_ID ORDER BY ROWID) rn
      FROM CUSTPRODINVOICEDISCUSAGE)
WHERE rn>1;

--------------------------------------------------------------------------------------------------------------------
-- CPDU repair
--------------------------------------------------------------------------------------------------------------------
set timing on
prompt
prompt Creating unduplicated CPDU copy...
CREATE TABLE NC_DEDUP_CPDU NOLOGGING TABLESPACE &target_tablespace
AS
SELECT c.*
FROM CUSTPRODUCTDISCOUNTUSAGE c
WHERE ROWID IN (SELECT /*+ parallel */ rid
FROM (SELECT ROWID rid, ROW_NUMBER() OVER (
		PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, PERIOD_NUM, DOMAIN_ID ORDER BY ROWID) rn
	FROM CUSTPRODUCTDISCOUNTUSAGE)
	WHERE rn=1);

prompt
prompt Backing up original CPDU ...
CREATE TABLE NC_BAK_CPDU NOLOGGING TABLESPACE &target_tablespace AS 
	select  /*+ parallel */ * 
	FROM CUSTPRODUCTDISCOUNTUSAGE;
 
prompt
prompt Truncating CPDU table...
TRUNCATE TABLE CUSTPRODUCTDISCOUNTUSAGE;
 
prompt
prompt Copying unduplicated CPDU rows...
INSERT INTO CUSTPRODUCTDISCOUNTUSAGE (SELECT * FROM NC_DEDUP_CPDU);
 
--------------------------------------------------------------------------------------------------------------------
-- CPIDU repair
--------------------------------------------------------------------------------------------------------------------
prompt
prompt Creating unduplicated CPIDU copy...
CREATE TABLE NC_DEDUP_CPIDU NOLOGGING TABLESPACE &target_tablespace
AS
SELECT c.*
FROM CUSTPRODINVOICEDISCUSAGE c
WHERE ROWID IN (SELECT /*+ parallel */ rid
FROM (SELECT ROWID rid, ROW_NUMBER() OVER (
		PARTITION BY CUSTOMER_REF , PRODUCT_SEQ, EVENT_DISCOUNT_ID, EVENT_SOURCE, PERIOD_NUM, EVENT_SEQ, DOMAIN_ID ORDER BY ROWID) rn
     FROM CUSTPRODINVOICEDISCUSAGE)
     WHERE rn=1);
 
prompt
prompt Backing up original CPIDU ...
CREATE TABLE NC_BAK_CPIDU NOLOGGING TABLESPACE &target_tablespace AS 
	SELECT /*+ parallel */ * 
	FROM CUSTPRODINVOICEDISCUSAGE;
 
prompt
prompt Truncating CPIDU table...
TRUNCATE TABLE CUSTPRODINVOICEDISCUSAGE;
 
prompt
prompt Copying unduplicated CPIDU rows...
INSERT INTO CUSTPRODINVOICEDISCUSAGE (SELECT * FROM NC_DEDUP_CPIDU);

prompt Done.
