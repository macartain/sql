set echo on
set timing on
spool cleanupdb.log
select systimestamp from dual;
show parameter job_queue_processes
alter system set job_queue_processes=0 scope=memory;
drop user UNIF_ADMIN cascade;
drop user OFM_ADMIN cascade;
drop user CDM_ADMIN cascade;
drop user IPFAPPUSER cascade;
drop user IPF_ADMIN cascade;
drop user INF_ADMIN cascade;
drop user IPF_AUDIT_ADMIN cascade;
drop user IPF_SEC_ADMIN cascade;
drop user INF_ADMIN cascade;
drop user PMI_ADMIN cascade;
drop user PAYHAN_ADMIN cascade;
drop user NII_ADMIN cascade;
drop user ENCRYPT_ADMIN cascade;
drop user CYGENT_ADMIN cascade;
drop user COMMON_ADMIN cascade;
drop user UNIF_ADMIN cascade;
drop user IPF_ADMIN cascade;
drop user IPF_SEC_ADMIN cascade;
drop user SIMULATORS_ADMIN cascade;
drop role INFINYS_PUBLIC_INSTALL ;
drop role INFINYS_OFM_ADMIN ;
drop role INFINYS_CDM_ADMIN ;
drop role CSM_ENCRYPT_ROLE ;
drop role PF_RO_ROLE_IPF_ADMIN ;
drop role PF_RO_ROLE_UNIF_ADMIN ;
drop role PF_UPD_ROLE_IPF_ADMIN;
drop role PF_UPD_ROLE_UNIF_ADMIN;
drop role PF_READ_ONLY_ROLE_IPF_ADMIN ;
drop role PF_READ_ONLY_ROLE_UNIF_ADMIN ;
drop role PF_UPDATE_ROLE_IPF_ADMIN;
drop role PF_UPDATE_ROLE_UNIF_ADMIN;
drop role INFINYS_COMMON_ADMIN;
drop role INFINYS_CYGENT_ADMIN;
drop role INFINYS_ENCRYPT_ADMIN;
drop role INFINYS_IPF_ADMIN;
drop role INFINYS_IPFAPPUSER;
drop role INFINYS_NII_ADMIN;
drop role INFINYS_PAYHAN_ADMIN;
drop role INFINYS_PMI_ADMIN;
drop role INFINYS_SIMULATORS_ADMIN;
drop role INFINYS_UNIF_ADMIN;
drop role INFINYS_PF;
drop role PF_AUDIT_ADMIN_IPF_AUDIT_ADMIN;
drop role PF_AUDIT_IPF_AUDIT_ADMIN;
drop role PF_AUDIT_READ_IPF_AUDIT_ADMIN;
drop user IPF_ADMIN cascade;
alter system set job_queue_processes=20 scope=memory;
select systimestamp from dual;
set echo off
spool off
exit

