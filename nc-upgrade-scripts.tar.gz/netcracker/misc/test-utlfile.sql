declare
  f utl_file.file_type;
begin
  f := utl_file.fopen('CVG_INFINYS_PF', 'test.txt', 'w');
  utl_file.put_line(f, 'line one: testing 123');
  utl_file.put_line(f, 'line two: testing 234');
  utl_file.fclose(f);
end;
/

