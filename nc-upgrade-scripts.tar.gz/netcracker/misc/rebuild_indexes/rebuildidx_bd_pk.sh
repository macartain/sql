#!/usr/bin/ksh
#################################################################################

PROG_NAME=$(basename $0)
LOG_FILE="${PWD}/BILLDETAILS_PK.$$.log"

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting BILLDETAILS_PK process..."

sqlResult=`sqlplus -S ${DATABASE} >${LOG_FILE} << EOF
	set trimout on trimspool on pagesize 5000 linesize 255 verify off
	set serveroutput on size 1000000
	alter session force parallel DDL;
	prompt Starting BILLDETAILS_PK
	@@rebuildidx_env.sql
	set timing on
	DECLARE
	BEGIN
		migrationCreateIndexParallel('BILLDETAILS', 'BILLDETAILS_PK', 'ACCOUNT_NUM asc, BILL_SEQ asc, BILL_VERSION asc, REVENUE_FEED_ID asc, BILL_REVENUE_FEED_SEQ asc', '&&gBILLDETAILS_PK', true);
	EXCEPTION
	WHEN OTHERS THEN
		dbms_output.put_line('ERROR : ' || SQLERRM);
	END;
	/
	set timing off
	prompt Done - BILLDETAILS_PK
	@rebuildidx_report.sql
	exit;
	EOF`

printInform "BILLDETAILS_PK Output:"
cat ${LOG_FILE}

cat ${LOG_FILE} | grep -i "ERROR" > /dev/null
if [ $? -eq 0 ] 
then
    printError "ERROR: in BILLDETAILS_PK process..."
    printInform "Check ${LOG_FILE} file for more details"
    exit 1
else 
	printInform "BILLDETAILS_PK process completed successfully..."
fi

exit 0

