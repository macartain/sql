define gBILLPRODUCTCHARGE_AK2          = USERS;
define gBILLDETAILS_PK                 = USERS;
define gBILLDETAILS_UK1                = USERS;
define gCUSTPRODUCTCHARGE_AK2          = USERS;
define gIndexDegreeOfParallelism = 4
@@./migrationCreateIndexParallel.sql 'F'
