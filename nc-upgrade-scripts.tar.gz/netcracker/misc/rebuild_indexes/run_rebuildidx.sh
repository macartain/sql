#!/usr/bin/ksh
#################################################################################

PROG_NAME=$(basename $0)

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting concurrent index rebuilds in background..."

nohup rebuildidx_cpc_ak2.sh 2>&1 >/dev/null &
wait 1
nohup rebuildidx_bpc_ak2.sh 2>&1 >/dev/null &
wait 1
nohup rebuildidx_bd_pk.sh 2>&1 >/dev/null &
wait 1
nohup rebuildidx_bd_uk1.sh 2>&1 >/dev/null & 

printInform "run_rebuildidx.sh process completed successfully."

exit 0
