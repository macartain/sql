drop procedure migrationCreateIndexParallel;
drop procedure dropIndex;
