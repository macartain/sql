#!/usr/bin/ksh
#################################################################################

PROG_NAME=$(basename $0)
LOG_FILE="${PWD}/REBUILDIDX_BPC_AK2.$$.log"

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting REBUILDIDX_BPC_AK2 process..."

sqlResult=`sqlplus -S ${DATABASE} >${LOG_FILE} << EOF
	set trimout on trimspool on pagesize 5000 linesize 255 verify off
	set serveroutput on size 1000000
	alter session force parallel DDL;
	prompt Starting BILLPRODUCTCHARGE_AK2
	@@rebuildidx_env.sql
	set timing on
	DECLARE
	BEGIN
		migrationCreateIndexParallel('BILLPRODUCTCHARGE', 'BILLPRODUCTCHARGE_AK2', 'ACCOUNT_NUM asc, CHARGE_END_DAT asc', '&&gBILLPRODUCTCHARGE_AK2', false);
	EXCEPTION
	WHEN OTHERS THEN
		dbms_output.put_line('ERROR : ' || SQLERRM);
	END;
	/
	set timing off
	prompt Done - BILLPRODUCTCHARGE_AK2
	@rebuildidx_report.sql
	exit;
	EOF`

printInform "REBUILDIDX_BPC_AK2 Output:"
cat ${LOG_FILE}

cat ${LOG_FILE} | grep -i "ERROR" > /dev/null
if [ $? -eq 0 ] 
then
    printError "ERROR: in REBUILDIDX_BPC_AK2 process..."
    printInform "Check ${LOG_FILE} file for more details"
    exit 1
else 
	printInform "REBUILDIDX_BPC_AK2 process completed successfully..."
fi

exit 0

