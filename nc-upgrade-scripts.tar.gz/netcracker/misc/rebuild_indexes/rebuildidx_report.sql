select ds.object_name, ds.created, ds.status, di.tablespace_name
from dba_objects ds join dba_indexes di on ds.object_name=di.index_name
where ds.object_name in ('CUSTPRODUCTCHARGE_AK2','BILLPRODUCTCHARGE_AK2','BILLDETAILS_UK1','BILLDETAILS_PK');
