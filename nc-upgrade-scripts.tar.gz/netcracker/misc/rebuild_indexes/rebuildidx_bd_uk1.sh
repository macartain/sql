#!/usr/bin/ksh
#################################################################################

PROG_NAME=$(basename $0)
LOG_FILE="${PWD}/BILLDETAILS_UK1.$$.log"

#################################################################################
# Logging functions

printLog() {
    NOW=`date '+%d/%m/%y %H:%M:%S'`
    echo "${1}${PROG_NAME}:$NOW > ${2}"
}

printInform() {
    printLog "INFORM----" "${1}"
}

printWarn() {
    printLog "WARN------" "${1}"
}

printError() {
    printLog "ERROR-----" "${1}"
}

#################################################################################
# main

printInform "Starting BILLDETAILS_UK1 process..."

sqlResult=`sqlplus -S ${DATABASE} >${LOG_FILE} << EOF
	set trimout on trimspool on pagesize 5000 linesize 255 verify off
	set serveroutput on size 1000000
	alter session force parallel DDL;
	prompt Starting BILLDETAILS_UK1
	@@rebuildidx_env.sql
	set timing on
	DECLARE
	BEGIN
		migrationCreateIndexParallel('BILLDETAILS', 'BILLDETAILS_UK1', 'ACCOUNT_NUM asc, DOMAIN_ID asc, BILL_SEQ asc, BILL_VERSION asc, REVENUE_START_DAT asc, REVENUE_END_DAT asc, REVENUE_FEED_ID asc, REVENUE_CHARGE_TYPE asc, INVOICED_CHARGE_BOO asc, GROUP_ATTR_1 asc, GROUP_ATTR_2 asc, GROUP_ATTR_3 asc, GROUP_ATTR_4 asc, GROUP_ATTR_5 asc, GROUP_ATTR_6 asc, GROUP_ATTR_7 asc, GROUP_ATTR_8 asc, GROUP_ATTR_9 asc, GROUP_ATTR_10 asc, GROUP_ATTR_11 asc, GROUP_ATTR_12 asc', '&&gBILLDETAILS_UK1', true);
	EXCEPTION
	WHEN OTHERS THEN
		dbms_output.put_line('ERROR : ' || SQLERRM);
	END;
	/
	set timing off
	prompt Done - BILLDETAILS_UK1
	@rebuildidx_report.sql
	exit;
	EOF`

printInform "BILLDETAILS_UK1 Output:"
cat ${LOG_FILE}

cat ${LOG_FILE} | grep -i "ERROR" > /dev/null
if [ $? -eq 0 ] 
then
    printError "ERROR: in BILLDETAILS_UK1 process..."
    printInform "Check ${LOG_FILE} file for more details"
    exit 1
else 
	printInform "BILLDETAILS_UK1 process completed successfully..."
fi

exit 0

