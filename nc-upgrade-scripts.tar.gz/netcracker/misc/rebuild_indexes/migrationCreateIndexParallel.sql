-- ********************************************************
-- File: migrationCreateIndex.sql
--
-- This procedure is currently used by p2p CMERGE as part
-- of single step migration.
--
-- Creates a procedure to handle the creation of indexes in parallel
-- mode at migration time, handling various situations where a
-- similar or conflicting index already exists.
--
-- Based on the variable eRacPartitioned ('F' or 'T') being passed as the
-- parameter to this script, an appropriate version of migrationCreateIndexParallel
-- procedure is created. To accomplish this, the code for this procedure
-- is duplicated and stored in variables v_procedure_sql1 and v_procedure_sql2.
--
-- Version: @(#) (%full_filespec: migrationCreateIndexParallel.sql-2:sql:CB1#31 %)
--
-- Copyright (c) 2008 - 2011 Convergys. All rights reserved.
-- Convergys refers to Convergys Corporation or any of its wholly owned
-- subsidiaries.
-- *********************************************************

declare
    -- Parameter value of variable eRacPartitioned ('F' or 'T')
    v_rac_partitioned       varchar2(1) := upper('&1');

    -- Procedure migrationCreateIndexParallel in a regular (non-partitioned) environment
    v_procedure_sql1        varchar2(32767) := '
create or replace procedure migrationCreateIndexParallel(p_table_name        IN varchar2,
                                                 p_index_name        IN varchar2,
                                                 p_index_column_list IN varchar2,
                                                 p_index_tablespace  IN varchar2,
                                                 p_unique_boo        IN boolean,
                                                 p_rac_partitioned   IN varchar2 := ''F'')
authid current_user
--
-- Creates indexes during migration, handling several situations where conflicting
-- indexes already exist.
--
-- If an index with the same name, the same column list and the same uniqueness
-- as the specified index is found, then it is left unchanged.
--
-- If an index with the same name and a different column list is found, then it
-- is dropped. The specified index is then created.
--
-- If an index with a different name to the specified index, but with the same
-- column list is detected, the uniqueness of the existing index is compared with
-- the specified index. If it matches, it is renamed to match the specified index
-- name, else the existing index is dropped and the specified index created in
-- its place.
--
-- If an index is suffixed with _PK or _UK*, a corresponding primary key or
-- unique constraint is built on the index.
--
-- This procedure runs with invoker rights so that privileges granted through
-- roles are available; this allow the use of DDL commands without additional
-- direct grants to the user.
--
-- Parameters:
--     p_table_name        : Table to create index on
--
--     p_index_name        : Name of index to create
--
--     p_index_column_list : Column list for index. Must be of form:
--         ''COLUMN_NAME1 asc, COLUMN_NAME2 asc''
--         Column names must be uppercase, ''asc'' or ''desc'' must be lowercase,
--         and there must be a single space after each comma, else it will not
--         match correctly with any existing indexes.
--
--     p_index_tablespace  : Tablespace for index
--
--     p_unique_boo        : Whether to create as a unique index
--
as
    e_such_cols_already_indexed     exception;
        pragma EXCEPTION_INIT(e_such_cols_already_indexed, -1408);

    e_existing_object               exception;
        pragma EXCEPTION_INIT(e_existing_object, -955);

    -- Local function getIndexColumns
    --
    -- Parameters:
    --     p_index_name : Name of index for which the column list is required.
    -- Returns:
    --     A string containing the column list of the index, of the form:
    --         COLUMN_NAME1 asc, COLUMN_NAME2 asc
    --
    function getIndexColumns(p_index_name IN varchar2)
    return varchar2
    is
        v_index_column_list varchar2(2000) := '''';
    begin
        for v_index_column in (select   column_name,
                                        descend
                               from     user_ind_columns
                               where    index_name = p_index_name
                               order by column_position)
        loop
            v_index_column_list := v_index_column_list           ||
                                   v_index_column.column_name    ||
                                   '' ''                           ||
                                   LOWER(v_index_column.descend) ||
                                   '', '';
        end loop;
        v_index_column_list := SUBSTR(v_index_column_list,
                                      0,
                                      LENGTH(v_index_column_list) - 2);
        return v_index_column_list;
    end getIndexColumns;

    -- Local function getReplacementIndexName
    --
    -- Parameters:
    --     p_table_name : Table name to create
    -- Returns:
    --     p_table_name with a suffix ''_GOx'' where x is an integer,
    --     such that the name does not conflict with existing objects.
    --
    function getReplacementIndexName(p_table_name IN varchar2)
    return varchar2
    is
        v_suffix_number  number := 1;
        v_number_objects number;
    begin

        loop
            select count(*)
            into   v_number_objects
            from   user_indexes
            where  index_name = p_table_name || ''_GO'' || to_char(v_suffix_number);

            exit when v_number_objects = 0;

            v_suffix_number := v_suffix_number + 1;

        end loop;

        return p_table_name || ''_GO'' || v_suffix_number;

    end getReplacementIndexName;

    -- Local procedure appendDDL
    --
    -- Parameters:
    --     p_index_name        : Name of index for which a DDL statement is
    --                           being sought.
    -- Returns:
    --     A string containing the substringed DDL command,
    --     for recreating a partitioned index.
    --
    function appendDDL(p_index_name IN varchar2)
    return varchar2
    is
        v_statement varchar2(32000);
    begin
        -- Storage parameters begin immediately after the index column list,
        -- beginning with the PCTFREE parameter.
        select substr(DDL_APPEND,
                      instr(DDL_APPEND,
                            ''PCTFREE''))
        into   v_statement
        from   MIGTABLESPACES
        where  OBJECT_NAME = p_index_name;

        return v_statement;
    exception
        when NO_DATA_FOUND then return null;
    end appendDDL;

    -- Local procedure dropIndex
    --
    -- Parameters:
    --     p_table_name        : Table index to be dropped is on
    --     p_index_name        : Name of index to drop
    --     p_tablespace_name   : Tablespace the index is stored in
    --
    procedure dropIndex(p_table_name        IN varchar2,
                        p_index_name        IN varchar2,
                        p_tablespace_name  OUT varchar2)
    is
        e_enforcing_constraint exception;
            PRAGMA EXCEPTION_INIT(e_enforcing_constraint, -2429);
    begin
        select TABLESPACE_NAME
        into   p_tablespace_name
        from   (select TABLESPACE_NAME from USER_SEGMENTS
                where  SEGMENT_NAME = p_index_name
                union
                select TABLESPACE_NAME from USER_INDEXES
                where  INDEX_NAME = p_index_name)
        where rownum = 1;

        execute immediate ''drop index '' || p_index_name;
    exception
        when e_enforcing_constraint then
            declare
                v_table_name      user_constraints.table_name%type;
                v_constraint_name user_constraints.constraint_name%type;
            begin
                select table_name, constraint_name
                into   v_table_name, v_constraint_name
                from   user_constraints
                where  table_name = p_table_name
                and    index_name = p_index_name;

                execute immediate ''alter table ''      || v_table_name ||
                                  '' drop constraint '' || v_constraint_name ||
                                  '' drop index'';
            end;
    end dropIndex;

    -- Local procedure createIndex
    --
    -- Parameters:
    --     p_table_name        : Table to create index on
    --     p_index_name        : Name of index to create
    --     p_index_column_list : Column list for index
    --     p_index_tablespace  : Tablespace for index
    --     p_unique_boo        : Whether to create as a unique index
    --
    procedure createIndex(p_table_name        IN varchar2,
                          p_index_name        IN varchar2,
                          p_index_column_list IN varchar2,
                          p_index_tablespace  IN varchar2,
                          p_unique_boo        IN boolean)
    is
        v_unique_clause       varchar2(7)   := '''';
        v_index_column_output varchar2(255) := '''';
        v_index_tablespace    varchar2(255);
    begin
        if p_unique_boo then
            v_unique_clause := ''unique '';
        end if;

        if p_index_tablespace is not null then
            v_index_tablespace := ''tablespace '' || p_index_tablespace;
        end if;

        if length(p_index_column_list) > 100 then
            v_index_column_output := substr(p_index_column_list,1,100) || ''...'';
        else
            v_index_column_output := p_index_column_list;
        end if;

        dbms_output.put_line(''Creating ''           ||
                             v_unique_clause       ||
                             ''index ''              ||
                             p_index_name          ||
                             '' on table ''          ||
                             p_table_name          ||
                             '' (''                  ||
                             v_index_column_output ||
                             '') parallel ''        ||
                             &&gIndexDegreeOfParallelism);
                             --'' nologging '');

        -- ''compute statistics'' clause removed, as not needed at Oracle 10g.
        -- appendDDL can return null where an index is not partitioned.
        execute immediate ''create ''           ||
                          v_unique_clause     ||
                          ''index ''            ||
                          p_index_name        ||
                          '' on ''              ||
                          p_table_name        ||
                          ''(''                 ||
                          p_index_column_list ||
                          '')  parallel ''               ||
                          &&gIndexDegreeOfParallelism ||
                          --'' nologging '' ||
                          nvl(appendDDL(p_index_name), v_index_tablespace);

        if p_index_name like ''%\_PK'' escape ''\'' then
            execute immediate ''alter table '' || p_table_name ||
                              '' add constraint '' || p_index_name ||
                              '' primary key ('' ||
                              replace(
                                  replace(p_index_column_list, '' asc'', ''''),
                                  '' desc'',
                                  '''') ||
                              '')'' || '' using index ''||p_index_name;
        elsif p_index_name like ''%\_UK%'' escape ''\'' then
            execute immediate ''alter table '' || p_table_name ||
                              '' add constraint '' || p_index_name ||
                              '' unique ('' ||
                              replace(
                                  replace(p_index_column_list, '' asc'', ''''),
                                  '' desc'',
                                  '''') ||
                              '')'' || '' using index ''||p_index_name;
        end if;

        if p_index_name not like ''TMP%'' then
            execute immediate ''alter index '' || p_index_name ||
                                '' parallel 1 logging'';
        end if;

        dbms_output.put_line(''Index created.'');
    end createIndex;

    --
    -- An index on the same columns already exists.
    --
    -- Find the index;
    --   If the uniqueness matches, then rename it to match a standard schema.
    --   If uniqueness does not match, then drop and recreate the index, as
    --    uniqueness cannot be altered with an ALTER INDEX command.
    --
    procedure handleAlreadyIndexed(p_table_name        IN varchar2,
                                   p_index_name        IN varchar2,
                                   p_index_column_list IN varchar2,
                                   p_unique_boo        IN boolean)
    is
        v_index_tablespace varchar2(30);
    begin
        dbms_output.put_line(''An index already exists on this column list. Searching for this index...'');

        for v_index in (select   index_name,
                                 uniqueness,
                                 decode(degree, ''DEFAULT'', ''1'', degree) degree
                        from     user_indexes
                        where    table_name = p_table_name
                        order by index_name)
        loop
            if p_index_column_list = getIndexColumns(v_index.index_name) then

                if (    p_unique_boo and v_index.uniqueness = ''UNIQUE'')
                or (not p_unique_boo and v_index.uniqueness = ''NONUNIQUE'')
                then
                    dbms_output.put_line(''Index ''                                         ||
                                         v_index.index_name                               ||
                                         '' matches required column list and uniqueness.'');

                    dbms_output.put_line(''Renaming index ''  ||
                                         v_index.index_name ||
                                         '' to ''             ||
                                         p_index_name);

                    execute immediate ''alter index ''     ||
                                      v_index.index_name ||
                                      '' rename to ''      ||
                                      p_index_name;

                else
                    dbms_output.put_line(''Index ''                                                        ||
                                         v_index.index_name                                              ||
                                         '' matches required column list, but does not match uniqueness.'');

                    dbms_output.put_Line(''Dropping index ''   ||
                                          v_index.index_name ||
                                         '' and recreating... '');

                    dropIndex(p_table_name, v_index.index_name, v_index_tablespace);
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_index.degree;
                    end if;
                end if;

                exit;

            end if;

        end loop;

    end handleAlreadyIndexed;

    --
    -- An index with the same name already exists.
    --
    -- It may have the same column list - if it does, then check uniqueness.
    --     If the uniqueness matches, then no change is required.
    --     If it does not, then drop the existing index and recreate the index.
    -- If it does not have the same column list, rename it and create the correct index.
    --
    procedure handleExistingObject(p_table_name        IN varchar2,
                                   p_index_name        IN varchar2,
                                   p_index_column_list IN varchar2,
                                   p_unique_boo        IN boolean)
    is
        v_index_tablespace varchar2(30);
        v_existing_index_table_name varchar2(30);
        v_constraint_exist number(1);

        v_existing_uniqueness       USER_INDEXES.uniqueness%TYPE;

        e_such_cols_already_indexed exception;
            pragma EXCEPTION_INIT(e_such_cols_already_indexed, -1408);
        v_degree varchar2(40);

    begin
        dbms_output.put_line(''An index named '' ||
                             p_index_name      ||
                             '' already exists. Checking if it matches required definition...'');

        select table_name,
               uniqueness,
               decode(degree, ''DEFAULT'', ''1'', degree)
        into   v_existing_index_table_name,
               v_existing_uniqueness,
               v_degree
        from   user_indexes
        where  index_name = p_index_name;

        select count(1)
        into   v_constraint_exist
        from   user_constraints
        where  table_name = p_table_name
        and    index_name = p_index_name
        and    constraint_name = p_index_name;

        if   v_existing_index_table_name = p_table_name
        and  p_index_column_list = getIndexColumns(p_index_name) then

            if (    p_unique_boo and v_existing_uniqueness = ''UNIQUE'' and v_constraint_exist = 1)
            or (not p_unique_boo and v_existing_uniqueness = ''NONUNIQUE'' and v_constraint_exist = 0)
            then
                dbms_output.put_line(''Index definition matches, leaving index unchanged.'');
            elsif (    p_unique_boo and v_existing_uniqueness = ''UNIQUE'' and v_constraint_exist = 0) then
                dbms_output.put_line(''Index definition matches, but no constraint present.'');
                dbms_output.put_line(''Creating constraint.'');

                   if p_index_name like ''%\_PK'' escape ''\'' then
                        execute immediate ''alter table '' || p_table_name ||
                                      '' add constraint '' || p_index_name ||
                                      '' primary key ('' ||
                                      replace(
                                          replace(p_index_column_list, '' asc'', ''''),
                                          '' desc'',
                                          '''') ||
                                      '')'' || '' using index ''||p_index_name;
                elsif p_index_name like ''%\_UK%'' escape ''\'' then
                        execute immediate ''alter table '' || p_table_name ||
                                      '' add constraint '' || p_index_name ||
                                      '' unique ('' ||
                                      replace(
                                          replace(p_index_column_list, '' asc'', ''''),
                                          '' desc'',
                                          '''') ||
                                      '')'' || '' using index ''||p_index_name;
                end if;
            else
                dbms_output.put_line(''Index column list matches, but uniqueness does not.'');
                dbms_output.put_line(''Dropping existing index and creating new index.'');

                dropIndex(p_table_name, p_index_name, v_index_tablespace);
                dbms_output.put_line(''Index '' || p_index_name || '' dropped.'');

                dbms_output.put_line(''Retrying index creation...'');

                begin
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_degree;
                    end if;
                exception
                    when e_such_cols_already_indexed then
                        handleAlreadyIndexed(p_table_name,
                                             p_index_name,
                                             p_index_column_list,
                                             p_unique_boo);
                    when others then
                        raise;
                end;
            end if;

        else

            begin
                dbms_output.put_line(''Index definition does not match. Dropping index'');
                dropIndex(v_existing_index_table_name, p_index_name, v_index_tablespace);
                dbms_output.put_line(''Retrying index creation...'');

                begin
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_degree;
                    end if;
                exception
                    when e_such_cols_already_indexed then
                        handleAlreadyIndexed(p_table_name,
                                             p_index_name,
                                             p_index_column_list,
                                             p_unique_boo);
                    when others then
                        raise;
                end;
            end;

        end if;

    end handleExistingObject;

begin
    dbms_output.enable(1000000);

    --
    -- In a regular (non-partitioned) environment, (re)create the index.
    --
    createIndex(p_table_name,
                p_index_name,
                p_index_column_list,
                p_index_tablespace,
                p_unique_boo);

exception
    when e_such_cols_already_indexed then
        handleAlreadyIndexed(p_table_name,
                             p_index_name,
                             p_index_column_list,
                             p_unique_boo);

    when e_existing_object then
        handleExistingObject(p_table_name,
                             p_index_name,
                             p_index_column_list,
                             p_unique_boo);

    when others then
        raise;

end migrationCreateIndexParallel;';

    -- procedure migrationCreateIndexParallel in a partitioned environment
    v_procedure_sql2        varchar2(32767) := '
create or replace procedure migrationCreateIndexParallel(p_table_name        IN varchar2,
                                                 p_index_name        IN varchar2,
                                                 p_index_column_list IN varchar2,
                                                 p_index_tablespace  IN varchar2,
                                                 p_unique_boo        IN boolean,
                                                 p_rac_partitioned   IN varchar2 := ''F'')
authid current_user
--
-- Creates indexes during migration, handling several situations where conflicting
-- indexes already exist.
--
-- If an index with the same name, the same column list and the same uniqueness
-- as the specified index is found, then it is left unchanged.
--
-- If an index with the same name and a different column list is found, then it
-- is dropped. The specified index is then created.
--
-- If an index with a different name to the specified index, but with the same
-- column list is detected, the uniqueness of the existing index is compared with
-- the specified index. If it matches, it is renamed to match the specified index
-- name, else the existing index is dropped and the specified index created in
-- its place.
--
-- If an index is suffixed with _PK or _UK*, a corresponding primary key or
-- unique constraint is built on the index.
--
-- This procedure runs with invoker rights so that privileges granted through
-- roles are available; this allow the use of DDL commands without additional
-- direct grants to the user.
--
-- Parameters:
--     p_table_name        : Table to create index on
--
--     p_index_name        : Name of index to create
--
--     p_index_column_list : Column list for index. Must be of form:
--         ''COLUMN_NAME1 asc, COLUMN_NAME2 asc''
--         Column names must be uppercase, ''asc'' or ''desc'' must be lowercase,
--         and there must be a single space after each comma, else it will not
--         match correctly with any existing indexes.
--
--     p_index_tablespace  : Tablespace for index
--
--     p_unique_boo        : Whether to create as a unique index
--
as
    e_such_cols_already_indexed     exception;
        pragma EXCEPTION_INIT(e_such_cols_already_indexed, -1408);

    e_existing_object               exception;
        pragma EXCEPTION_INIT(e_existing_object, -955);

    v_index_partitioned             varchar2(1) := ''F'';

    -- Local function getIndexColumns
    --
    -- Parameters:
    --     p_index_name : Name of index for which the column list is required.
    -- Returns:
    --     A string containing the column list of the index, of the form:
    --         COLUMN_NAME1 asc, COLUMN_NAME2 asc
    --
    function getIndexColumns(p_index_name IN varchar2)
    return varchar2
    is
        v_index_column_list varchar2(2000) := '''';
    begin
        for v_index_column in (select   column_name,
                                        descend
                               from     user_ind_columns
                               where    index_name = p_index_name
                               order by column_position)
        loop
            v_index_column_list := v_index_column_list           ||
                                   v_index_column.column_name    ||
                                   '' ''                           ||
                                   LOWER(v_index_column.descend) ||
                                   '', '';
        end loop;
        v_index_column_list := SUBSTR(v_index_column_list,
                                      0,
                                      LENGTH(v_index_column_list) - 2);
        return v_index_column_list;
    end getIndexColumns;

    -- Local function getReplacementIndexName
    --
    -- Parameters:
    --     p_table_name : Table name to create
    -- Returns:
    --     p_table_name with a suffix ''_GOx'' where x is an integer,
    --     such that the name does not conflict with existing objects.
    --
    function getReplacementIndexName(p_table_name IN varchar2)
    return varchar2
    is
        v_suffix_number  number := 1;
        v_number_objects number;
    begin

        loop
            select count(*)
            into   v_number_objects
            from   user_indexes
            where  index_name = p_table_name || ''_GO'' || to_char(v_suffix_number);

            exit when v_number_objects = 0;

            v_suffix_number := v_suffix_number + 1;

        end loop;

        return p_table_name || ''_GO'' || v_suffix_number;

    end getReplacementIndexName;

    -- Local procedure appendDDL
    --
    -- Parameters:
    --     p_index_name        : Name of index for which a DDL statement is
    --                           being sought.
    -- Returns:
    --     A string containing the substringed DDL command,
    --     for recreating a partitioned index.
    --
    function appendDDL(p_index_name IN varchar2)
    return varchar2
    is
        v_statement varchar2(32000);
    begin
        -- Storage parameters begin immediately after the index column list,
        -- beginning with the PCTFREE parameter.
        select substr(DDL_APPEND,
                      instr(DDL_APPEND,
                            ''PCTFREE''))
        into   v_statement
        from   MIGTABLESPACES
        where  OBJECT_NAME = p_index_name;

        return v_statement;
    exception
        when NO_DATA_FOUND then return null;
    end appendDDL;

    -- Local procedure dropIndex
    --
    -- Parameters:
    --     p_table_name        : Table index to be dropped is on
    --     p_index_name        : Name of index to drop
    --     p_tablespace_name   : Tablespace the index is stored in
    --
    procedure dropIndex(p_table_name        IN varchar2,
                        p_index_name        IN varchar2,
                        p_tablespace_name  OUT varchar2)
    is
        e_enforcing_constraint exception;
            PRAGMA EXCEPTION_INIT(e_enforcing_constraint, -2429);
    begin
        select TABLESPACE_NAME
        into   p_tablespace_name
        from   (select TABLESPACE_NAME from USER_SEGMENTS
                where  SEGMENT_NAME = p_index_name
                union
                select TABLESPACE_NAME from USER_INDEXES
                where  INDEX_NAME = p_index_name)
        where rownum = 1;

        execute immediate ''drop index '' || p_index_name;
    exception
        when e_enforcing_constraint then
            declare
                v_table_name      user_constraints.table_name%type;
                v_constraint_name user_constraints.constraint_name%type;
            begin
                select table_name, constraint_name
                into   v_table_name, v_constraint_name
                from   user_constraints
                where  table_name = p_table_name
                and    index_name = p_index_name;

                execute immediate ''alter table ''      || v_table_name ||
                                  '' drop constraint '' || v_constraint_name ||
                                  '' drop index'';
            end;
    end dropIndex;

    -- Local procedure createIndex
    --
    -- Parameters:
    --     p_table_name        : Table to create index on
    --     p_index_name        : Name of index to create
    --     p_index_column_list : Column list for index
    --     p_index_tablespace  : Tablespace for index
    --     p_unique_boo        : Whether to create as a unique index
    --
    procedure createIndex(p_table_name        IN varchar2,
                          p_index_name        IN varchar2,
                          p_index_column_list IN varchar2,
                          p_index_tablespace  IN varchar2,
                          p_unique_boo        IN boolean)
    is
        v_unique_clause       varchar2(7)   := '''';
        v_index_column_output varchar2(255) := '''';
        v_index_tablespace    varchar2(255);
    begin
        if p_unique_boo then
            v_unique_clause := ''unique '';
        end if;

        if p_index_tablespace is not null then
            v_index_tablespace := ''tablespace '' || p_index_tablespace;
        end if;

        if length(p_index_column_list) > 100 then
            v_index_column_output := substr(p_index_column_list,1,100) || ''...'';
        else
            v_index_column_output := p_index_column_list;
        end if;

        dbms_output.put_line(''Creating ''           ||
                             v_unique_clause       ||
                             ''index ''              ||
                             p_index_name          ||
                             '' on table ''          ||
                             p_table_name          ||
                             '' (''                  ||
                             v_index_column_output ||
                             '') parallel ''       ||
                             &&gIndexDegreeOfParallelism); 
                             --'' nologging '');

        -- ''compute statistics'' clause removed, as not needed at Oracle 10g.
        -- appendDDL can return null where an index is not partitioned.
        execute immediate ''create ''           ||
                          v_unique_clause     ||
                          ''index ''            ||
                          p_index_name        ||
                          '' on ''              ||
                          p_table_name        ||
                          ''(''                 ||
                          p_index_column_list ||
                          '') parallel  ''               ||
                          &&gIndexDegreeOfParallelism || 
                          --'' nologging '' ||
                          nvl(appendDDL(p_index_name), v_index_tablespace);

        if p_index_name like ''%\_PK'' escape ''\'' then
            execute immediate ''alter table '' || p_table_name ||
                              '' add constraint '' || p_index_name ||
                              '' primary key ('' ||
                              replace(
                                  replace(p_index_column_list, '' asc'', ''''),
                                  '' desc'',
                                  '''') ||
                              '')'' || '' using index ''||p_index_name;
        elsif p_index_name like ''%\_UK%'' escape ''\'' then
            execute immediate ''alter table '' || p_table_name ||
                              '' add constraint '' || p_index_name ||
                              '' unique ('' ||
                              replace(
                                  replace(p_index_column_list, '' asc'', ''''),
                                  '' desc'',
                                  '''') ||
                              '')'' || '' using index ''||p_index_name;
        end if;

        if p_index_name not like ''TMP%'' then
            execute immediate ''alter index '' || p_index_name ||
                                '' parallel 1 logging'';
        end if;

        dbms_output.put_line(''Index created.'');
    end createIndex;

    --
    -- An index on the same columns already exists.
    --
    -- Find the index;
    --   If the uniqueness matches, then rename it to match a standard schema.
    --   If uniqueness does not match, then drop and recreate the index, as
    --    uniqueness cannot be altered with an ALTER INDEX command.
    --
    procedure handleAlreadyIndexed(p_table_name        IN varchar2,
                                   p_index_name        IN varchar2,
                                   p_index_column_list IN varchar2,
                                   p_unique_boo        IN boolean)
    is
        v_index_tablespace varchar2(30);
    begin
        dbms_output.put_line(''An index already exists on this column list. Searching for this index...'');

        for v_index in (select   index_name,
                                 uniqueness,
                                 decode(degree, ''DEFAULT'', ''1'', degree) degree
                        from     user_indexes
                        where    table_name = p_table_name
                        order by index_name)
        loop
            if p_index_column_list = getIndexColumns(v_index.index_name) then

                if (    p_unique_boo and v_index.uniqueness = ''UNIQUE'')
                or (not p_unique_boo and v_index.uniqueness = ''NONUNIQUE'')
                then
                    dbms_output.put_line(''Index ''                                         ||
                                         v_index.index_name                               ||
                                         '' matches required column list and uniqueness.'');

                    dbms_output.put_line(''Renaming index ''  ||
                                         v_index.index_name ||
                                         '' to ''             ||
                                         p_index_name);

                    execute immediate ''alter index ''     ||
                                      v_index.index_name ||
                                      '' rename to ''      ||
                                      p_index_name;

                else
                    dbms_output.put_line(''Index ''                                                        ||
                                         v_index.index_name                                              ||
                                         '' matches required column list, but does not match uniqueness.'');

                    dbms_output.put_Line(''Dropping index ''   ||
                                          v_index.index_name ||
                                         '' and recreating... '');

                    dropIndex(p_table_name, v_index.index_name, v_index_tablespace);
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_index.degree;
                    end if;
                end if;

                exit;

            end if;

        end loop;

    end handleAlreadyIndexed;

    --
    -- An index with the same name already exists.
    --
    -- It may have the same column list - if it does, then check uniqueness.
    --     If the uniqueness matches, then no change is required.
    --     If it does not, then drop the existing index and recreate the index.
    -- If it does not have the same column list, rename it and create the correct index.
    --
    procedure handleExistingObject(p_table_name        IN varchar2,
                                   p_index_name        IN varchar2,
                                   p_index_column_list IN varchar2,
                                   p_unique_boo        IN boolean)
    is
        v_index_tablespace varchar2(30);
        v_existing_index_table_name varchar2(30);
        v_constraint_exist number(1);

        v_existing_uniqueness       USER_INDEXES.uniqueness%TYPE;

        e_such_cols_already_indexed exception;
            pragma EXCEPTION_INIT(e_such_cols_already_indexed, -1408);
        v_degree varchar2(40);
    begin
        dbms_output.put_line(''An index named '' ||
                             p_index_name      ||
                             '' already exists. Checking if it matches required definition...'');

        select table_name,
               uniqueness,
               decode(degree, ''DEFAULT'', ''1'', degree)
        into   v_existing_index_table_name,
               v_existing_uniqueness,
               v_degree
        from   user_indexes
        where  index_name = p_index_name;

        select count(1)
        into   v_constraint_exist
        from   user_constraints
        where  table_name = p_table_name
        and    index_name = p_index_name
        and    constraint_name = p_index_name;

        if   v_existing_index_table_name = p_table_name
        and  p_index_column_list = getIndexColumns(p_index_name) then

            if (    p_unique_boo and v_existing_uniqueness = ''UNIQUE'' and v_constraint_exist = 1)
            or (not p_unique_boo and v_existing_uniqueness = ''NONUNIQUE'' and v_constraint_exist = 0)
            then
                dbms_output.put_line(''Index definition matches, leaving index unchanged.'');
            elsif (    p_unique_boo and v_existing_uniqueness = ''UNIQUE'' and v_constraint_exist = 0) then
                dbms_output.put_line(''Index definition matches, but no constraint present.'');
                dbms_output.put_line(''Creating constraint.'');

                   if p_index_name like ''%\_PK'' escape ''\'' then
                        execute immediate ''alter table '' || p_table_name ||
                                      '' add constraint '' || p_index_name ||
                                      '' primary key ('' ||
                                      replace(
                                          replace(p_index_column_list, '' asc'', ''''),
                                          '' desc'',
                                          '''') ||
                                      '')'' || '' using index ''||p_index_name;
                elsif p_index_name like ''%\_UK%'' escape ''\'' then
                        execute immediate ''alter table '' || p_table_name ||
                                      '' add constraint '' || p_index_name ||
                                      '' unique ('' ||
                                      replace(
                                          replace(p_index_column_list, '' asc'', ''''),
                                          '' desc'',
                                          '''') ||
                                      '')'' || '' using index ''||p_index_name;
                end if;
            else
                dbms_output.put_line(''Index column list matches, but uniqueness does not.'');
                dbms_output.put_line(''Dropping existing index and creating new index.'');

                dropIndex(p_table_name, p_index_name, v_index_tablespace);
                dbms_output.put_line(''Index '' || p_index_name || '' dropped.'');

                dbms_output.put_line(''Retrying index creation...'');

                begin
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_degree;
                    end if;
                exception
                    when e_such_cols_already_indexed then
                        handleAlreadyIndexed(p_table_name,
                                             p_index_name,
                                             p_index_column_list,
                                             p_unique_boo);
                    when others then
                        raise;
                end;
            end if;

        else

            begin
                dbms_output.put_line(''Index definition does not match. Dropping index'');
                dropIndex(v_existing_index_table_name, p_index_name, v_index_tablespace);
                dbms_output.put_line(''Retrying index creation...'');

                begin
                    createIndex(p_table_name, p_index_name, p_index_column_list, v_index_tablespace, p_unique_boo);

                    if p_index_name not like ''TMP%'' then
                        execute immediate ''alter index '' || p_index_name ||
                                            '' parallel '' || v_degree;
                    end if;
                exception
                    when e_such_cols_already_indexed then
                        handleAlreadyIndexed(p_table_name,
                                             p_index_name,
                                             p_index_column_list,
                                             p_unique_boo);
                    when others then
                        raise;
                end;
            end;

        end if;

    end handleExistingObject;

begin
    dbms_output.enable(1000000);

    select decode(count(*), 0, ''F'', ''T'')
    into    v_index_partitioned
    from    user_part_indexes
    where   index_name = p_index_name;

    --
    -- In a partitioned environment, if the index is partitioned,
    -- invoke Partition Manager to (re)create the partitioned index.
    --
    if p_rac_partitioned = ''T'' and v_index_partitioned = ''T'' then
        dbms_output.put_line(''Invoking Partition Manager...'');
        partitionmanager.migrationPartitionIndex(p_table_name,
                                                p_index_name,
                                                p_index_column_list,
                                                p_index_tablespace,
                                                p_unique_boo);
        return;
    end if;

    --
    -- In a regular (non-partitioned) environment, (re)create the index.
    --
    createIndex(p_table_name,
                p_index_name,
                p_index_column_list,
                p_index_tablespace,
                p_unique_boo);

exception
    when e_such_cols_already_indexed then
        handleAlreadyIndexed(p_table_name,
                             p_index_name,
                             p_index_column_list,
                             p_unique_boo);

    when e_existing_object then
        handleExistingObject(p_table_name,
                             p_index_name,
                             p_index_column_list,
                             p_unique_boo);

    when others then
        raise;

end migrationCreateIndexParallel;';

begin
    if v_rac_partitioned = 'F' then
        -- Create migrationCreateIndexParallel procedure in a
        -- regular (non-partitioned) environment
        execute immediate v_procedure_sql1;
    elsif v_rac_partitioned = 'T' then
        -- Create migrationCreateIndexParallel procedure in a
        -- partitioned environment
        execute immediate v_procedure_sql2;
    end if;

exception
    when others then
        raise;
end;
/
commit;

show errors procedure migrationCreateIndexParallel;
