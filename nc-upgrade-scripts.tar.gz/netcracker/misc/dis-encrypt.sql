call data_security_mask.deleteMaskedField_1('RB_HOLDINGACCOUNT_BANK_ACCOUNT_NUMBER','Installer');
call data_security_mask.deleteMaskedField_1('RB_PRMANDATE_BANK_ACCOUNT_NUMBER','Installer');
call data_security_mask.deleteMaskedField_1('RB_PRMANDATE_CARD_NUMBER','Installer');

call data_security_mask.addMaskedField_1('RB_HOLDINGACCOUNT_BANK_ACCOUNT_NUMBER','false','FROM_RIGHT', 4,'*','Installer');
call data_security_mask.addMaskedField_1('RB_PRMANDATE_BANK_ACCOUNT_NUMBER','false','FROM_RIGHT', 4,'*','Installer');
call data_security_mask.addMaskedField_1('RB_PRMANDATE_CARD_NUMBER','false','FROM_RIGHT', 4,'*','Installer');
