grant select any dictionary to unif_admin;
grant select any dictionary to ipf_admin;
grant select any dictionary to inf_admin;

grant execute on ipf_admin.sysreg to GENEVA_ADMIN;                                              
grant execute on ipf_admin.sysreg to IPF_AUDIT_ADMIN;                                           
grant execute on ipf_admin.sysreg to GENEVAADMIN;                                               
grant execute on ipf_admin.sysreg to INFINYS_PF;                                                
grant execute on ipf_admin.sysreg to PF_UPDATE_ROLE_UNIF_ADMIN;                                             
create or replace synonym GENEVA_ADMIN.SYSREG for IPF_ADMIN.SYSREG;                                               
create or replace synonym INF_ADMIN.SYSREG for IPF_ADMIN.SYSREG;                                            
create or replace synonym IPF_AUDIT_ADMIN.SYSREG for IPF_ADMIN.SYSREG;                                            
create or replace synonym UNIF_ADMIN.SYSREG for IPF_ADMIN.SYSREG;                                           
create or replace public synonym SYSREG for IPF_ADMIN.SYSREG;                                               
grant execute on DBMS_RULE_ADM to public with grant option;
grant execute on DBMS_STREAMS to public with grant option;

