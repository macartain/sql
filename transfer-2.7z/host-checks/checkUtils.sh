#!/bin/ksh

# utility functions for checks

# function that records that a test has passed
function logSuccess {

    typeset testName comments

    testName=$1
    comments=$2

    echo "TEST $testName $comments PASSED" >> $RESULT_FILE
}


# function that records that a test has failed
function logFailure {

    typeset testName comments

    testName=$1
    comments=$2

    echo "TEST $testName $comments FAILED" >> $RESULT_FILE
}

# function that records an information message
function logInform {

    typeset testName comments

    testName=$1
    comments=$2

    echo "INFORM $testName $comments" >> $RESULT_FILE
}

function logWarning {

    typeset testName comments

    testName=$1
    comments=$2

    echo "TEST $testName $comments WARN" >> $RESULT_FILE
}

# utility function (not used directly as a check) to compare 2 version numbers A and B, each of the
# form x.y.z etc. (either version number can have any number of parts, and the separators can be
# full stop, dash or underscore).  It is driven by version A.
#
# Returns 0: if they are the same
#         1: if A is less than B
#         2: if A is greater than B
#
# (I would have prefered returning -1, 0 or 1, but ksh functions can't return negative numbers)

function compareVersions {

    typeset versionA versionB

    echo "comparing versions A = $1, and B = $2"

    IFS="._-"
    set -A versionA $1
    set -A versionB $2
    unset IFS

    echo "version A has" ${#versionA[*]} "part[s] and the version B has" ${#versionB[*]} "part[s]"

    # compare bits of version number, starting with the most significant (left-hand):
    # as soon as the found version is less than the corresponding part of the minimum version, that's an error
    # as soon as the found version is greater than the corresponding part of the minimum version, that's success
    i=0
    while [[ $i -lt ${#versionA[*]} ]]
    do
      echo "comparing ${versionA[$i]} from version A with ${versionB[$i]} from version B"

      # check the next place in the version numbers
      if [[ ${versionA[$i]} -lt ${versionB[$i]} ]]; then
	  echo "${versionA[$i]} is less than ${versionB[$i]}"
	  versionComparison=1
	  return
      else
	  if [[ ${versionA[$i]} -gt ${versionB[$i]} ]]; then
	      echo "${versionA[$i]} is greater than ${versionB[$i]}"
	      versionComparison=2
	      return
	  fi
      fi

      i=$(( $i+1 ))
    done

    # if we get to here, they're the same
    echo "versions are the same"

    versionComparison=0
}

