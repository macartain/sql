#!/bin/ksh

# list of checks to perform on machines to see if they're ready for installing Infinys
#
# called from master.sh
#
# Bob Salmon
# 19th May 2010
#


scriptPath=${0%/*}
. $scriptPath/checkUtils.sh
. $scriptPath/db_checks.sh

function cpucheck {

    typeset tmpfile tmpfile2 numCores coreSpeed

    numCores=$1
    coreSpeed=$2

    tmpfile=$TEMP_DIR/cores
    tmpfile2=$TEMP_DIR/cores2

    print "checking that there are at least $numCores cores, each with clock speed at least $coreSpeed GHz"

    # get an unsorted list of core speeds, and number of cores with that speed
    # some /proc/cpuinfo have a line that says the number of cores in this CPU, and others don't
    # (where all CPUs have only 1 core).

    # Therefore default the number of cores per CPU to 1, and process the sections in the file
    # retrospectively.  I.e. if you come across a cores-per-CPU line, store its value.  When you come across
    # a CPU speed line, store the new value away.  When you come across a gap between sections, update the
    # proper totals with the previous CPU speed value and previous cores-per-CPU value.
    # Remember to flush at the end of the file.

    awk 'BEGIN         {numCores=1; speed=-1}
         /^model name/ {x=index($NF,"G"); speed=substr($NF,1,x-1)}
         /^cpu cores/  {numCores=$NF}
	 /^\s*$/       {if (speed > 0) {cores[speed]+=numCores; speed=-1}}
         END           {if (speed > 0) {core[speed]+=numCores};
                        for (i in cores) {printf "%f %d\n", i, cores[i];}}' /proc/cpuinfo > $tmpfile

    # sort it, fastest first
    sort -r $tmpfile > $tmpfile2

    # Work through the list of cores, starting with the fastest.  For each group of cores, if the speed
    # is fast enough, take the number in the group off the total needed.  If there aren't enough in this
    # group, move onto the next fastest group etc.
    awk 'BEGIN {numCoresLeft='$numCores'; totalCoresNeeded='$numCores'; minSpeed='$coreSpeed'} \
               {if ((numCoresLeft > 0) && (minSpeed <= $1)) {numCoresLeft -= $2}} \
         END   {if (numCoresLeft <= 0) {printf "TEST CPU need %d core[s] of at least %f GHz PASSED\n", \
                                               totalCoresNeeded, minSpeed} else \
                {numCoresFound=totalCoresNeeded-numCoresLeft; \
                 printf "TEST CPU need %d cores of at least %f GHz, only found %d: FAILED\n", \
                 totalCoresNeeded, minSpeed, numCoresFound}}' $tmpfile2 >> $RESULT_FILE
}


# A check on free memory, in Gigabytes (supports decimal places)
function memorycheck {

    typeset memoryNeededGigs memoryFreeGigs tmpFile
    typeset -i memoryNeededk memoryFreek kPerGig

    # memory needed in gigabytes
    memoryNeededGigs=$1
    print "memorycheck"
    print "needed gigs  " $memoryNeededGigs

    kPerGig=1048576                        # go via k rather than bytes to reduce the risk of overflow

    memoryNeededk=$(( $memoryNeededGigs*$kPerGig ))
    print "needed k     " $memoryNeededk

    memoryFreek=`free | awk '{if ($1 == "Mem:") {print $4}}'`
    print "free k       " $memoryFreek

    memoryFreeGigs=`echo "2 k $memoryFreek $kPerGig / p" | dc`
    print "free gigs    " $memoryFreeGigs

    tmpFile=$TEMP_DIR/memcheck
    if [[ $memoryNeededk -lt $memoryFreek ]]; then
	printf "looking for at least %0.2f Gb (%d k) and found %0.2f Gb (%d k)" $memoryNeededGigs $memoryNeededk $memoryFreeGigs $memoryFreek > $tmpFile
        logSuccess memorycheck "`cat $tmpFile`"
    else
        printf "looking for at least %0.2f Gb (%d k) and found only %0.2f Gb (%d k)" $memoryNeededGigs $memoryNeededk $memoryFreeGigs $memoryFreek > $tmpFile
	logFailure memoryCheck "`cat $tmpFile`"
    fi
}


function subnetcheck {

    typeset clusterName ipAddr subnet

    clusterName=$1

    print "about to get IP address via tracepath $MASTER_NAME ..."
    ipAddr=`tracepath $MASTER_NAME | head -1 | awk '{print $3}' | tr -d '()'`

    subnet=${ipAddr%.+(\d)}

    echo "$clusterName $subnet" > $RESULT_DIR/subnet.`hostname`
}

# Checks that Perl is installed, with the minimum version as specified
function perlVersion {

    typeset neededVersion whichPerl noPerl perlText foundVersion result

    neededVersion=$1

    if [[ $# -ne 1 ]]; then
	logFailure perlVersion "bad arguments in config file: need 1 arg = minimumum Perl version"
	return
    fi

    echo "looking for Perl version $neededVersion"

    if [[ "${PERL_HOME}" = "" ]]; then
	logFailure perlVersion "please set PERL_HOME in the checks' config file"
	return
    fi

    # get its version, stripping off leading "v"
    foundVersion=`${PERL_HOME}/bin/perl -v | grep 'This is perl' | awk '{print $4}' | tr -d 'v'`

    echo "found Perl version $foundVersion"

    # compare the found version to the needed version
    compareVersions "$neededVersion" "$foundVersion"

    echo "got $versionComparison from compareVersions of Perl"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure perlVersion "looking for Perl version $neededVersion or greater, but found $foundVersion"
    else
	logSuccess perlVersion "looking for Perl version $neededVersion or greater, and found $foundVersion"
    fi

}

function perlModuleVersion {
    
    typeset moduleName result neededVersion tmpFile tmpFile2

    if [[ $# -ne 2 ]]; then
	logFailure perlModuleVersion "bad arguments in config file: need 2 args = module name, minimumum version"
	return
    fi

    moduleName=$1
    neededVersion=$2

    print "looking for version $neededVersion of $moduleName"

    tmpFile=$TEMP_DIR/perlModuleVersion
    tmpFile2=$TEMP_DIR/perlModuleVersion2

    if [[ "${PERL_HOME}" = "" ]]; then
	logFailure "please set PERL_HOME in the checks' config file"
	return
    fi

    # need to use sed to strip out non-printing control characters
    ${PERL_HOME}/bin/perldoc perllocal | sed -e 's/.//g' > $tmpFile

    awk 'BEGIN {prevModule=""; neededModule="'$moduleName'"}
	 /"Module"/ {prevModule=$7}
	 /"VERSION:/ {if (neededModule==prevModule) {print $3} }' $tmpFile > $tmpFile2

    result=`cat $tmpFile2 | tr -d '"'`

    print "got '$result' as module version"

    if [[ "$result" = "" ]]; then
	logFailure perlModuleVersion "looking for at least version $neededVersion of module $moduleName, cannot find the module at all"
	return
    fi

    compareVersions "$neededVersion" "$result"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure perlModuleVersion "looking for Perl module $neededVersion of module $moduleName, but found version $result"
    else
	logSuccess perlModuleVersion "looking for Perl module $neededVersion of module $moduleName, and found version $result"
    fi
}


function javaVersion {

    typeset checkingCommand neededVersion foundVersion outFile

    if [[ $# -ne 1 ]]; then
	logFailure javaVersion "bad arguments in config file: need 1 arg = minimumum version"
	return
    fi

    neededVersion=$1
    
    outFile=${TEMP_DIR}/javaversion

    if [[ "${JAVA_HOME}" = "" ]]; then
	logFailure javaVersion "please set JAVA_HOME in config file"
	return
    fi

    checkingCommand="${JAVA_HOME}/bin/java -version > $outFile 2>&1"

    print "looking for at least version $neededVersion of Java, using $checkingCommand"

    eval "\$( $checkingCommand )"

    foundVersion=`grep 'java version' $outFile | awk '{print $3}'`

    print "found version $foundVersion"

    if [[ "$foundVersion" = "" ]]; then
	logFailure javaVersion "Can't find any Java at all"
    fi

    compareVersions "$neededVersion" $foundVersion

    echo "got $versionComparison from compareVersions of Java"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure javaVersion "looking for Java version $neededVersion or greater, but found $foundVersion"
    else
	logSuccess javaVersion "looking for Java version $neededVersion or greater, and found $foundVersion"
    fi
}

# Checks that the passed in program can be run as sudo.  Adds ${SAFFIRE_HOME}/bin/ to beginning of program name.
function checkSAFfireSudo {

    typeset shortName fullPath result

    if [[ $# -ne 1 ]]; then
	logFailure checkSAFfireSudo "bad arguments in config file: need 1 arg = name of program in SAFFIRE_HOME/bin to be checked against sudo list"
	return
    fi

    shortName=$1

    if [[ "${SAFFIRE_HOME}" = "" ]]; then
	logFailure checkSAFfireSudo "please set SAFFIRE_HOME in config file"
	return
    fi

    fullPath="${SAFFIRE_HOME}/bin/"$shortName

    print "checking that $fullPath can be run as sudo for this user"

    result=`sudo -l | grep $fullPath`

    if [[ $result != "" ]]; then
	logSuccess "checkSAFfireSudo" "checking $fullPath can be run as sudo"
    else
	logFailure "checkSAFfireSudo" "checking $fullPath can be run as sudo"
    fi
}


# Checks that the passed in script can be found in ${SAFFIRE_HOME}/bin, and is executable
function checkSAFfireScriptExists {

    typeset scriptName fullPath

    if [[ $# -ne 1 ]]; then
	logFailure checkSAFfireScriptExists "bad arguments in config file: need 1 arg = name of program to check for in SAFFIRE_HOME/bin
	 return"
    fi

    scriptName=$1

    if [[ "${SAFFIRE_HOME}" = "" ]]; then
	logFailure checkSAFfireScriptExists "please set SAFFIRE_HOME in config file"
    fi

    fullPath="${SAFFIRE_HOME}/bin/$scriptName"

    print "checking that $fullPath exists and is executable"

    if [[ -f $fullPath ]]; then
	if [[ -x $fullPath ]]; then
	    logSuccess "checkSAFfireScriptExists" "$fullPath exists and is executable"
	else
	    logFailure "checkSAFfireScriptExists" "$fullPath exists but isn't executable"
	fi
    else
	logFailure "checkSAFfireScriptExists" "can't find $fullPath"
    fi
}


# This isn't something that passes or fails, just collects the license info from all machines into one place
# (needs to be added to the config file for each machine)
function collectMachineInfo {

    $scriptPath/LICprintMachineInfo > $RESULT_DIR/machineInfo.`hostname`
}


# Checks that Zenoss exists, is executable, and with a version at least equal to the value passed in
function zenossVersion {

    typeset neededVersion fullCommand foundVersion

    if [[ $# -ne 1 ]]; then
	logFailure zenossVersion "bad arguments in config file: need 1 arg = minimum version"
	return
    fi

    neededVersion=$1

    if [[ "${ZENOSS_HOME}" = "" ]]; then
	logFailure zenossVersion "please set ZENOSS_HOME in config file"
	return
    fi

    if [[ "${ZENOSS_EXECUTABLE}" = "" ]]; then
	logFailure zenossVersion "please set ZENOSS_EXECUTABLE in config file"
	return
    fi

    fullCommand="$ZENOSS_HOME/$ZENOSS_EXECUTABLE --version"

    print "looking for at least verion $neededVersion of Zenoss using $fullCommand"

    foundVersion=`$fullCommand | awk '{print $2}`

    print "as a string, I found $foundVersion"

    compareVersions "$neededVersion" "$foundVersion"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure zenossVersion "looking for Zenoss version $neededVersion or greater, but found $foundVersion"
    else
	logSuccess zenossVersion "looking for Zenoss version $neededVersion or greater, and found $foundVersion"
    fi
}


# checks that this machine is in the specified SAFfire cluster
function checkSAFfireCluster {

    typeset clusterName otherContents

    if [[ $# -ne 1 ]]; then
	logFailure checkSAFfireCluster "bad arguments in config file: need 1 arg = SAFfire cluster name"
	return
    fi

    clusterName=$1

    if [[ "${SAFFIRE_CLUSTER_DIR}" = "" ]]; then
	logFailure checkSAFfireCluster "please set SAFFIRE_CLUSTER_DIR in config file"
    fi

    print "checking that this machine is in cluster $clusterName, by looking in directory $SAFFIRE_CLUSTER_DIR"

    if [[ ! -d $SAFFIRE_CLUSTER_DIR ]]; then
	logFailure checkSAFfireCluster "the SAFfire directory $SAFFIRE_CLUSTER_DIR doesn't exist"
	return 0
    fi

    if [[ -d "$SAFFIRE_CLUSTER_DIR/$clusterName" ]]; then
	logSuccess checkSAFfireCluster "the SAFfire cluster is $clusterName"
    else
	logFailure checkSAFfireCluster "the SAFfire cluster is not $clusterName."

	logInform checkSAFfireCluster "Looked in SAFfire directory $SAFFIRE_CLUSTER_DIR"

	for otherContents in `\ls -1 $SAFFIRE_CLUSTER_DIR`; do
	    logInform checkSAFfireCluster "SAFfire directory contained: $otherContents"
	done
    fi
}


#
# Checks that the preferred role for this machine is what's expected.
#
# Args: 1 = cluster name
#       2 = role name
#
function checkSAFfireRole {

    typeset clusterName roleName fileToCheck result

    if [[ $# -ne 2 ]]; then
	logFailure checkSAFfireRole "bad arguments in config file - need 2 args = cluster name, role name"
	return 0
    fi

    clusterName=$1
    roleName=$2

    if [[ ! -d $SAFFIRE_CLUSTER_DIR ]]; then
	logFailure checkSAFfireCluster "the SAFfire directory $SAFFIRE_CLUSTER_DIR doesn't exist"
	return 0
    fi

    print "checking that this machine's SAFfire preferred role is $roleName, assuming its cluser is $clusterName"

    fileToCheck="$SAFFIRE_CLUSTER_DIR/$clusterName/app.xml"

    if [[ ! -f $fileToCheck ]]; then
	logFailure checkSAFfireRole "role config file $fileToCheck doesn't exist"
	return 0
    fi

    result=`grep "preferredRole" $fileToCheck | sed -e 's/^\s*//'`

    # assume that the <COL> is on the line as the enclosed role element
    result=${result#<COL *>}
    result=${result%</COL>}

    if [[ "$roleName" = "$result" ]]; then
	logSuccess checkSAFfireRole "role is $roleName"
    else
	logFailure checkSAFfireRole "looked for role $roleName but found $result"
    fi
}


# Checks that this machine has the right amount of disk space for the jobs it's going to
#
# Arguments = 1 or more labels, e.g. INSTALLATION BACKUP PRIVATE
#
# It is assumed that there will be a pair of environment variables defined for each label X:
#     1. X_ROOT     (where to look)
#     2. X_MIN_SIZE (how much space needed, in Gigabytes)
#
function checkDiskSpace {

    typeset spaceLabel spaceRoot spaceMinSize tmpFile dfData fileSystemFreeBefore
    typeset -i dfIdx

    # set up global arrays with filesystems, free space, mount point
    tmpFile=$TEMP_DIR/checkDiskSpace
    df | grep -v "Mounted on" > $tmpFile              # get rid of the heading line

    dfIdx=0
    for dfData in `awk '{print $1}' $tmpFile`; do
	fileSystemName[$dfIdx]=$dfData
	dfIdx=$(( $dfIdx+1 ))
    done

    dfIdx=0
    for dfData in `awk '{print $4}' $tmpFile`; do
	fileSystemFree[$dfIdx]=$dfData   # this is the number of 1024 byte blocks
	fileSystemFreeBefore[$dfIdx]=$dfData   # this is the number of 1024 byte blocks
	dfIdx=$(( $dfIdx+1 ))
    done

    dfIdx=0
    for dfData in `awk '{print $6}' $tmpFile`; do
	fileSystemMount[$dfIdx]=$dfData
	dfIdx=$(( $dfIdx+1 ))
    done

    # loop through the command line arguments, consuming space in the relevant filesystem
    for spaceLabel; do

	spaceRoot=$spaceLabel"_ROOT"
	spaceMinSize=$spaceLabel"_MIN_SIZE"

	print "checking for file area $spaceLabel"

	consumeFileSpace $spaceRoot $spaceMinSize
    done

    # if we get here without error, then the test has passed.
    if [[ $diskSpaceError -eq 0 ]]; then
	logSuccess checkDiskSpace "enough space"
    fi

    dfIdx=0
    while [[ $dfIdx -lt ${#fileSystemMount[*]} ]]
      do

      if [[ ${fileSystemFree[$dfIdx]} = ${fileSystemFreeBefore[$dfIdx]} ]]; then
	  logInform checkDiskSpace "${fileSystemName[$dfIdx]} ${fileSystemMount[$dfIdx]}: no change - ${fileSystemFree[$dfIdx]} 1k blocks free"
      else
	  logInform checkDiskSpace "${fileSystemName[$dfIdx]} ${fileSystemMount[$dfIdx]}: ${fileSystemFreeBefore[$dfIdx]} -> ${fileSystemFree[$dfIdx]} 1k blocks free"
      fi



      dfIdx=$(( $dfIdx+1 ))
    done
}


# Not a check, but called by the check function checkDiskSpace
# Args: 1 = name of environment variable holding the root of the area to try to fit in
#       2 = name of environment variable holding how big the area to fit in is
#
# Finds which file system the area would go into, and then sees if there's enough space there
# Assumes that the global arrays fileSystemName, fileSystemFree and fileSystemMount are already set up.
#
function consumeFileSpace {

    # things that look like numbers here are deliberately strings to avoid overflow
    typeset rootDir minSize spaceK

    typeset -i maxMatchLength bestMatchIdx fileSystemIdx matchPos

    nameref rootDirPointer=$1
    nameref minSizePointer=$2

    rootDir=$rootDirPointer
    minSize=$minSizePointer

    if [[ "$rootDir" = "" ]]; then
	logFailure checkDiskSpace "Checking for space in non-existant directory $1"
	diskSpaceError=1
	return 0
    fi

    print "looking for at least $minSize GB in $rootDir"

    # find the most specific match in the list of filesystem mount points i.e. the mount point whose
    # name matches and is the longest (so that e.g. /a/b is preferred over / if you're looking for /a/b/c).

    maxMatchLength=0
    fileSystemIdx=0

    while [[ $fileSystemIdx -lt ${#fileSystemName[*]} ]]
    do
      matchPos=`echo $rootDir "^"${fileSystemMount[$fileSystemIdx]} | awk '{print match($1, $2)}'`

      # found a match?
      if [[ $matchPos -eq 1 ]]; then

	  # is it a better match than any previous matches?
	  if [[ ${#fileSystemMount[$fileSystemIdx]} -gt $maxMatchLength ]]; then
	      maxMatchLength=${#fileSystemMount[$fileSystemIdx]}
	      bestMatchIdx=$fileSystemIdx
	  fi
      fi
      
      fileSystemIdx=$(( $fileSystemIdx+1 ))
    done

    # if there was no file system at all for this area, report an error
    # (this shouldn't happen, as something should be mounted as /)
    if [[ $maxMatchLength -eq 0 ]]; then
	logFailure checkDiskSpace "can't find a filesystem for $rootDir"
	diskSpaceError=1
	return 0
    fi

    # take space away from the file system that's the best match
    spaceK=`echo $minSize | awk '{print $1*1048576}'`

    # use awk to avoid overflow
    fileSystemFree[$bestMatchIdx]=`echo ${fileSystemFree[$bestMatchIdx]} $spaceK | awk '{print $1-$2}'`

    print "${fileSystemName[$bestMatchIdx]} mounted on ${fileSystemMount[$bestMatchIdx]} now has ${fileSystemFree[$bestMatchIdx]} k free"

    if [[ ${fileSystemFree[$bestMatchIdx]} -lt 0 ]]; then
	logFailure checkDiskSpace "need $minSize GB in $rootDir for $1, but not enough space on ${fileSystemName[$bestMatchIdx]}"
	diskSpaceError=1
	return 0
    else
	print "enough space so far"
    fi
}


function checkSNMPDrunning {

    typeset tmpFile

    tmpFile=$TEMP_DIR/snmpdrunning

    ps -ef | grep snmpd | grep -v grep > $tmpFile

    if [[ `cat $tmpFile` = "" ]]; then
	logFailure checkSNMPDrunning "can't find snmpd in the list of running processes"
    else
	logSuccess checkSNPDrunning "snmpd is running"
    fi
}

function checkSNMPversion {

    typeset neededVersion foundVersion

    if [[ $# -ne 1 ]]; then
	 logFailure checkSNMPversion "error in config file - need 1 argument = minimum version needed"
	 return
    fi

    neededVersion=$1

    if [[ "${SNMP_HOME}" = "" ]]; then
	logFailure checkSNMPversion "please set SNMP_HOME in config file"
	return
    fi

    foundVersion=`${SNMP_HOME}/sbin/snmpd -v | grep 'NET-SNMP version' | awk '{print $NF}'`

    print "looking for version $neededVersion of SNMP and found $foundVersion"

    compareVersions "$neededVersion" "$foundVersion"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure checkSNMPversion "looking for NET-SNMP version $neededVersion but found $foundVersion"
    else
	logSuccess checkSNMPversion "looking for NET-SNMP version $neededVersion and found $foundVersion"
    fi
}

##########################
#
# house keeping functions
#
##########################

function setUpLocalEnvVars {

    typeset -i envVarIdx

    # call the function generated on the master to define the names and values we want
    localEnvVars

    envVarIdx=0
    while [[ $envVarIdx -lt ${#envVarName[*]} ]]
    do

      export ${envVarName[$envVarIdx]}="${envVarValue[$envVarIdx]}"

      print "Setting environment variable ${envVarName[$envVarIdx]} to ${envVarValue[$envVarIdx]}"

      envVarIdx=$(( $envVarIdx+1 ))
    done
}


################################
#
# proper execution starts here
#
################################

RUN_DIR=$1
RESULT_DIR=$RUN_DIR/results
TEMP_DIR=$RUN_DIR/working

# general results file (some tests will go into their own files)
RESULT_FILE=$RESULT_DIR/result.`hostname`

TODO_LIST=$2

# name of host that master script is running on, which is where to copy the results back to
MASTER_NAME=$3                

# where to log to
LOG_FILE=$4

exec >$LOG_FILE
exec 2>$LOG_FILE

print "got args RUN_DIR              = $RUN_DIR"
print "         TODO_LIST            = $TODO_LIST"
print "         master's host name   = $MASTER_NAME"
print "         log file             = $LOG_FILE"

# load in the todo list, which specifies the localChecks function
. $TODO_LIST

# set up the environment with variables that were originally specified in the config file
setUpLocalEnvVars

# work through the todo list
localChecks

# assume the master will copy and delete things afterwards
#print "copying results back to $MASTER_NAME:$MASTER_RESULT_DIR"
#scp $RESULT_DIR/* $RUN_DIR/working/log* $MASTER_NAME:$MASTER_RESULT_DIR
echo "not copying stuff back to the master - assume it's doing the copying"


