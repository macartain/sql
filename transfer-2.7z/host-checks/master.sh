#!/bin/ksh

# master script for pre-installation checking
#
# Bob Salmon
# 18th May 2010

. ./master_checks.sh

###############################################################################################
#
# Function definitions
#
###############################################################################################

# Gets rid of comments, and leading and trailing white space.

# read will get rid of leading and trailing white space, but doesn't know about comments, so
# if a line is good stuff, then white space, then a comment it means we can't rely on read to
# get rid of the white space in the middle.
function f_CleanLine {

    typeset inputLine noComments cleanLine

    inputLine=$1

    # delete comments if they exist
    noComments=${inputLine%%#*}
    
    # delete leading and trailing white space
    cleanLine=$(echo "$noComments" | sed -e 's/^[ \t]*//g;s/[ \t]*$//g')

    echo $cleanLine
}

# returns the first non-empty line (having first removed comments) or when the file is finished
function f_ReadLine {

    typeset -i timeToStop
    typeset rawLine

    timeToStop=0

    until [[ $timeToStop -eq 1 ]]; do

	read rawLine <&4

	currentLine=$(f_CleanLine "$rawLine")

	numLinesRead=$(( $numLinesRead+1 ))

	if [[ $numLinesRead -ge $lineLimit ]]; then
	    timeToStop=1
	elif [[ "$currentLine" != "" ]]; then
	    timeToStop=1
	fi

    done
}

# Looks for the first argument in the input file
#
# If it can't find it in the current line, read more lines until it's found or the end of file
# reached (in which case it will print the error string and exit)
#
# If it finds the token it deletes it from the currentLine variable, and returns
#
function f_LookForToken {

    typeset lookFor errorString
    typeset -i stopSearching

    lookFor=$1
    errorString=$2

    stopSearching=0

    while [[ $stopSearching -eq 0 ]]
    do
      # is the wanted string in current line (allowing for white space) ?
      if [[ $currentLine =~ "$lookFor" ]]; then
          # yes? delete it
	  stopSearching=1
	  currentLine=${currentLine##$lookFor}
      else
          # no, try another line
	  if [[ $numLinesRead -lt $lineLimit ]]; then
	      f_ReadLine

	      # only had blank lines left?
	      if [[ "$currentLine" = "" ]]; then
		  stopSearching=1
		  print $errorString
	      fi
	  else
	      stopSearching=1 # run out of file
	      print $errorString
	  fi
      fi
    done
}


# Handles all the parsing of a machine's definition in the config file
function f_DefineMachine {

    typeset -i foundEndOfRoles
    typeset machineName machineText

    nextMachineIdx=$(( $nextMachineIdx+1 ))

    machineName=`echo $currentLine | awk '{print $2}'`
    print "Line $numLinesRead: found machine $nextMachineIdx $machineName"
    mode='machine'
    lastMachineName=$machineName

    # initialise this machine to have no per-machine environment variables
    # if the machine does have some, these will be changed to point to the first / last entry in the per-machine
    # environment variable name/value arrays that's for this machine
    machineFirstEnvVar[$nextMachineIdx]=-1
    machineLastEnvVar[$nextMachineIdx]=-1

    if [[ $machineName = +(\d) ||
	  "$machineName" = "results" || "$machineName" = "working" ]]; then
	print "This script cannot test a machine whose name is 'results', 'working' or just a number."
	exit 1
    fi

    machineNames[$nextMachineIdx]=$machineName
    machineRoles[$nextMachineIdx]=""

    # get rid of the machine name and "machine" token before looking for anything else
    currentLine=${currentLine##machine+(\s)+(\S)*(\s)}

    # look for at least one role
    f_LookForToken "roles" "End of file reached in the definition of machine $machineName"
    f_LookForToken "=" "End of file reached in the definition of machine $machineName"
    f_LookForToken "(" "End of file reached in the definition of machine $machineName"

    # get roles until you see a close bracket
    foundEndOfRoles=0
    while [[ $foundEndOfRoles != 1 ]]
    do
      # ignore any close brackets at the beginning of the line, and any leading/trailing white space
      # if there's anything left, treat it as a role
      machineText=$(echo "$currentLine" | sed -e 's/^[ \t]*//g;s/[) \t]*$//g')

      if [[ "$machineText" != "" ]]; then
	  if [[ "${machineRoles[$nextMachineIdx]}" != "" ]]; then
	      machineRoles[$nextMachineIdx]=${machineRoles[$nextMachineIdx]}"|"
	  fi

	  machineRoles[$nextMachineIdx]=${machineRoles[$nextMachineIdx]}$machineText
      fi

      if [[ $currentLine =~ ")" ]]; then
	  foundEndOfRoles=1
      else
	  f_ReadLine

	  if [[ "$currentLine" = "" ]]; then
	      print "End of file reached in the definition of machine $machineName"
	  fi
      fi
    done

#    print "set roles for ${machineNames[$nextMachineIdx]} to --${machineRoles[$nextMachineIdx]}++"
}


# Handles all the parsing of a role's definition in the config file
function f_DefineRole {

    typeset roleName newVarArray roleVarsThisLine roleText
    typeset -i foundStartOfChecks foundEndOfChecks newVarIdx

    roleName=`echo $currentLine | awk '{print $2}'`
    print "Line $numLinesRead: found role $nextRoleIdx $roleName"
    mode="role" # guard against environment variables being defined for a role

    roleNames[$nextRoleIdx]=$roleName
    roleVars[$nextRoleIdx]=""
    roleChecks[$nextRoleIdx]=""

    # get rid of role name and "role" from line
    currentLine=${currentLine##role+(\s)+(\S)*(\s)}

    # anything that's before ( and isn't white space are role variables
    foundStartOfChecks=0
    while [[ $foundStartOfChecks != 1 ]]
    do
      roleVarsThisLine=$(echo "$currentLine" | sed -e 's/^[ \t]*//g;s/[\t (]*$//g')

      # add this line's role variable[s] on to any already found from previous lines
      if [[ $roleVarsThisLine != "" ]]; then
	  set -A newVarArray $roleVarsThisLine
	  newVarIdx=0
	  while [ $newVarIdx -lt ${#newVarArray[*]} ]
	  do
	    if [[ "${roleVars[$nextRoleIdx]}" != "" ]]; then
		roleVars[$nextRoleIdx]=${roleVars[$nextRoleIdx]}"|"
	    fi

	    roleVars[$nextRoleIdx]=${roleVars[$nextRoleIdx]}${newVarArray[$newVarIdx]}
	    newVarIdx=$(( $newVarIdx+1 ))
	  done
      fi

      if [[ $currentLine =~ "(" ]]; then
	  foundStartOfChecks=1

	  # get rid of any variables on the line before the (
	  currentLine=${currentLine##*(\s)$roleVars*(\s)}
      else
	  f_ReadLine
	  if [[ "$currentLine" = "" ]]; then
	      print "End of file reached in the definition of role $roleName"
	  fi
      fi
    done

    # consume the (
    f_LookForToken "(" "End of file reached in the definition of role $roleName"

    # get checks until you see a close bracket
    foundEndOfChecks=0
    while [[ $foundEndOfChecks != 1 ]]
    do
      # ignore any close brackets at the beginning of the line, and any leading/trailing white space
      # if there's anything left, treat it as a role
      roleText=$(echo "$currentLine" | sed -e 's/^[ \t]*//g;s/[) \t]*$//g')

      if [[ "$roleText" != "" ]]; then
	  if [[ ${roleChecks[$nextRoleIdx]} != "" ]]; then
	      roleChecks[$nextRoleIdx]=${roleChecks[$nextRoleIdx]}"|"
	  fi
	  roleChecks[$nextRoleIdx]=${roleChecks[$nextRoleIdx]}$roleText
      fi

      if [[ $currentLine =~ ")" ]]; then
	  foundEndOfChecks=1
      else
	  f_ReadLine

	  if [[ "$currentLine" = "" ]]; then
	      print "Error: End of file reached in the definition of role $roleName"
	      exit 1
	  fi
      fi
    done

    nextRoleIdx=$(( $nextRoleIdx+1 ))
}

function f_UnknownLine {
    echo "don't know about the line $1"
}

# Defines global settings e.g. environment variables
function f_DefineGlobal {

    print "Line $numLinesRead: found global settings"

    # get rid of "global" from line
    f_LookForToken "global" "End of file reached in the definition of global settings"

    # all we do here is say that it's in global mode rather than per-machine
    # rely on env_var etc. processing code to do the hard work
    mode='global'
}


function f_DefineEnvVars {

    typeset -i foundEndOfEnvVars
    typeset envVarText eVName eVValue

    f_LookForToken "env_vars" "End of file reached in the definition of environment variables"
    f_LookForToken "=" "End of file reached in the definition of environment variables"
    f_LookForToken "(" "End of file reached in the definition of environment variables"

    # keep reading until you find a ")"
    nextEnvVarIdx=0
    foundEndOfEnvVars=0
    while [[ $foundEndOfEnvVars != 1 ]]
    do
      # ignore any close brackets at the beginning of the line, and any leading/trailing white space
      # if there's anything left, treat it as a environment variable
      envVarText=$(echo "$currentLine" | sed -e 's/^[ \t]*//g;s/[) \t]*$//g')

      if [[ "$envVarText" != "" ]]; then

          # assume each environment variable is a single line of the format: name whitespace+ value
	  eVName=${envVarText%%+(\s)*}
	  eVValue=${envVarText##+(\S)+(\s)}
      
	  # store environment variables in the right place
	  if [[ "$mode" = "global" ]]; then
	      print "Line $numLinesRead: found environment variable $nextEnvVarIdx name='$eVName' value='$eVValue'"
	      envVarName[$nextEnvVarIdx]=$eVName
	      envVarValue[$nextEnvVarIdx]="$eVValue"
	      nextEnvVarIdx=$(( $nextEnvVarIdx+1 ))
	  else
	      if [[ "$mode" = "machine" ]]; then
		  print "Line $numLinesRead: found per-machine environment variable $nextMachineEnvVarIdx name='$eVName' value='$eVValue'"

		  # is this the first environment variable for this machine? If so, point to it
		  if [[ ${machineFirstEnvVar[$nextMachineIdx]} -eq -1 ]]; then
		      machineFirstEnvVar[$nextMachineIdx]=$nextMachineEnvVarIdx
		  fi
		  machineLastEnvVar[$nextMachineIdx]=$nextMachineEnvVarIdx

		  machineEnvVarName[$nextMachineEnvVarIdx]=$eVName
		  machineEnvVarValue[$nextMachineEnvVarIdx]="$eVValue"

		  nextMachineEnvVarIdx=$(( $nextMachineEnvVarIdx+1 ))

	      else
		  print "Error on line $numLinesRead: trying to set environment variables at a bad point in the config file"
		  exit 1
	      fi
	  fi
      fi

      if [[ $currentLine =~ ")" ]]; then
	  foundEndOfEnvVars=1
      else
	  f_ReadLine

	  if [[ "$currentLine" = "" ]]; then
	      print "Error: End of file reached in the definition of environment variables"
	      exit 1
	  fi
      fi
    done

}

# top level function to parse the config file
function f_ReadConfigFile {

    configFileName=$1

    lineLimit=`wc -l $configFileName | awk '{print $1}'`

    exec 4<$configFileName

    nextMachineIdx=-1 # incremented at the start of each machine's stuff in the file
    nextRoleIdx=0
    mode='notSet'
    lastMachineName='notSet'
    nextMachineEnvVarIdx=0

    while [[ $numLinesRead -lt $lineLimit ]]
    do
        f_ReadLine

	case "$currentLine" in
	    # blank lines at the end?
	    "") break;;

	    # defining a machine?
	    machine*) f_DefineMachine;;

	    # defining a role?
	    role*) f_DefineRole;;

	    # defining global settings?
	    global*) f_DefineGlobal;;

	    # defining environment variables (global or per-machine)?
	    env_vars*) f_DefineEnvVars;;

	    # bad line?
	    *) f_UnknownLine;;
	esac
	
    done

    exec 4<&-
}


# Does argument substitution when roles are used by machines
function f_SubArg {

    typeset argNameToFind argListString valueListString argListArray
    typeset -i argIdx

    argNameToFind=`echo $1 | tr -d '$'`        # prefixed with $ when passed in
    argListString=$2                           # | separated list
    valueListString=$3                         # whitespace separated list

    # find which position the argument we're after is in the list of arguments
    IFS="|"
    set -A argListArray $argListString

    argIdx=0

    while [[ $argIdx -lt ${#argListArray[*]} ]]
    do
      if [[ "$argNameToFind" = "${argListArray[$argIdx]}" ]]; then
	  break;
      fi

      argIdx=$(( $argIdx+1 ))
    done

    if [[ $argIdx -eq ${#argListArray[*]} ]]; then
	print "Can't find argument during substitution - looking for $argNameToFind in $argListString"
	exit
    fi

    # pick the value from that position in the list of values
    typeset valueListArray
    unset IFS
    set -A valueListArray $valueListString

    if [[ ${#valueListArray[*]} -ne ${#argListArray[*]} ]]; then
	print "Machine is using the wrong number of values for a role.  Can't find a value for $argNameToFind"
	exit
    fi

    echo ${valueListArray[$argIdx]}
}

function f_WritePerMachineEnvVars {

    typeset -i machineIdx envVarIdx machineEnvVarIdx foundEnvVar outputIdx
    typeset outFile

    machineIdx=$1
    outFile=$2

    if [[ ${#envVarName[*]} -gt 0 || ${machineFirstEnvVar[$machineIdx]} -ne -1 ]]; then
	print "creating environment variables for machine $machineIdx in file $outFile"
    else
	print "no environment variables for machine $machineIdx"
	return
    fi

    outputIdx=0
    echo "function localEnvVars {" >> $outFile

    envVarIdx=0
    while [[ $envVarIdx -lt ${#envVarName[*]} ]]
      do

      # write out anything in the global list that's not also in the per-machine list

      foundEnvVar=0

      # if there are any per-machine environment variables, see if this global one is in the per-machine list
      if [[ ${machineFirstEnvVar[$machineIdx]} -ne -1 ]]; then

	  machineEnvVarIdx=${machineFirstEnvVarIdx[$machineIdx]}
	  while [[ $machineEnvVarIdx -le ${machineLastEnvVar[$machineIdx]} ]]
	  do
	    if [[ ${machineEnvVarName[$machineEnvVarIdx]} = ${envVarName[$envVarIdx]} ]]; then
		foundEnvVar=1
		break
	    fi

	    machineEnvVarIdx=$(( $machineEnvVarIdx+1 ))
	  done
      fi

      if [[ $foundEnvVar -eq 0 ]]; then
	  echo "# global value" >> $outFile
	  echo "envVarName[$outputIdx]=${envVarName[$envVarIdx]}" >> $outFile
	  echo "envVarValue[$outputIdx]=${envVarValue[$envVarIdx]}" >> $outFile
	  echo "" >> $outFile

	  print "env var $outputIdx = global ${envVarName[$envVarIdx]} = ${envVarValue[$envVarIdx]}"

	  outputIdx=$(( $outputIdx+1 ))
      fi

      envVarIdx=$(( $envVarIdx+1))
    done

    # write out anything in the per-machine list
    if [[ ${machineFirstEnvVar[$machineIdx]} -gt -1 ]]; then
	machineEnvVarIdx=${machineFirstEnvVar[$machineIdx]}

	while [[ $machineEnvVarIdx -le ${machineLastEnvVar[$machineIdx]} ]]
	do
	  echo "# per-machine value" >> $outFile
	  echo "envVarName[$outputIdx]=${machineEnvVarName[$machineEnvVarIdx]}" >> $outFile
	  echo "envVarValue[$outputIdx]=${machineEnvVarValue[$machineEnvVarIdx]}" >> $outFile
	  echo "" >> $outFile

	  print "env var $outputIdx = per-machine ${machineEnvVarName[$machineEnvVarIdx]} = ${machineEnvVarValue[$machineEnvVarIdx]}"

	  outputIdx=$(( $outputIdx+1 ))
	  machineEnvVarIdx=$(( $machineEnvVarIdx+1 ))
	done
    fi

    echo "}" >> $outFile
    echo "" >> $outFile
}


#
# Creates to do lists (in the form of a function called localChecks) per remote machine, storing them
# in the $TEMP_DIR/todo.$machineName. It uses the config file to create the to do lists.
#
function f_CreateTodoLists {

    typeset configFileName machineName todoList roles thisRole thisRoleName thisRoleArgs checks
    typeset checkArgs checkArgArray checkArg subbedArg subbedCheck
    typeset -i machineIdx roleIdx searchIdx checkIdx checkArgIdx

    configFileName=$1

    numLinesRead=0
    lineLimit=0
    currentLine=""

    f_ReadConfigFile ${configFileName}

    # loop through all the machines
    machineIdx=0
    while [[ $machineIdx -lt ${#machineNames[*]} ]]
    do
      machineName=${machineNames[$machineIdx]}
      echo ""
      echo "Preparing checks for machine $machineName"

      todoList=$TEMP_DIR/todo.${machineName}
      echo "# local data for machine $machineName" > $todoList

      f_WritePerMachineEnvVars $machineIdx "$todoList"

      echo "function localChecks {" >> $todoList

      # for this machine, loop through all its roles
      IFS="|"
      set -A roles ${machineRoles[$machineIdx]}

      roleIdx=0
      while [[ $roleIdx -lt ${#roles[*]} ]]
      do
        # find the role's definition by its name
	thisRole=${roles[$roleIdx]}
	thisRoleName=`echo ${thisRole} | awk '{print $1}'` # strip off any variables
	thisRoleArgs=${thisRole##+(\S)*(\s)}

	searchIdx=0

	while [[ $searchIdx -lt ${#roleNames[*]} ]]
	do
	  if [[ "${roleNames[$searchIdx]}" = "$thisRoleName" ]]; then
	      break
	  fi
	  searchIdx=$(( $searchIdx+1 ))
	done

    # can't find this role?
    if [[ "${roleNames[$searchIdx]}" != "$thisRoleName" ]]; then
	print "Can't find the definition of role $thisRoleName, which is used in machine $machineName"
	exit
    fi

    # for this role, loop through all the checks
    IFS="|"
    set -A checks ${roleChecks[$searchIdx]}

    checkIdx=0
    while [[ $checkIdx -lt ${#checks[*]} ]]
    do
      fullCheckString=${checks[$checkIdx]}
      checkArgs=${fullCheckString##+(\S)*(\s)}
      
      # do any arguments need their values taking from the role and machine definition?
      if [[ "$checkArgs" != "" ]]; then
	  unset IFS
	  set -A checkArgArray $checkArgs
	  checkArgIdx=0
	  subbedCheck=`echo $fullCheckString | awk '{print $1}'`  # start with just the command name

	  while [[ $checkArgIdx -lt ${#checkArgArray[*]} ]]
	  do
	    checkArg=${checkArgArray[$checkArgIdx]}

	    if [[ $checkArg =~ [\$]+ ]]; then
		subbedArg=$(f_SubArg $checkArg ${roleVars[$searchIdx]} "${thisRoleArgs}")
		subbedCheck="$subbedCheck $subbedArg"
	    else
		subbedCheck="$subbedCheck $checkArg"
	    fi

	    checkArgIdx=$(( $checkArgIdx+1 ))
	  done

	  print "will do check: $subbedCheck"
	  echo "$subbedCheck" >> $todoList
      else
	  print "will do check: ${checks[$checkIdx]}"
	  echo "${checks[$checkIdx]}" >> $todoList
      fi

      checkIdx=$(( $checkIdx+1 ))
    done

    roleIdx=$(( $roleIdx+1 ))
  done

  echo "}" >> $todoList

  machineIdx=$(( $machineIdx+1 ))
done
}


#
# Check that the root directory exists, and that the per-run directory within that doesn't already exist
# Create the per-run directory, and the output and working directories within that.
#
# Sets the global variables RESULT_DIR and TEMP_DIR to point to the output and working directories
#
function f_CheckAndCreateDirs {

    typeset rootDir subDir

    rootDir=$1
    subDir=$2

    # Does the root directory exist with the correct permission? (it should)
    if [[ ! -d $rootDir ]]; then
	print "Error: Root directory $rootDir does not exist"
	exit 1
    fi

    if [[ ! ( -w $rootDir && -x $rootDir ) ]]; then
	print "Error: Can't create a per-run directory in $rootDir"
	exit 1
    fi

    # Does the sub directory exist? (it shouldn't)
    RUN_DIR=$rootDir/$subDir

    if [[ -a $RUN_DIR ]]; then
	print "Error: Output directory $RUN_DIR already exists for this run."
	exit 1
    fi

    # create the run directory
    mkdir $RUN_DIR
    chmod +wx $RUN_DIR       # being paranoid

    # create the results directory
    RESULT_DIR=$RUN_DIR/results
    mkdir $RESULT_DIR
    chmod +wx $RESULT_DIR   # being paranoid

    # create the working directory
    TEMP_DIR=$RUN_DIR/working
    mkdir $TEMP_DIR
    chmod +wx $TEMP_DIR   # being paranoid
}

# Sets the REMOTE_USER environment variable, trying in this order:
# 1. a per-machine setting in the config file
# 2. a global setting in the config file
# 3. the current value of USER
#
# REMOTE_USER will be used when sshing or scping to a remote machine - password
# will need to be entered by the user.
#
function f_GetRemoteUser {

    typeset -i machineIdx envVarIdx

    machineIdx=$1

    foundRemoteUser=0

    # look for a per-machine environment variable called REMOTE_USER
    if [[ ${machineFirstEnvVar[$machineIdx]} -ne -1 ]]; then

	envVarIdx=${machineFirstEnvVar[$machineIdx]}
	while [[ $envVarIdx -le ${machineLastEnvVar[$machineIdx]} ]]
	do
	  print "checking per-machine variable ${machineEnvVarName[$envVarIdx]}"
	  if [[ ${machineEnvVarName[$envVarIdx]} = 'REMOTE_USER' ]]; then
	      print "found a per-machine value: ${machineEnvVarValue[$envVarIdx]}"
	      REMOTE_USER=${machineEnvVarValue[$envVarIdx]}
	      return 0
	  fi

	  envVarIdx=$(( $envVarIdx+1 ))
	done
    fi

    # if there's no per-machine environment variable, look for a global
    envVarIdx=0

    while [[ $envVarIdx -lt ${#envVarName[*]} ]]
    do
      if [[ ${envVarName[$envVarIdx]} = 'REMOTE_USER' ]]; then
	  print "using global value of REMOTE_USER: ${envVarValue[$envVarIdx]}"
	  REMOTE_USER=${envVarValue[$envVarIdx]}
	  return 0
      fi

      envVarIdx=$(( $envVarIdx+1 ))
    done

    # if we still haven't found one, use the current USER
    print "defaulting REMOTE_USER to USER: ${USER}"
    REMOTE_USER=${USER}
}


# Loop through all the machines, copy over the script files and kick off the tests
function f_StartTests {

    typeset todoList machineName firstRemoteScriptName rootDir scriptDir thisMachine resultDir testCommand
    typeset -i status scriptIdx machineIdx

    rootDir=$1

    listOfScripts="checks.sh checkUtils.sh db_checks.sh LICprintMachineInfo" # as well as the to do list itself
    firstRemoteScriptName="fixDirectories.sh"

    thisMachine=`hostname`

    print ""
    print "Copying files to remote machines and starting tests from directory $scriptPath"
    
    unset IFS
    machineIdx=0
    while [[ $machineIdx -lt ${#machineNames[*]} ]]
    do
	machineName=${machineNames[$machineIdx]}
	todoList=$TEMP_DIR/todo.$machineName

	# sets the global REMOTE_USER
	f_GetRemoteUser $machineIdx

	print "todoList file name='$todoList'"
	print "copying files onto machine $machineName as user ${REMOTE_USER}"

	# create a directory on the master machine to receive the results
	resultDir=$RUN_DIR/$machineName
	mkdir $resultDir

	# copy a little script over to /tmp to sort out the proper directories
	scp $firstRemoteScriptName ${REMOTE_USER}@$machineName:/tmp

	# run the directory sorting out script
	status=`ssh -l ${REMOTE_USER} $machineName "/tmp/$firstRemoteScriptName $1"`
	print "ssh status to execute directory set-up script=" $status

	# delete the directory sorting out script
	status=`ssh -l ${REMOTE_USER} $machineName "rm /tmp/$firstRemoteScriptName"`
	print "ssh status to remove directory set-up script=" $status

	# copy the proper scripts over to the directories you now know are there
	remoteRunDir="$rootDir/$machineName"
	scriptDir="$remoteRunDir/scripts"

	# copy the todo list itself, plus the other scripts
	# do it in one big copy in case the user is having to enter a password
	# (this would be once for each scp call)
	scp $todoList $listOfScripts ${REMOTE_USER}@$machineName:$scriptDir

	# kick off the main script on the remote machine, but don't wait for it to finish

	testCommand=`printf "ssh -l %s %s %s %s %s %s %s" ${REMOTE_USER} $machineName $scriptDir/checks.sh $remoteRunDir $scriptDir/todo.$machineName $thisMachine $remoteRunDir/working/log`

	print "starting test on $machineName with $testCommand"

	# used to do these asynchronously (i.e. with & on the end) but it would start OK but then never finish
	# on machines where REMOTE_USER != this USER
	ssh -l ${REMOTE_USER} $machineName "$scriptDir/checks.sh $remoteRunDir $scriptDir/todo.$machineName $thisMachine $remoteRunDir/working/log"

	machineIdx=$(( $machineIdx+1 ))
    done
}


function f_WaitForTestsToEnd {

    typeset remoteHostsActive
    typeset -i numHostsActive numRepeats maxNumRepeats sleepDuration

    numRepeats=0
    numHostsActive=1 # dummy initial non-zero value to force at least one check
    maxNumRepeats=50
    sleepDuration=2

    print ""
    print "Waiting for remote tests to finish"

    while [[ $numHostsActive -gt 0 && $numRepeats -lt $maxNumRepeats ]];
    do
      remoteHostsActive=`ps -ef | awk '{if ($3 == '$$') {if ($8 == "ssh") {print $11}}}'`

      numHostsActive=`echo $remoteHostsActive | wc -w`

      print $numHostsActive "remote test[s] active:" `echo $remoteHostsActive | tr '\n' ' '`

      if [[ $numHostsActive -gt 0 ]]; then
	  numRepeats=$(( $numRepeats+1 ))
	  print $(( $maxNumRepeats-$numRepeats )) "more attempt[s] to wait for remote tests to finish"

	  print "Sleeping for $sleepDuration seconds..."
	  sleep $sleepDuration
      fi
    done

    # did we give up?
    if [[ $numHostsActive -gt 0 ]]; then
	print "Timeout: still $numHostsActive remote test[s] running"
	REMOTE_TESTS_FINISHED=0
    else
	print "All remote tests finished"
	REMOTE_TESTS_FINISHED=1
    fi
}


function f_CleanUpRemoteMachines {

    typeset todoList machineName rootDir targetDir
    typeset -i machineIdx

    rootDir=$1

    print ""
    print "Deleting temporary files from remote machines..."

    # loop through the remote machines
    machineIdx=0
    while [[ $machineIdx -lt ${#machineNames[*]} ]]
    do

	f_GetRemoteUser $machineIdx

	machineName=${machineNames[$machineIdx]}
	todoList="$TEMP_DIR/todo.$machineName"	    

#       echo "not deleting temporary files from $machineName - do this by hand"
	print "Deleting temporary files from $machineName"

        # copy back and then delete the results
	targetDir=$RUN_DIR/$machineName

	scp ${REMOTE_USER}@$machineName:$rootDir/$machineName/results/* ${REMOTE_USER}@$machineName:$rootDir/$machineName/working/log* $targetDir
	ssh -l ${REMOTE_USER} $machineName "rm -r $rootDir/$machineName"

	machineIdx=$(( $machineIdx+1 ))
    done
}



# Call all the end of run checks (defined in other file[s])
function f_EndOfRunChecks {

    typeset outputFile

    outputFile=$1

    f_SubnetCheck $outputFile
    f_checkDBunixUser $outputFile
}



function f_SummariseResultFile {

    typeset resultFile testName tmpFile
    typeset -i testsInFile passesInFile failuresInFile warningsInFile

    resultFile=$1
    testName="$2"
    outFile=$3

    tmpFile=$TEMP_DIR/resultSummary

    awk 'BEGIN {totalTests=0; totalFailures=0; totalSuccesses=0; totalWarnings=0; label="'$testName'"; moreDetails="'$resultFile'"} \
	       {if ($1=="TEST") {totalTests++; \
	                         if ($NF == "FAILED") {failedTests[$2]=1; totalFailures++} \
	                         else {if ($NF == "PASSED") {totalSuccesses++} \
                                       else {if ($NF == "WARN") {warnings[$2]=1; totalWarnings++}}}}}
         END   {printf "Summary of results for %s: %d test[s] executed, %d passed, %d warning[s], %d failed.\n", \
                             label, totalTests, totalSuccesses, totalWarnings, totalFailures; \
                     if (totalFailures > 0 || totalWarnings > 0) \
                            {printf "Failed test[s]:"; \
                             for (i in failedTests) {printf " %s", i}; \
	                     printf "\nWarning[s]:"; \
	                     for (i in warnings) {printf " %s", i}; \
                             printf "\nFor more details refer to %s\n\n", moreDetails}}' $resultFile > $tmpFile
    cat $tmpFile

    # add total tests, passes and failures onto global totals
    testsInFile=`grep "Summary of results" $tmpFile | awk ' {print $6}`
    passesInFile=`grep "Summary of results" $tmpFile | awk ' {print $9}`
    warningsInFile=`grep "Summary of results" $tmpFile | awk ' {print $11}`
    failuresInFile=`grep "Summary of results" $tmpFile | awk ' {print $13}`

    totalTests=$(( $totalTests+$testsInFile ))
    totalPasses=$(( $totalPasses+$passesInFile ))
    totalFailures=$(( $totalFailures+$failuresInFile ))
    totalWarnings=$(( $totalWarnings+$warningsInFile ))

    # dump it to the overall summary file
    cat $tmpFile >> $outFile
}



function f_CollateResults {

    typeset todoList machineName resultFile masterMachineInfoFile summaryFile

    masterMachineInfoFile=$RESULT_DIR/machineInfoList

    print ""
    print "***************************************"
    print ""
    print "Test results"
    print ""
    print "***************************************"
    print ""

    totalTests=0
    totalPasses=0
    totalFailures=0
    totalWarnings=0

    summaryFile=$RESULT_DIR/summary

    # loop through all machines, summarising the tests per machine
    for todoList in `ls $TEMP_DIR/todo.*`; do

	machineName=${todoList##/*/todo.}

	resultFile=$RUN_DIR/$machineName/result.$machineName

	f_SummariseResultFile $resultFile $machineName $summaryFile

	echo $machineName >> $masterMachineInfoFile
	cat $RUN_DIR/$machineName/machineInfo.$machineName >> $masterMachineInfoFile
	echo "" >> $masterMachineInfoFile
    done

    # summarise the per-run tests
    f_SummariseResultFile $MASTER_RESULT_FILE "cross_machine_checks" $summaryFile

    echo ""
    echo "TOTAL: $totalTests test[s] executed, $totalPasses passed, $totalWarnings warning[s], $totalFailures failed"
    echo ""

    echo "Summary of tests copied to $summaryFile"

    echo ""

    echo "List of machine info for license is in $masterMachineInfoFile"
}

# Parse config file enough to get a list of machines, then log onto each in turn, making sure that
# the root output directory is present.
function f_InitMachines {

    typeset machineName
    typeset -i machineIdx status

    echo "initialising machines"

    f_ReadConfigFile ${configFileName}

    machineIdx=0
    while [[ $machineIdx -lt ${#machineNames[*]} ]]
    do
      machineName=${machineNames[$machineIdx]}

      f_GetRemoteUser $machineIdx

      echo "setting up $ROOT_DIR on $machineName as user ${REMOTE_USER}"

      # -p => if it exists already, that's not an error
      status=`ssh -l ${REMOTE_USER}$machineName "mkdir -p $ROOT_DIR"`

      echo "status=$status"

      machineIdx=$(( $machineIdx+1 ))
    done
}


###############################################################################################
#
# Execution starts here
#
###############################################################################################

# ARGS
# 1. ROOT_DIR (see below)
# 2. config file

# Will use this file structure on the master for outputs:
#
# ROOT_DIR/$run/results
#              /working
#              /$machineName1               - stuff copied back from remote machine 1
#                  ...
#              /$machineNameN               - stuff copied back from remote machine N
#
# Will use this file structure on the remote machines for outputs
#
# ROOT_DIR/$machineName/results
#                      /working
#                      /scripts             - where the scripts are copied to
#
# This means that when the checks are done on the master (as if it were a remote machine)
# there will temporarily be ROOT_DIR/master/* and ROOT_DIR/$machineName/*.  At the end of the per-machine
# checks on the master, things at or below ROOT_DIR/$machineName can be deleted safely i.e. keeping
# ROOT_DIR/master intact.
#
# The assumption that no machine will have the name "results" or "working" or looks like a UNIX
# process id is checked when the config file is read
#

# check the correct number of arguments have been passed
if [[ $# -lt 2  || $# -gt 3 ]]; then
    badUsage=1
fi

if [[ $# -eq 3 ]]; then

    if [[ $1 = '-init' ]]; then
	initMode=1
	ROOT_DIR=$2
	configFileName=$3
    else
	badUsage=1
    fi
else
    initMode=0
    ROOT_DIR=$1
    configFileName=$2
fi

if [[ badUsage -eq 1 ]]; then
    echo "Usage: $0 [-init] <root directory> <config file>"
    echo ""
    echo "root directory = where to store results and temporary files"
    echo "                 Note this must exist on all machines, and must be local storage"
    echo ""
    echo "config file    = name of file that specifies machines to check and their"
    echo "                 roles (what checks to do per machine)"
    echo ""
    echo "options:"
    echo "-init          = log into all machines in the config file, creating the root"
    echo "                 directory if it doesn't exist.  Useful also for checking that"
    echo "                 user names, passwords etc. are set up correctly.  Doesn't do"
    echo "                 the proper checks."
    echo ""
    exit 1
fi


if [[ $initMode = 1 ]]; then

    f_InitMachines
    echo ""
    echo "Exiting.  Run again without -init to perform the checks"
    echo ""
    exit 0
fi


# if we're here, then it's normal stuff rather than init mode.
RUN_ID=$$

scriptPath=${0%/*}

f_CheckAndCreateDirs $ROOT_DIR $RUN_ID

# where to put the results of end-of-run checks (as opposed to the overall results of the run)
MASTER_RESULT_FILE=$RESULT_DIR/result.master

f_CreateTodoLists $configFileName

f_StartTests $ROOT_DIR

#f_WaitForTestsToEnd
f_CleanUpRemoteMachines $ROOT_DIR

# if at least one of the machines hadn't finished, leave all the remote results in place
# (rather than working out which ones didn't finish and deleting all the rest)
#if [[ $REMOTE_TESTS_FINISHED -eq 1 ]]; then
#    f_CleanUpRemoteMachines $ROOT_DIR
#fi

# do any checks that can only happen after all the checks have finished on the remote machines
f_EndOfRunChecks $MASTER_RESULT_FILE

f_CollateResults


