--/*C*--------------------------------------------------------------------
--
-- FILENAME    : healthcheck_dumpschema.sql
--
-- AUTHOR      : acolema1
--
-- DESCRIPTION :
--
-- VERSION     : %full_filespec: healthcheck_dumpschema.sql-1:sql:1 %
--
-- Copyright :   NetCracker Technology Corporation 2012
--
----------------------------------------------------------------------*C*/
--
-- File: healthcheck_dumpschema.sql
--
-- Script to dump the Rating and Billing schema after performing an install
-- or a migration.
--
-- It is based on the dumpschema.sql script supplied with RB 5.3.2 but the
-- following changes have been made:
--
-- (1) Instead of selecting from ALL_*, selects from ALL_* where
--     OWNER = '&vSchemaOwner' (though column is not always called "OWNER").
--      vSchemaOwner should have been set up by healthcheck_setup.sql
--
-- (2) It requires only one parameter (rather than the 2 needed by dumpschema.sql):
--     the directory name where the various output files should be written.
--
-- (3) Improved error handling (WHENEVER SQLERROR EXIT/WHENEVER OSERROR EXIT)
--     and progress messages (set termout on/off around the "spool ..." commands.
--
-- It generates a file for each type of schema object.
--
-- The output files might have a name like:
--  schemaDump_Tables.lst
--
-- It will ignore well known non-Rating and Billing objects such as "PLAN_TABLE".
--
-- It will also ignore any "VERSION_RB" type tables, since this table only
-- exists at certain times, and it might cause confusion.
--
-- It will also ignore the "MIGRATIONPROCESS" bootstrap table.
--
-- It will also ignore the "MIGTABLESPACES" working table.
--
-- It will ignore changes to the customizable Rating and Billing tables
-- CUSTOMERATTRIBUTES and ACCOUNTATTRIBUTES, except for their mandatory primary keys.
--
-- It will also ignore column order within tables due to CR 28804 - which means
-- two separate schemas will pass for identical if their column orders are in
-- different orders - so long as the datatypes, precision values and nullabilities
-- are the same.
--
-- Copyright :   NetCracker Technology Corporation 2012
--
-- *********************************************************
set termout off
WHENEVER SQLERROR EXIT
WHENEVER OSERROR EXIT

-- Set output format correctly

set echo off
set scan on

-- Ensure sort order is same regardless of nls_language
alter session set NLS_SORT = BINARY;

set trimspool on
set pagesize 50000
set linesize 255
set feed off
set head off
set verify off
set termout on
select 'Dumping schema for user ' || USERNAME from all_users where USERNAME = '&vSchemaOwner';
set termout off
set head on
set long 10000
set arraysize 5

-- Capture Directory Name

define gOutputDirName = &1

define gFilenamePrefix = schemaDump

-- Setup formatting for each column

column clu_column_name  format a30      heading "Cluster Column|Name"
column column_name      format a30      heading "Column|Name"
column column_position  format 999      heading "Col|Pos"
column cluster_name     format a30      heading "Cluster|Name"
column data_length      format 99999    heading "Data|Length"
column data_scale       format 99999    heading "Data|Scale"
column data_precision   format 99999    heading "Data|Precision"
column data_type        format a30      heading "Data|Type"
column description      format a160     heading "Trigger|Description" fold_before
column index_name       format a30      heading "Index|Name"
column sequence_name    format a30      heading "Sequence|Name"
column tab_column_name  format a30      heading "Table Column|Name"
column table_name       format a30      heading "Table|Name"
column text                             heading "Source|Code"
column trigger_name     format a30      heading "Trigger|Name"
column trigger_type                     heading "Trigger|Type"
column triggering_event format a10      heading "Triggering|Event"
column view_name        format a30      heading "View|Name"
column when_clause      format a160     heading "Trigger|When Clause" fold_before

-----------------------------------------------------------------------
-- Dump Tables
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Tables.lst
prompt Dump Tables
set termout off
prompt TABLE DEFINITIONS
prompt

select /*+ ALL_ROWS */ TABLE_NAME,
      COLUMN_NAME,
      DATA_TYPE,
      DATA_LENGTH,
      DATA_PRECISION,
      DATA_SCALE,
      NULLABLE
from  ALL_TAB_COLUMNS
where OWNER = '&vSchemaOwner'
and   TABLE_NAME NOT LIKE 'PV%'
and   TABLE_NAME NOT LIKE 'IV%'
and   TABLE_NAME NOT LIKE 'WEB%'
and   TABLE_NAME NOT LIKE '%TAP3%'
and   TABLE_NAME NOT LIKE 'SPD%'
and   TABLE_NAME NOT LIKE '%VERSION_RB%'
and   TABLE_NAME NOT LIKE '%VERSION_GENEVA%'
and   TABLE_NAME NOT LIKE 'BIN$%'
and   TABLE_NAME NOT IN ('MIGRATIONPROCESS', 'PLAN_TABLE', 'MIGTABLESPACES')
and   TABLE_NAME NOT LIKE 'PARTITIONMANAGER%'
and   TABLE_NAME NOT LIKE 'PARTMANAGER%'
and   TABLE_NAME NOT LIKE '%$%'
and   TABLE_NAME NOT IN (select QUEUE_TABLE from ALL_QUEUE_TABLES where OWNER = '&vSchemaOwner')
and   TABLE_NAME NOT IN (select VIEW_NAME from ALL_VIEWS
                         where  OWNER = '&vSchemaOwner' and VIEW_NAME like '%QUEUE%')
and (TABLE_NAME <> 'ACCOUNTATTRIBUTES'
      or COLUMN_NAME in ('ACCOUNT_NUM', 'DOMAIN_ID'))
and (TABLE_NAME <> 'CUSTOMERATTRIBUTES'
      or COLUMN_NAME in ('CUSTOMER_REF', 'DOMAIN_ID'))
and (TABLE_NAME <> 'OFFERACCOUNTATTRIBUTES'
      or COLUMN_NAME in ('ACCOUNT_NUM', 'DOMAIN_ID', 'BILLING_OFFER_ID'))
and (TABLE_NAME <> 'SCHEMASTATSLOG'
      or COLUMN_NAME not in ('CL1'))
order by TABLE_NAME, COLUMN_NAME;
spool off

-----------------------------------------------------------------------
-- Dump Indexes
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Indexes.lst
prompt Dump Indexes
set termout off
prompt
prompt
prompt INDEX DEFINITIONS
prompt

select  INDEX_NAME,
        TABLE_NAME,
        COLUMN_POSITION,
        DECODE(SUBSTR(COLUMN_NAME, 0, 4),
               'SYS_', SUBSTR(COLUMN_NAME, 0, 6)||'xxxxx$',
               COLUMN_NAME) COLUMN_NAME
from    ALL_IND_COLUMNS
where   TABLE_OWNER = '&vSchemaOwner'
and     INDEX_NAME NOT LIKE '%VERSION_GENEVA%'
and     INDEX_NAME NOT LIKE '%VERSION_RB%'
and     INDEX_NAME NOT LIKE 'PARTITIONMANAGER%'
and     INDEX_NAME NOT LIKE 'PARTMANAGER%'
and     INDEX_NAME NOT LIKE '%\_URK%' escape '\'
and     INDEX_NAME NOT LIKE '%\_RK%' escape '\'
and     INDEX_NAME NOT LIKE 'WEB%'
and     INDEX_NAME NOT LIKE 'TAP3%'
and     INDEX_NAME NOT LIKE 'SPD%'
and     INDEX_NAME NOT LIKE 'SYS%'
and     INDEX_NAME NOT LIKE '%$%'
and     INDEX_NAME NOT LIKE 'BIN$%'
order by INDEX_NAME, COLUMN_POSITION;
spool off

-----------------------------------------------------------------------
-- Dump Constraints
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Constraints.lst
prompt Dump Constraints
set termout off
prompt
prompt
prompt CONSTRAINT DEFINITIONS
prompt

select /*+ ALL_ROWS*/ constraint_name,
       uc.constraint_type,
       ucc.table_name,
       uc.index_name,
       position,
       ucc.column_name
from   user_constraints uc
join   user_cons_columns ucc using (owner, constraint_name)
where  uc.constraint_type in ('P', 'U', 'C')
and    constraint_name not like 'PARTMANAGER%'
and    constraint_name not like '%\_URK%' escape '\'
and    constraint_name not like '%\_RK%' escape '\'
and    constraint_name not like 'SYS%'
and    constraint_name not like 'BIN$%'
and    constraint_name not like 'TAP3%'
and    constraint_name not like '%$%'
order by constraint_name, ucc.position;

spool off

-----------------------------------------------------------------------
-- Dump Clusters
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Clusters.lst
prompt Dump Clusters
set termout off
prompt
prompt
prompt CLUSTER DEFINITIONS
prompt
prompt Note: occasionally the cluster has been renamed. Providing that the
prompt definitions are the same, the name is not important.
prompt

select  CLUSTER_NAME,
        CLU_COLUMN_NAME,
        TABLE_NAME,
        TAB_COLUMN_NAME
from    DBA_CLU_COLUMNS
where   OWNER = '&vSchemaOwner'
and     CLUSTER_NAME not like '%TAP3%'
order by TABLE_NAME, TAB_COLUMN_NAME;
spool off

-----------------------------------------------------------------------
-- Dump Sequences
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Sequences.lst
prompt Dump Sequences
set termout off
prompt
prompt
prompt SEQUENCES
prompt

select  SEQUENCE_NAME
from    ALL_SEQUENCES
where   SEQUENCE_OWNER = '&vSchemaOwner'
and     SEQUENCE_NAME NOT LIKE 'AQ$_%'
order by SEQUENCE_NAME;
spool off

-----------------------------------------------------------------------
-- Dump Triggers
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Triggers.lst
prompt Dump Triggers
set termout off
prompt
prompt
prompt TRIGGER DEFINITIONS
prompt

select  TRIGGER_NAME,
        TRIGGER_TYPE,
        TRIGGERING_EVENT,
        TABLE_NAME,
        trim(DESCRIPTION) as DESCRIPTION,
        nvl(WHEN_CLAUSE,'No When Clause') as WHEN_CLAUSE
from    ALL_TRIGGERS
where   OWNER = '&vSchemaOwner'
and     TABLE_NAME not like '%VERSION_RB%'
and     TABLE_NAME not like '%VERSION_GENEVA%'
and     TABLE_NAME not like 'TAP3%'
and     TRIGGER_NAME not like 'BIN$%'
order by TRIGGER_NAME;
spool off

set termout on
spool &gOutputDirName/&gFilenamePrefix._TriggerBodies.lst
prompt Dump Trigger Bodies
set termout off
prompt
prompt
prompt TRIGGER SOURCE CODE
prompt
prompt (This has been run against Oracle 8 which will store blank lines. On
prompt Oracle 7 they were not stored. If the only difference is the presence
prompt of blank lines then please ignore the differences)
prompt

select  TRIGGER_NAME,
        TRIGGER_BODY
from    ALL_TRIGGERS
where   OWNER = '&vSchemaOwner'
and     TABLE_NAME not like 'TAP3%'
and     TRIGGER_NAME not like 'BIN$%'
order by TRIGGER_NAME;
spool off

-----------------------------------------------------------------------
-- Dump Current Views
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Views.lst
prompt Dump Current Views
set termout off
prompt
prompt
prompt CURRENT VIEW DEFINITIONS
prompt

select  VIEW_NAME,
        TEXT
from    (
        select VIEW_NAME,
               translate(v1.VIEW_NAME,'P0123456789','P') as STUB_NAME,
               TO_NUMBER(nvl(translate(v1.VIEW_NAME,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$', '0123456789'), '1')) as VERSION,
               TEXT
        from   ALL_VIEWS v1
        where  OWNER = '&vSchemaOwner'
        and    v1.VIEW_NAME like 'PV%'
        and    v1.VIEW_NAME not like 'PVTAP3%'
        and    v1.VIEW_NAME not like 'PVSPD%') v
where not exists (
        select 1
        from   user_views o
        where  translate(o.view_name,'P0123456789','P') = v.stub_name
        and    TO_NUMBER(nvl(translate(o.VIEW_NAME,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$', '0123456789'), '1')) > v.VERSION
        and    o.view_name like 'PV%'
  )
and exists (
        select 1
        from user_tables t
        where table_name = substr(v.stub_name,3))
order by VIEW_NAME;
spool off

-----------------------------------------------------------------------
-- Dump Superseded Views
-----------------------------------------------------------------------

set termout on
spool &gOutputDirName/&gFilenamePrefix._Views_Old.lst
prompt Dump Superseded Views
set termout off
prompt
prompt
prompt SUPERSEDED VIEW DEFINITIONS
prompt

select  VIEW_NAME,
        TEXT
from    (
        select VIEW_NAME,
               translate(v1.VIEW_NAME,'P0123456789','P') as STUB_NAME,
               TO_NUMBER(nvl(translate(v1.VIEW_NAME,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$', '0123456789'), '1')) as VERSION,
               TEXT
        from   ALL_VIEWS v1
        where  OWNER = '&vSchemaOwner'
        and    v1.VIEW_NAME like 'PV%'
        and    v1.VIEW_NAME not like 'PVTAP3%'
        and    v1.VIEW_NAME not like 'PVSPD%') v
where exists (
        select 1
        from   user_views o
        where  translate(o.view_name,'P0123456789','P') = v.stub_name
        and    TO_NUMBER(nvl(translate(o.VIEW_NAME,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$', '0123456789'), '1')) > v.VERSION
        and    o.view_name like 'PV%'
  )
or not exists (
        select 1
        from user_tables t
        where table_name = substr(v.stub_name,3))
order by VIEW_NAME;
spool off

-- End of dumpschema script
