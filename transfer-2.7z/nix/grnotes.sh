#!/usr/bin/ksh
##########################################################
# 16 aug 2011 - cam - v1.0
##########################################################
# Create a directory containing the usual release format
# of a directory named patchname.client containing a zipfile. 

echo "`date +%Y-%m-%d_%H:%M`: Starting "
RNOTES=/home/cdsinf22/cam/rnotes
for archive in $(ls $1/*.zip); do
    	unzip -j ${archive} RB/RB/doc/release_notes* -d ${RNOTES}
done

echo "`date +%Y-%m-%d_%H:%M`: Completed."
