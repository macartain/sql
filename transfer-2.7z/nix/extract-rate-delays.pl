use strict;
use File::Spec::Functions;
use Time::Local;

sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

sub checkDir {
   my $dirname = shift;
   opendir(DIR,$dirname);
   my @files=grep(/\.log$/,readdir(DIR));
   closedir DIR;
   my $filename;
   foreach $filename (@files) {
      if(not $filename =~ /run(\d\d\d)_(.*?).log/) {
         next;
      }
      my $runnumber = $1;
      my ($starttime, $endtime, $stepstart, $stepend, $stepnumber, $stepname, @steps);
      $starttime = undef;
      $endtime = undef;
      my ($startdatetime, $enddatetime, $stepstartdatetime, $stependdatetime);
      my $path = catfile($dirname,$filename);
      open( FILE, "< $path" ) or die "Can't open $filename : $!";
      while( <FILE> ) {
          if (/INFORM: ((\d\d\d\d)\/(\d\d)\/(\d\d) (\d\d):(\d\d):(\d\d)) (Begin|Restarting) script/) {
              $starttime=$1;
              $startdatetime=timelocal($7,$6,$5,$4,($3-1),$2);
          }
          if (/INFORM: ((\d\d\d\d)\/(\d\d)\/(\d\d) (\d\d):(\d\d):(\d\d)) End script/) {
              $endtime=$1;
              $enddatetime=timelocal($7,$6,$5,$4,($3-1),$2);
          }
          if (/INFORM: ((\d\d\d\d)\/(\d\d)\/(\d\d) (\d\d):(\d\d):(\d\d)) Step: STEP-(\d\d\d) before (.*)/) {
              $stepstart = $1;
              $stepnumber = $8;
              $stepname = $9;
              $stepstartdatetime=timelocal($7,$6,$5,$4,($3-1),$2);
          }
          if (/INFORM: ((\d\d\d\d)\/(\d\d)\/(\d\d) (\d\d):(\d\d):(\d\d)) Step: STEP-(\d\d\d) after (.*)/) {
              $stepend = $1;
              $stependdatetime=timelocal($7,$6,$5,$4,($3-1),$2);
              my $stepdifference = undef;
              if(defined() and defined()) {
                  $stepdifference=$stependdatetime-$stepstartdatetime;
              }
              push(@steps, ($stepnumber, $stepstart, $stepend, trim($stepname),$stepdifference));
          }
      }
      my $difference;
      if(defined($starttime) and defined($endtime)) {
          $difference=$enddatetime-$startdatetime;
      } else {
          $difference = undef;
      }
      print "$runnumber,$filename,$starttime,$endtime,$difference\n";
      my ($stepnr, $stepst, $stepe, $stepn,$stepdiff);
      while($#steps > 0) {
         $stepnr=shift(@steps);
         $stepst=shift(@steps);
         $stepe=shift(@steps);
         $stepn=shift(@steps); 
         $stepdiff=shift(@steps);
         print "$runnumber,-> STEP-$stepnr $stepn,$stepst,$stepe,$stepdiff\n";
      }
      close FILE;
   }
}

my $numArgs = $#ARGV + 1;

if($numArgs != 1) {
   print "Usage: get_timings.pl log_directory"; 
} else {
   my $dirname = $ARGV[0];
   checkDir($dirname);
}


