#!/bin/ksh

# polling interval in seconds
POLLING_INTERVAL=2

# source & dest dirs
FROM=/tmp/colm/PF/platform/schema/install/scripts
TO=/tmp/colm/test

# batch size - number of files to transfer
BATCHSIZE=3

cd $FROM
while true; do
		for FILENAME in `ls -t | head -$BATCHSIZE`; do
			echo Moving $FILENAME
			mv $FILENAME ${TO}/.			
		done
		echo Done at `date`

        sleep $POLLING_INTERVAL
done
