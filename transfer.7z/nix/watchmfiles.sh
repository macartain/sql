#!/bin/ksh

rm old-managedfiles

while true; do
        ps -ef > current-processes
        dnum=`date +"%Y%m%d"`
        ls -la /geneva_data/geneva/mf/default/$dnum | awk '{print $9}' > current-managedfiles
        diff current-managedfiles old-managedfiles | grep ">" > changes
        if [[ $? = 0 ]]
        then
                echo Problem!
                echo `date` >>incident-logs/current-processes
                cat current-processes >>incident-logs/current-processes
                echo `date` >>incident-logs/changes
                cat changes >>incident-logs/changes
        fi
        mv current-managedfiles old-managedfiles
        sleep 2
done
