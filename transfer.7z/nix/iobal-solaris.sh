#!/bin/sh
#
# TITLE:   iobal
#
# PURPOSE: awk to process iostat -x[n] output & aggregate stats by ranges of percent busy
#          This version figures out by itself whether input is from iostat -x or iostat -xn
#
# AUTHOR:  robert.smith@east.sun.com -- Unsupported tool, use or modify at your own risk
#

# iostat -x header, awk column position, variable for aggregation:
#                          extended device statistics          cpu
# device       r/s  w/s   Kr/s   Kw/s wait actv  svc_t  %w  %b  us sy wt id
# $1           $2   $3    $4     $5   $6   $7    $8     $9  $10 -  -  -  - 
# this_devname rs   ws    krs    kws  wait actv  svct   pctw pctb (the rest are ignored)

# iostat -xn on Solaris 2.6 and later
#  extended device statistics
#  r/s  w/s   kr/s   kw/s wait actv wsvc_t asvc_t  %w   %b    device
#  $1   $2    $3     $4   $5   $6   $7     $8      $9   $10   $11          -  -  -  - 
#  rs   ws    krs    kws  wait actv wsvct  asvct   pctw pctb  this_devname  (any others are ignored)

BANNER="Local Physical Disk Load Balance: iobal v2.4 14Aug2002\n"

BFLAG=1	# Print Balance report if true
CFLAG=0	# Print Controller report if true
TFLAG=0	# Print Throughput report if true
IFLAG=0	# Print IOPS report if true
SFLAG=0	# Print Service Time report if true
NFLAG=1	# Must be followed by number of drives to display in TOP reports
TOP=10  # Default number of disks to report top stats

USAGE="\nUsage: iobal [-tis] [-n number] iostat-file\n \
       Help:    iobal -h\n \
       Version: iobal -v\n"

HELP="\nUsage: iobal [-tis] [-n number] iostat-file\n \
               iostat -x[n] interval | iobal [-tis] [-n number] - \n \
      -t Report top n drives by Throughput (KBytes/sec)\n \
      -i Report top n drives by IOPS (I/O operations per second)\n \
      -s Report top n drives by Service Time (avg millseconds response time)\n \
      -n number, how many drives to include in top reports,\n \
         only with t, s or i options.  Defaults to 10 if omitted.\n
      iobal -h Display this help and exit\n \
      iobal -v Display version and exit\n \
\nFile Example: Report top 22 drives by Throughput, IOPS and Service Time\n \
iobal -n 22 -tsi iostat-xn30.out | more\n \
\nInteractive Example: Report top 10 drives by Service Time\n \
iostat -xn 30 | iobal -s - \n"

while getopts bctishvn: SWCH
do
   case $SWCH in
        b)   BFLAG=1;;
        c)   CFLAG=1;;
        t)   TFLAG=1;;
        i)   IFLAG=1;;
        s)   SFLAG=1;;
        h)   echo $HELP; exit 0;;
        v)   echo $BANNER; exit 0;;
        n)   TOP=${OPTARG}; NFLAG=1;;
       \?)   echo $USAGE
             exit 2;;
   esac
done

shift `expr $OPTIND - 1`
FILE="$*"
if [ -z "$FILE" ]; then
   echo "\niobal: no input file"
   echo $USAGE
   exit 3
elif [ "$FILE" = "-" ] ; then
   echo $BANNER
   echo "Input file is stdin"
else
   echo $BANNER
   echo "Input file is $FILE"
fi

# Must use exec to allow option of reading from pipe or stdin
# Must use nawk to get user-defined functions
exec nawk 'BEGIN { init_vars()
                   iter = 0  }

     /extended/ {next}


     /wait/     {
                  if ($6 ~ /wait/) input_type="X"
                  else if ($5 ~ /wait/) input_type="N"
                  else {print "iobal: Fatal: Bad input file"; exit 4}

                  iter++	# This counts the number of iostat iterations -- never reset
                  ndevs--       # Adjust for funny count
                  active_devs = ndevs - idle_devs   # No kidding
                  busy[0] -= idle_devs   # Subtract completely idle drives from busy stats

                  if (ndevs>0) {
                     # Compute avg io sizes within busy ranges
                     for (i=0; i<=BUSY_RANGE; i++) {
                          if (rs_a[i]>0) 
                             avg_read_a[i]=krs_a[i]/rs_a[i]
                          else
                             avg_read_a[i]=0
                          if (ws_a[i]>0) 
                             avg_write_a[i]=kws_a[i]/ws_a[i]
                          else
                             avg_write_a[i]=0
                          if (busy[i]>0) {
                              avg_wait_a[i]  = wait_a[i]/busy[i]
                              avg_actv_a[i]  = actv_a[i]/busy[i]
                              avg_svct_a[i]  = svct_a[i]/busy[i]
                              avg_wsvct_a[i] = wsvct_a[i]/busy[i]
                              avg_asvct_a[i] = asvct_a[i]/busy[i]
                              avg_pctw_a[i]  = pctw_a[i]/busy[i]
                              avg_pctb_a[i]  = pctb_a[i]/busy[i]
                              }
                          else {
                              avg_wait_a[i]  = 0
                              avg_actv_a[i]  = 0
                              avg_svct_a[i]  = 0
                              avg_wsvct_a[i] = 0
                              avg_asvct_a[i] = 0
                              avg_pctw_a[i]  = 0
                              avg_pctb_a[i]  = 0
                              }
                     }
                     # Compute some averages for this whole iteration
                     if (rs>0) 
                        avg_read=krs/rs
                     else
                        avg_read=0

                     if (ws>0) 
                        avg_write=kws/ws
                     else
                        avg_write=0

                     if (active_devs>0) {
                        avg_wait  = wait/active_devs
                        avg_actv  = actv/active_devs
                        avg_svct  = svct/active_devs
                        avg_wsvct = wsvct/active_devs
                        avg_asvct = asvct/active_devs
                        avg_pctw  = pctw/active_devs
                        avg_pctb  = pctb/active_devs
                        avg_wasvct = (wsvct + asvct)/active_devs
                        avg_iops   = (rs + ws)/active_devs
                     }
                     else {
                        avg_wait  = 0
                        avg_actv  = 0
                        avg_svct  = 0
                        avg_wsvct = 0
                        avg_asvct = 0
                        avg_pctw  = 0
                        avg_pctb  = 0
                        avg_wasvct = 0
                        avg_iops   = 0
                     }
 
                     if (kbs>0) 
                        for (i=0; i<TOP_RANGE; i++)
                            pct_io[i]=krws_a[i]/kbs
                     else
                        for (i=0; i<TOP_RANGE; i++)
                            pct_io[i]=0

                     if (iops>0) 
                        for (i=0; i<TOP_RANGE; i++)
                            pct_rws[i]=rws_a[i]/iops
                     else
                        for (i=0; i<TOP_RANGE; i++)
                            pct_rws[i]=0



                     # Print it all out
                     report_busy_ranges()

                     if (T_FLAG==1) {
                        printf ("\n%d most active drives or LUNs by THROUGHPUT = KB read+written/sec\n", TOP_RANGE)
                        printf ("\n%-15s  %-19s  %-17s\n", "Disk", "       Total KB/sec", "% of Total KB/sec")
                        printf ("%-15s  %-19s  %-17s\n", "---------------", "-------------------", "-----------------")
                        printf ("%-15s  %12.2f KB/sec  %16.1f%%\n", "All Disks", kbs, 100)
                        for (i=0; i<TOP_RANGE; i++)
                            printf ("%-15s  %12.2f KB/sec  %16.1f%%\n", device_top_krws[i], krws_a[i], pct_io[i]*100)
                     }

                     if (I_FLAG==1) {
                        printf ("\n%d most active drives or LUNs by IOPS = reads+writes/sec\n", TOP_RANGE)
                        printf ("\n%-15s  %-14s  %-15s\n", "Disk", "    Total IOPS", "% of Total IOPS")
                        printf ("%-15s  %-14s  %-15s\n", "---------------", "--------------", "---------------")
                        printf ("%-15s  %9.2f iops  %14.1f%%\n", "All Disks", iops, 100)
                        for (i=0; i<TOP_RANGE; i++)
 	 	            printf ("%-15s  %9.2f iops  %14.1f%%\n", device_top_rws[i], rws_a[i], pct_rws[i]*100)
                     }

                     if (S_FLAG==1) {
                        printf ("\n%d slowest drives or LUNs by Service Time =" \
                                "avg_wait_service_time + avg_active_service_time(ms)\n", TOP_RANGE)
 	 	        printf ("\n%-15s  %-20s  %14s\n", "Disk", "Avg Service Time(ms)", "Avg IOPS/device")
 	 	        printf ("%-15s  %-20s  %-14s\n", "---------------", "--------------------", "---------------")

                        if (input_type=="X")
 	 	           printf ("%-15s  %17.2f ms   %14.2f\n", "All Disks", avg_svct, avg_iops)
                        else 
 	 	           printf ("%-15s  %17.2f ms   %14.2f\n", "All Disks", avg_wasvct, avg_iops)

                        for (i=0; i<TOP_RANGE; i++)
                           printf ("%-15s  %17.2f ms   %14.2f\n", device_top_svct[i], wasvct_a[i], svct_iops_a[i])
                     }

                     # Reset counters for next interval
                     init_vars()
                }  # end if ndevs > 0
     }  # End wait regex

     # Solaris 2.6 iostat on systems with A1000, A3000, A3500 can produce mix of sd and ctd names
     /c.*t.*d.*|sd/ {
                  # Gather data from all local physical drives 
                  # (This regex omits DiskSuite volumes, NFS, tape)

                  if (input_type=="X") { 
                     this_devname = $1
                     this_rs      = $2
                     this_ws      = $3
                     this_krs     = $4
                     this_kws     = $5
                     this_wait    = $6
                     this_actv    = $7
                     this_svct    = $8
                     this_pctw    = $9
                     this_pctb    = $10
                     }
                  else if (input_type=="N") {
                     this_rs      = $1
                     this_ws      = $2
                     this_krs     = $3
                     this_kws     = $4
                     this_wait    = $5
                     this_actv    = $6
                     this_wsvct   = $7
                     this_asvct   = $8
                     this_pctw    = $9
                     this_pctb    = $10
                     this_devname = $11
                     }
                  else {
                     printf ("iobal: Fatal: Bad input type: %s\n", input_type)
                     exit 5
                     }

                  # Count completely idle drives
                  if (this_rs    == 0.0 && \
                      this_ws    == 0.0 && \
                      this_krs   == 0.0 && \
                      this_kws   == 0.0 && \
                      this_wait  == 0.0 && \
                      this_actv  == 0.0 && \
                      this_svct  == 0.0 && \
                      this_wsvct == 0.0 && \
                      this_asvct == 0.0 && \
                      this_pctw  == 0   && \
                      this_pctb  == 0) {ctlr_idle_devs_a[this_ctlr]++
                                        ctlr_idle_devs_a["All"]++
                                        idle_devs++ }

                  # Aggregate values for TOP reports (by individual device)
                  krws = this_krs + this_kws
                  rws  = this_rs + this_ws
                  if (input_type == "X")
                     wasvct = this_svct
                  else
                     wasvct = this_wsvct + this_asvct

                  # Sum up totals for all devices within this iostat iteration
                  ndevs++ 
                  rs    += this_rs
                  ws    += this_ws
                  krs   += this_krs
                  kws   += this_kws
                  wait  += this_wait
                  actv  += this_actv
                  svct  += this_svct
                  wsvct += this_wsvct
                  asvct += this_asvct
                  pctw  += this_pctw
                  pctb  += this_pctb
                  
                  iops += this_rs  + this_ws
                  kbs  += this_krs + this_kws

                  # Find TOP_RANGE busiest drives by Throughput 
                  # (greatest KB read+written/sec)
                  for (i=0; i<TOP_RANGE; i++) {
                      if (krws > krws_a[i]) {
                         j = i
                         while (j<TOP_RANGE) {             # Push stack 
                               krws_a[i+1] = krws_a[i]; device_top_krws[i+1] = device_top_krws[i]
                               j++
                         }
                         krws_a[i]=krws; device_top_krws[i]=this_devname
                         break
                      }
                  }
                  krws=0

                  # Find TOP_RANGE slowest drives (highest svc_t)
                  for (i=0; i<TOP_RANGE; i++) {
                      if (wasvct > wasvct_a[i]) {
                         j = i
                         while (j<TOP_RANGE) {             # Push stack 
                               wasvct_a[i+1] = wasvct_a[i]; device_top_svct[i+1] = device_top_svct[i]
                               svct_iops_a[i+1] = svct_iops_a[i]
                               j++
                         }
                         wasvct_a[i]=wasvct; device_top_svct[i]=this_devname; svct_iops_a[i]=rws
                         break
                      }
                  }
                  wasvct=0

                  # Find TOP_RANGE busiest drives by IOPS (highest reads+writes/sec)
                  for (i=0; i<TOP_RANGE; i++) {
                      if (rws > rws_a[i]) {
                         j = i
                         while (j<TOP_RANGE) {             # Push stack 
                               rws_a[i+1] = rws_a[i]; device_top_rws[i+1] = device_top_rws[i]
                               j++
                         }
                         rws_a[i]=rws; device_top_rws[i]=this_devname
                         break
                      }
                  }
                  rws=0

                  # Break down stats within ranges of percent busy
                  if (this_pctb == 0)                     brange=0
                  else if(this_pctb>0  && this_pctb<=20)  brange=1
                  else if(this_pctb>20 && this_pctb<=40)  brange=2
                  else if(this_pctb>40 && this_pctb<=60)  brange=3
                  else if(this_pctb>60 && this_pctb<=80)  brange=4
                  else if(this_pctb>80)                   brange=5
                  else                                    brange=6    # Should always be all zeros

                  busy[brange]++  # Count devices in each range
                  rs_a[brange]    += this_rs
                  krs_a[brange]   += this_krs
                  ws_a[brange]    += this_ws
                  kws_a[brange]   += this_kws
                  wait_a[brange]  += this_wait
                  actv_a[brange]  += this_actv
                  svct_a[brange]  += this_svct
                  wsvct_a[brange] += this_wsvct
                  asvct_a[brange] += this_asvct
                  pctw_a[brange]  += this_pctw
                  pctb_a[brange]  += this_pctb

}  # End regex

function init_vars() {
   # Initialize all variables and arrays
   BUSY_RANGE=7
   ndevs=0; idle_devs=0; active_devs=0
   this_devname=" "
   rs=0; krs=0                                        # Total per iteration only
   ws=0; kws=0                                        # Total per iteration only
   wait=0; actv=0; asvct=0; wsvct=0; pctw=0; pctb=0   # Total per iteration only
   for (i=0; i<=BUSY_RANGE; i++) {
        busy[i]=0                                               # Disk count in range
        rs_a[i]=0; krs_a[i]=0; ws_a[i]=0; kws_a[i]=0            # Stats in range
        wait_a[i]=0; actv_a[i]=0                                # Stats in range
        svct_a[i]=0                                             # Stats in range
        wsvct_a[i]=0; asvct_a[i]=0; pctw_a[i]=0; pctb_a[i]=0    # Stats in range
        avg_read_a[i]  = 0
        avg_write_a[i] = 0
        avg_wait_a[i]  = 0
        avg_actv_a[i]  = 0
        avg_svct_a[i]  = 0
        avg_wsvct_a[i] = 0
        avg_asvct_a[i] = 0
        avg_pctw_a[i]  = 0
        avg_pctb_a[i]  = 0
   }
#  Averages over whole iteration
   avg_wait  = 0
   avg_actv  = 0
   avg_svct  = 0
   avg_wsvct = 0
   avg_asvct = 0
   avg_pctw  = 0
   avg_pctb  = 0

   krws=0; kbs=0
   for (i=0; i<TOP_RANGE; i++) {
        krws_a[i]=0
        device_top_krws[i]=" "
        pct_io[i]=0
   }
   rws=0; iops=0
   for (i=0; i<TOP_RANGE; i++) {
        rws_a[i]=0
        device_top_rws[i]=" "
        pct_rws[i]=0
   }
   wasvct=0; iops=0
   for (i=0; i<TOP_RANGE; i++) {
        wasvct_a[i]=0
        device_top_svct[i]=" "
        svct_iops_a[i]=0
   }
}  # End function init_vars()

function report_busy_ranges() {
   printf ("\n")
   printf ("\niostat interval number: %d   Total drives: %d   Idle drives: %d\n", \
            iter, ndevs, idle_devs)

   printf ("%% Busy Range:   %10s  %10s  %10s  %10s  %10s  %10s  %10s\n", \
           ".01-.99", "1-20", "21-40", "41-60", "61-80", ">80", "TOTAL")
   printf ("--------------  ----------  ----------  ----------  ----------  ----------  ----------  ----------\n")
   printf ("Disks           %10d  %10d  %10d  %10d  %10d  %10d  %10d\n", \
            busy[0], busy[1], busy[2], busy[3], busy[4], busy[5], ndevs)
   printf ("Reads/sec       %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            rs_a[0], rs_a[1], rs_a[2], rs_a[3], rs_a[4], rs_a[5], rs)
   printf ("KB Read/sec     %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            krs_a[0], krs_a[1], krs_a[2], krs_a[3], krs_a[4], krs_a[5], krs)
   printf ("Avg KB/Read     %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_read_a[0], avg_read_a[1], avg_read_a[2], avg_read_a[3], avg_read_a[4], avg_read_a[5], \
            avg_read)
   printf ("Writes/sec      %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            ws_a[0], ws_a[1], ws_a[2], ws_a[3], ws_a[4], ws_a[5], ws)
   printf ("KB Written/sec  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            kws_a[0], kws_a[1], kws_a[2], kws_a[3], kws_a[4], kws_a[5], kws)
   printf ("Avg KB/Write    %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_write_a[0], avg_write_a[1], avg_write_a[2], avg_write_a[3], avg_write_a[4], avg_write_a[5], \
            avg_write)
   printf ("Avg Wait Cmds   %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_wait_a[0], avg_wait_a[1], avg_wait_a[2], avg_wait_a[3], avg_wait_a[4], avg_wait_a[5], \
            avg_wait)
   printf ("Avg Active Cmds %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_actv_a[0], avg_actv_a[1], avg_actv_a[2], avg_actv_a[3], avg_actv_a[4], avg_actv_a[5], \
            avg_actv)
   if (input_type == "X")
       printf ("Avg SvcTime(ms) %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
                avg_svct_a[0], avg_svct_a[1], avg_svct_a[2], avg_svct_a[3], avg_svct_a[4], avg_svct_a[5], \
                avg_svct)
   else {
       printf ("Avg WSvcTime(ms)%10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
                avg_wsvct_a[0], avg_wsvct_a[1], avg_wsvct_a[2], avg_wsvct_a[3], avg_wsvct_a[4], avg_wsvct_a[5], \
                avg_wsvct)
       printf ("Avg ASvcTime(ms)%10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
                avg_asvct_a[0], avg_asvct_a[1], avg_asvct_a[2], avg_asvct_a[3], avg_asvct_a[4], avg_asvct_a[5], \
                avg_asvct)
   }
   printf ("Avg %% Wait      %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_pctw_a[0], avg_pctw_a[1], avg_pctw_a[2], avg_pctw_a[3], avg_pctw_a[4], avg_pctw_a[5], \
            avg_pctw)
   printf ("Avg %% Busy      %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f  %10.2f\n", \
            avg_pctb_a[0], avg_pctb_a[1], avg_pctb_a[2], avg_pctb_a[3], avg_pctb_a[4], avg_pctb_a[5], \
            avg_pctb)

} # End function report_busy_ranges()

# Pass variables from shell to nawk and end whole nawk script
' TOP_RANGE=$TOP S_FLAG=$SFLAG I_FLAG=$IFLAG T_FLAG=$TFLAG C_FLAG=$CFLAG $FILE