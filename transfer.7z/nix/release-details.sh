#!/usr/bin/ksh
##########################################################
# 16 mar 2011 - cam - v1.0
##########################################################

echo "`date +%Y-%m-%d_%H:%M`: Starting "

for dir in $1
	cd $dir
	print $dir
done

echo "`date +%Y-%m-%d_%H:%M`: Completed."