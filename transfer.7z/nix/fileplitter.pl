#!/usr/bin/perl

# Open file for read OR exit if file does not exist
$infile = shift(@ARGV);
open(INFILE, "$infile") || die "File \"$infile\" does not exist\n";

while ($record = <INFILE>)
{
        @line_fields = split(/ /,$record);

        $comms = $line_fields[9];
        $av_start = $line_fields[10];
        $av_moving = $line_fields[11];

        printf("%s,%d\n",$line_fields[1], $line_fields[3]);
}
close(INFILE);
