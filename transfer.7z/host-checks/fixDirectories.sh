#!/bin/ksh

# Script to ensure directories are correct on the remote machines

    rootDir=$1
    subDir=`hostname`       # this is for when the master machine is itself being checked
                            # and we want to keep the per-machine files separate from the master stuff

    # Does the root directory exist with the correct permission? (it should)
    if [[ ! -d $rootDir ]]; then
	mkdir $rootDir

	# did that work?
	if [[ ! -d $rootDir ]]; then
	    print "Error: Root directory $rootDir does not exist and couldn't create it"
	    exit 1
	fi
    fi

    if [[ ! ( -w $rootDir && -x $rootDir ) ]]; then
	print "Error: Can't create a directory in $rootDir"
	exit 1
    fi

    # Does the sub directory exist? (it shouldn't)
    rundir=$rootDir/$subDir

    if [[ -a $rundir ]]; then
	print "Error: Output directory $rundir already exists for this run."
	exit 1
    fi

    # create the run directory
    mkdir $rundir
    chmod +wx $rundir       # being paranoid

    # create the results directory
    resultsdir=$rundir/results
    mkdir $resultsdir
    chmod +wx $resultsdir   # being paranoid

    # create the working directory
    tempdir=$rundir/working
    mkdir $tempdir
    chmod +wx $tempdir   # being paranoid

    # create the scripts directory
    scriptdir=$rundir/scripts
    mkdir $scriptdir
    chmod +wx $scriptdir   # being paranoid


