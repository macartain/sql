#!/bin/ksh

# definition of checks to do on the master once the checks on the remote machines have finished
#
# Bob Salmon
# 25th May 2010

###############################################################################################
#
# Function definitions
#
###############################################################################################

# look at all the subnet / cluster pairs reported from the remote machines
# if all machines for a given cluster have the same subnet, that's great
function f_SubnetCheck {

    typeset outputFile 

    outputFile=$1

    cat $RUN_DIR/*/subnet.* | awk 'BEGIN {failed=0} \
                                         {if (subnet[$1] == "") \
                                             {subnet[$1]=$2} \
                                          else \
                                             {if (subnet[$1] != $2) \
                                                {badSubnet[$1]=1; failed=1}}} \
                                   END   {totalClusters=0; \
	                                  printf "INFO cluster_subnet clusters found:"; \
                                          for (i in subnet) \
                                              {totalClusters++; printf " %s", i}; \
                                          printf "\n"; \
                                          if (failed == 1) \
                                             {totalBadClusters=0; \
	                                      printf "INFO cluster_subnet bad clusters:"; \
	                                      for (i in badSubnet) \
                                                  {totalBadClusters++; printf " %s", i}; \
                                              printf "\n"; \
                                              print "TEST cluster_subnet " totalClusters " cluster[s] checked, " totalBadClusters " bad cluster[s] found: FAILED"} \
                                         else print "TEST cluster_subnet " totalClusters " cluster[s] checked OK: PASSED"}' >> $outputFile

}

# Tests that the unix user and group names are the same for all db instances in the system
function f_checkDBunixUser {

    typeset outputfile

    outputFile=$1

    cat $RUN_DIR/*/dbunixuser.* | awk 'BEGIN {failed=0; firstUser=""; firstGroup=""; firstProc=""; numChecked=0} \
	                                     {numChecked++; \
                                              if (firstUser == "") {firstUser=$1; firstGroup=$2; firstProc=$3} \
                                              else {if (firstUser != $1) {badUser=$1; badGroup=$2; badProc=$3; failed=1}; \
                                                    if (firstGroup != $2) {badUser=$1; badGroup=$2; badProc=$3; failed=1}}} \
                                       END {if (failed == 0) {printf "TEST checkDBunixUser checked %d db instances, all have user=%s and group=%s PASSED", numChecked, firstUser, firstGroup} \
                                            else {printf "TEST checkDBunixUser checked %d db instances, found at least different set-ups: (%s, %s, %s) and (%s, %s, %s) FAILED", numChecked, firstUser, firstGroup, firstProc, badUser, badGroup, badProc}}' >> $outputFile


}

