#!/bin/ksh

# basic check for being able to see a database
# argument = db name
function canSeeDB {

    typeset dbName checkCommand

    if [[ $# -ne 1 ]]; then
        logFailure "canSeeDB" "bad arguments in config file - need 1 args = database name"
	return
    fi

    dbName=$1

    if [[ "${ORACLE_HOME}" = "" ]]; then
	logFailure canSeeDB "please set ORACLE_HOME in config file"
    fi

    checkCommand=$ORACLE_HOME/bin/tnsping

    $checkCommand $dbName | tail -n 1 | awk 'BEGIN {dbn="'$dbName'"} \
               {if ($1 == "OK") {printf "TEST canSeeDB %s PASSED\n", dbn} \
                else {printf "TEST canSeeDB %s Error=\"%s\" FAILED\n", dbn, $0}}' >> $RESULT_FILE
    
}


function executableInOracleBin {
    
    typeset executableName testName

    executableName=$1
    testName=$2

    if [ -x ${ORACLE_HOME}/bin/$executableName ]; then
	echo "$executableName exists in ${ORACLE_HOME}/bin and is executable"

	error=0
    else
	logFailure $testName "can't find an executable $executableName binary in ORACLE_HOME/bin ${ORACLE_HOME}/bin"
	error=1
    fi
}


# tests the generic Oracle stuff for a db user - ORACLE_HOME etc.
function baseOracleSetup {

    if [[ "${ORACLE_HOME}" = "" ]]; then
	logFailure baseOracleSetup "please set ORACLE_HOME in config file"
	return 0
    fi

    # test that the directory pointed to by ORACLE_HOME exists and is accessible
    if [ -d "${ORACLE_HOME}" ]; then
	echo "ORACLE_HOME directory ${ORACLE_HOME} exists"

	if [[ -r "${ORACLE_HOME}" && -x "${ORACLE_HOME}" ]]; then
	    echo "ORACLE_HOME directory ${ORACLE_HOME} can be read and executed"
	else
	    logFailure baseOracleSetup "ORACLE_HOME ${ORACLE_HOME} isn't readable and executable"

	    # no point in doing the rest of this function
	    return
	fi
    else
	logFailure baseOracleSetup "ORACLE_HOME ${ORACLE_HOME} isn't a valid directory"

	# no point in doing the rest of this function
	return
    fi

    # test that sqlplus is available (don't assume it's in PATH)
    executableInOracleBin "sqlplus" "baseOracleSetUp"

    if [ $error -eq 0 ]; then
	executableInOracleBin "tnsping" "baseOracleSetup"
    fi

    if [ $error -eq 0 ]; then
	if [ -z "${DATABASE}" ]; then
	    logFailure baseOracleSetup "please set DATABASE environment variable in config file"
	    error=1
	fi
    fi

    if [ $error -eq 0 ]; then
	if [ "`echo 'exit;' | ${ORACLE_HOME}/bin/sqlplus ${DATABASE} | fgrep Connected`" = "" ]; then
	    logFailure baseOracleSetup "Cannot connect to db ${DATABASE} with sqlplus"
	    error=1
	else
	    echo "Can connect to db $DATABASE with sqlplus"
	fi
    fi

    # if you've got this far, the test has passed
    if [ $error -eq 0 ]; then
	logSuccess baseOracleSetup
    fi
}


# Internal function (not a check).  Uses sqlplus to execute the passed in select statement,
# redirecting output to the file whose name is passed in (file is overwritten if it already exists).
function selectToFile {

    typeset selectString outputFile

    selectString=$1
    outputFile=$2

    echo "selecting '$selectString' to file $outputFile"

    "${ORACLE_HOME}/bin/sqlplus" -s ${DATABASE} 2>&1 > $outputFile <<EOF
         set head off
	 set pagesize 0
	 set echo off
	 set feed off
	 set term off

         $selectString
	 exit
EOF

}

function dbchecks1 {

    typeset outFile result
    typeset -i error

    error=0

    outFile=$TEMP_DIR/dbchecks

    # Checking DB mode is ALLOWED
    selectToFile "select distinct trim(LOGINS) from v\$instance;" $outFile

    result=`cat $outFile`

    if [[ "${result}" = "RESTRICTED" ]]; then
	logFailure "dbchecks1" "Database mode is RESTRICTED when it should be ALLOWED"
	error=1
    else
	echo "database is in ALLOWED mode"
    fi

    # if we've got here without a problem, then log success
    if [ $error -eq 0 ]; then
	logSuccess dbChecks1
    fi
}



function oraInitParamInner {

    # deliberately have neededValue and foundValue as a string, to avoid overflow
    typeset paramName operation neededValue foundValue tempFile
    typeset -i result

    paramName=$1
    operation=$2
    neededValue=$3
    mode=$4

    echo "checking that Oracle init parameter $paramName $operation $neededValue"

    tempFile=$TEMP_DIR/oraInitParam

    selectToFile "select value from v\$parameter where name='$paramName';" $tempFile

    foundValue=`cat $tempFile`

    # go via awk to avoid overflow

    case "$operation" in
	"ge") result=`echo $foundValue $neededValue | awk '{if ($1+0 >= $2) {print 1} else {print 0}}'`
	      break;;

	      # deliberately no +0 to cope with strings or numbers
	"eq") result=`echo $foundValue $neededValue | awk '{if ($1 == $2) {print 1} else {print 0}}'`
	      break;;

	"ne") result=`echo $foundValue $neededValue | awk '{if ($1 != $2) {print 1} else {print 0}}'`
              break;;

    # bad operation?
	   *) logFailure "oraInitParam" "unknown comparison operation $operation"
              return;;
    esac

    if [[ $mode = 'warn' ]]; then
	if [[ $result -eq 1 ]]; then
	    logSuccess "oraInitParamWarn" "$paramName needs to be $operation $neededValue, and found $foundValue"
	else
	    logWarning "oraInitParamWarn" "$paramName needs to be $operation $neededValue, but found $foundValue"
	fi
    else
	if [[ $result -eq 1 ]]; then
	    logSuccess "oraInitParam" "$paramName needs to be $operation $neededValue, and found $foundValue"
	else
	    logFailure "oraInitParam" "$paramName needs to be $operation $neededValue, but found $foundValue"
	fi
    fi
}


# like oraInitParam, but gives pass / warning rather than pass / fail
function oraInitParamWarn {

    if [[ $# -ne 3 ]]; then
	logFailure "oraInitParamWarn" "need 3 parameters - oracle parameter name, operation, needed value - and got $# ($*)"
	return
    fi

    oraInitParamInner $1 $2 $3 'warn'
}

function oraInitParam {

    if [[ $# -ne 3 ]]; then
	logFailure "oraInitParam" "need 3 parameters - oracle parameter name, operation, needed value - and got $# ($*)"
	return
    fi

    oraInitParamInner $1 $2 $3 'fail'
}


function oracleVersion {

    typeset outFile tempMessageFile resultString minVersionString foundVersionString
    typeset -i i

    minVersionString=$1

    echo "testing that the Oracle version is at least $minVersionString"

    outFile=$TEMP_DIR/oracleVersion
    tempMessageFile=$TEMP_DIR/ovmessage

    selectToFile "select distinct trim(VERSION) from v\$instance;" $outFile
    foundVersionString=`cat $outFile`

    echo "as a string, the Oracle version I've found is '$foundVersionString'"

    if [[ "$foundVersionString" = "" ]]; then
	logFailure oracleVersion "can't find the Oracle version"
	return
    fi

    # we'll need this regardless of the outcome, so prepare it here
    printf "looking for minimum Oracle version %s and found %s" "$minVersionString" "$foundVersionString" > $tempMessageFile
    resultString=`cat $tempMessageFile`

    compareVersions "$minVersionString" "$foundVersionString"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure oracleVersion "$resultString"
    else
	logSuccess oracleVersion "$resultString"
    fi
}


# tests that the patch number[s] supplied as arguments have been applied
function oraclePatches {

    typeset patchInventory patchList pointerToInventory patchInventoryRoot patchNum patchString
    typeset -i patchIdx error

    pointerToInventory="$ORACLE_HOME/oraInst.loc"

    patchInventoryRoot=`grep inventory_loc $pointerToInventory | awk 'BEGIN{FS="="}{print $2}'`

    patchInventory=$patchInventoryRoot"/Contents/oneoffs*"

    patchList=`grep -h "<ONEOFF " $patchInventory | awk '{for (i=1; i<=NF; i++) {if ($i ~ /^REF_ID="/) {print $i}}}' | tr -d 'REF_ID="'`

    echo "found patch list $patchList"

    # turn the passed in list of patch numbers into an array for easier processing
    unset IFS
    set -A patchNum "$@"
    patchIdx=0
    error=0
    patchString="found"

    while [[ $patchIdx -lt ${#patchNum[*]} ]]; do
	echo "looking for patch $patchIdx = ${patchNum[$patchIdx]}"

	result=`echo $patchList | grep ${patchNum[$patchIdx]}`

	if [[ "$result" = "" ]]; then
	    logFailure oraclePatches "can't find patch ${patchNum[$patchIdx]}"
	    echo "can't find patch"
	    error=1
	else
	    echo "found patch"
	    patchString="$patchString ${patchNum[$patchIdx]}"
	fi

	patchIdx=$(( $patchIdx+1 ))
    done

    if [[ $error -eq 0 ]]; then
	logSuccess oraclePatches "$patchString"
    fi
}

function checkXDBcount {

    typeset -i minValue foundValue
    typeset tmpFile

    minValue=$1

    print "checking that there are at least $minValue valid XDB objects"

    tmpFile=$TEMP_DIR/xdbcount

    selectToFile "select count(*) from dba_objects where owner='XDB' and status='VALID';" $tmpFile

    foundValue=`cat $tmpFile`

    if [[ $foundValue -ge $minValue ]]; then
	logSuccess checkXDBcount "looking for at least $minValue valid XDB objects, and found $foundValue"
    else
	logFailure checkXDBcount "looking for at least $minValue valid XDB objects, but found $foundValue"
    fi
}

# Checks the version of a valid component in the dba_registry
#
# Called by other tests - isn't a test itself
# Args: 1 = minimum version needed
#       2 = component name to check for
#       3 = name of calling test
#
function checkDBregistryEntryVersion {

    typeset minVersion tmpFile foundVersion objectName checkName

    minVersion=$1
    objectName=$2
    checkName=$3

    print "checking that the $objectName version is at least $minVersion"

    tmpFile=$TEMP_DIR/dbRegistryObjectversion

    selectToFile "select VERSION from DBA_REGISTRY where COMP_NAME='$objectName' and status='VALID';" $tmpFile

    foundVersion=`cat $tmpFile`

    compareVersions "$minVersion" "$foundVersion"

    if [[ $versionComparison -eq 2 ]]; then
	logFailure $checkName "looking for $objectName version at least $minVersion, but found $foundVersion"
    else
	logSuccess $checkName "looking for $objectName version at least $minVersion, and found $foundVersion"
    fi
}


function checkJavaDbVersion {
    checkDBregistryEntryVersion $1 'JServer JAVA Virtual Machine' 'checkJavaDbVersion'
}

function checkXMLdbVersion {
    checkDBregistryEntryVersion $1 'Oracle XML Database' 'checkXMLdbVersion'
}


function checkDBoption {

    typeset tmpFile optionName neededValue foundValue

    optionName=$1
    neededValue=$2

    tmpFile=$TEMP_DIR/checkDBoption

    selectToFile "select trim(value) from v\$option where parameter='$optionName';" $tmpFile

    foundValue=`cat $tmpFile`

    if [[ "$neededValue" = "$foundValue" ]]; then
	logSuccess checkDBoption "checking that parameter $optionName had the value $neededValue"
    else
	logFailure checkDBoption "checking that parameter $optionName had the value $neededValue, but found it had the value $foundValue"
    fi
}


# Captures the UNIX user and group that's running the db processes (smon, actually)
# These are copied back to the master, which checks that the same user and group names are used everywhere
#
function checkDBunixUser {

    typeset tmpFile resultFile procinst procinfo groupName

    tmpFile=$TEMP_DIR/dbunixuser
    resultFile=$RESULT_DIR/dbunixuser.`hostname`

    # get the db instance and unix user name
    ps -ef | grep smon | grep -v grep | awk '{print $1 " " $8}' > $tmpFile

    print 'found db unix processes '
    cat $tmpFile

    cat $tmpFile | while read procinst
    do
	set -A procinfo $procinst

	print "processing line '$procinst' as unix user ${procinfo[0]} and process ${procinfo[1]}"

	groupName=`id -gn ${procinfo[0]}`

	print "found unix group name $groupName"

	# add the unix group name to the info we already have
	echo "${procinfo[0]} $groupName ${procinfo[1]}" >> $resultFile
    done
}
